package com.wofu.ecommerce.taobao;

import java.sql.Connection;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.domain.FenxiaoProduct;
import com.taobao.api.domain.FenxiaoSku;

import com.taobao.api.request.FenxiaoProductUpdateRequest;
import com.taobao.api.request.FenxiaoProductsGetRequest;

import com.taobao.api.response.FenxiaoProductUpdateResponse;
import com.taobao.api.response.FenxiaoProductsGetResponse;
import com.wofu.business.stock.StockManager;
import com.wofu.common.tools.sql.PoolHelper;
import com.wofu.common.tools.sql.SQLHelper;

import com.wofu.common.tools.util.DOMHelper;
import com.wofu.common.tools.util.JException;
import com.wofu.common.tools.util.StringUtil;
import com.wofu.common.tools.util.log.Log;
import com.wofu.base.job.timer.TimerJob;
import com.wofu.base.job.Executer;

public class SynDistributionStockExecuter extends Executer {
	
	private String url="";

	private String appkey="";

	private String appsecret="";

	private String authcode="";

	private String tradecontactid="";

	private String dbname="";
	
	private String username="";


	public void execute() throws Exception {
		// TODO Auto-generated method stub
		TimerJob job=(TimerJob) this.getExecuteobj();
		Properties prop=StringUtil.getStringProperties(job.getParams());
		
		url=prop.getProperty("url");
		appkey=prop.getProperty("appkey");
		appsecret=prop.getProperty("appsecret");
		authcode=prop.getProperty("authcode");
		tradecontactid=prop.getProperty("tradecontactid");
		dbname=prop.getProperty("dbname");
		username=prop.getProperty("username");
		Connection conn=PoolHelper.getInstance().getConnection(dbname);
		
		//if (job.getNotes().indexOf("����")>=0)		
		///	authcode=TaoBaoUtils.getToken(conn, tradecontactid, appkey, appsecret);
		
		synUpStock(conn);
		synDownStock(conn);
		downProduct(conn);		
	}
	
	private void synUpStock(Connection conn) throws Exception
	{
		int i=0;
		int j=0;
		long pageno=1L;
		Log.info("��ʼͬ���ϼ���Ʒ���");
		String sql="select orgid from ecs_tradecontactorgcontrast with(nolock) where tradecontactid="+tradecontactid;
		int orgid=SQLHelper.intSelect(conn, sql);
		
		sql="select defaultalarmqty from tradecontacts with(nolock)where tradecontactid="+tradecontactid;
		int defaultalarmqty=SQLHelper.intSelect(conn, sql);
		
		for (int k=0;k<10;)
		{
			try
			{
				
				TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
				FenxiaoProductsGetRequest req=new FenxiaoProductsGetRequest();
				req.setFields("skus");
				req.setStatus("up");
				req.setPageNo(pageno);
			
				req.setPageSize(20L);
				
				FenxiaoProductsGetResponse response = client.execute(req , authcode);					
					

				Document doc = DOMHelper.newDocument(response.getBody(), "GBK");
		           
				Element urlset = doc.getDocumentElement();
				
				while(true)
				{														
					if (!DOMHelper.ElementIsExists(urlset, "products") || response.getProducts()==null || response.getProducts().size()<=0)
					{
						k=10;
						break;
					}
				
					for(Iterator ititems=response.getProducts().iterator();ititems.hasNext();)
					{
					
						i=i+1;
						FenxiaoProduct product=(FenxiaoProduct) ititems.next();
						long productid=product.getPid();
					
						String skuids="";
						String skus="";
						String origskuqtys="";
						String skuqtys="";
						String adjustqtys="";
						int type=1;
						
						long quantity=product.getQuantity();
						int totalqty=0;
						
						if (product.getSkus()!=null)
						{
							
							boolean needSyn=true;
							boolean existsflag=false;
							for(Iterator it=product.getSkus().iterator();it.hasNext();)
							{
								
								j=j+1;
								FenxiaoSku fxsku=(FenxiaoSku) it.next();
								
									
								Log.info("ͬ���������","SKU:"+fxsku.getOuterId()+" ԭ���:"+String.valueOf(fxsku.getQuantity()));
							
								String sku=fxsku.getOuterId();
								quantity=fxsku.getQuantity();
								
							
								boolean ismulti=false;
								
								sql="select count(*) from barcode with(nolock) where custombc='"+sku+"'";
								if (SQLHelper.intSelect(conn, sql)==0)
								{
									sql="select count(*) from MultiSKURef where refcustomercode='"+sku+"'";
									if (SQLHelper.intSelect(conn, sql)==0)
									{
										Log.warn(username,"�Ҳ���SKU��"+sku+"����Ӧ������,��Ʒ����:"+product.getDescription());									
										continue;
									}
									
									ismulti=true;
								}
								
			
								
								existsflag=true;
								
								sql="select count(*) from ecs_stockconfig with(nolock) where orgid="+orgid+" and sku='"+sku+"'";
								if (SQLHelper.intSelect(conn, sql)==0)
								{
									StockManager.StockConfig(conn, sku, Integer.parseInt(tradecontactid)) ;
									Log.info("��Ʒδ���þ�����,SKU:"+sku);
								}
								
								sql="select alarmqty,isneedsyn,addstockqty from ecs_stockconfig with(nolock) "
									+"where orgid="+orgid+" and sku='"+sku+"'";
								Hashtable ht=SQLHelper.oneRowSelect(conn, sql);
								
								int alarmqty=Integer.valueOf(ht.get("alarmqty").toString());
								int isneedsyn=Integer.valueOf(ht.get("isneedsyn").toString());
								int addstockqty=Integer.valueOf(ht.get("addstockqty").toString());
								
								if (isneedsyn==0)
								{
									needSyn=false;
									Log.info("���ò���Ҫͬ�����,SKU:"+sku);
									continue;  //����Ҫͬ��
								}
								
			
									
								int newqty=0;
								
								int qty =0;
								
								if (ismulti)
								{
									int minqty=1000000;
									sql="select customercode from MultiSKURef where refcustomercode='"+sku+"'";
									List multiskulist=SQLHelper.multiRowListSelect(conn, sql);
									for(Iterator itmulti=multiskulist.iterator();itmulti.hasNext();)
									{
										String customercode=(String) itmulti.next();
										qty=StockManager.getTradeContactUseableStock(conn, Integer.valueOf(tradecontactid).intValue(), customercode);
										
										if (qty<minqty)
										{
											minqty=qty;
										}
									}
									
									qty=minqty;
								}
								else
								{
									qty=StockManager.getTradeContactUseableStock(conn, Integer.valueOf(tradecontactid).intValue(), sku);
								}
								
								if (qty<0) qty=0;
			

								//������ÿ����������ӵĿ��С�ڵ��ھ�����,�򽫿��ͬ��Ϊ0
								if ((qty+addstockqty)<=alarmqty)
								{
									if(fxsku.getQuantity()!=0L)
									{
										skuids=skuids.concat(fxsku.getId()+",");
										origskuqtys=origskuqtys.concat(fxsku.getQuantity()+",");
										skus=skus.concat(fxsku.getOuterId()+",");
										skuqtys=skuqtys.concat("0,");
									
										//���¾���״̬
										sql="update ecs_stockconfig set alarmstatus=1,alarmtime=getdate() "
											+"where orgid="+orgid+" and sku='"+sku+"'";
										SQLHelper.executeSQL(conn, sql);
										Log.warn("ͬ���������","��Ʒ����Ѵﵽ������:"+alarmqty+",SKU:"+sku);
									}									
								}
								else
								{
									skuids=skuids.concat(fxsku.getId()+",");
									origskuqtys=origskuqtys.concat(fxsku.getQuantity()+",");
									skus=skus.concat(fxsku.getOuterId()+",");
									
									skuqtys=skuqtys.concat(String.valueOf(qty+addstockqty)+",");
									
									newqty=qty+addstockqty;
									
									sql="update ecs_stockconfig set alarmstatus=0 "
										+"where orgid="+orgid+" and sku='"+sku+"'";
									SQLHelper.executeSQL(conn, sql);
									
									totalqty=totalqty+qty+addstockqty;
									
									Log.info("ͬ���������","��Ʒ�������,SKU:"+sku);
								}
								
								sql="update ecs_stockconfig set stockcount="+newqty
									+" where orgid="+orgid+" and sku='"+sku+"'";
								SQLHelper.executeSQL(conn, sql);
							}
							
							//���ܵ�����С�ھ��������ȫ��SKU����Ҫͬ�����ʱ�¼�
							if ((totalqty<=defaultalarmqty) && needSyn)
							{
								if (existsflag)  //�Ҳ������ϲ��¼�
									updateStatus("ͬ���������",product.getPid(),product.getOuterId());
							}
							else
							{
								if (!skuids.equals(""))
								{
									skuids=skuids.substring(0, skuids.length()-1);
									origskuqtys=origskuqtys.substring(0, origskuqtys.length()-1);
									skus=skus.substring(0, skus.length()-1);
									skuqtys=skuqtys.substring(0, skuqtys.length()-1);
									
									
								
									StockUtils.updateDistributionStock("ͬ���������","0000000000",url,appkey,appsecret,
											authcode,productid,skuids,skus,origskuqtys,skuqtys,adjustqtys,type,true);
									
								}
							}
							
						}
						else
						{
							Log.info("ͬ���������","SKU:"+product.getOuterId()+" ԭ���:"+String.valueOf(product.getQuantity()));
							
							String sku=product.getOuterId();
							
							sql="select count(*) from barcode with(nolock) where custombc='"+sku+"'";
							if (SQLHelper.intSelect(conn, sql)==0)
							{
								Log.warn("�Ҳ���SKU��"+sku+"����Ӧ������!");
								continue;
							}
							
							sql="select count(*) from ecs_stockconfig with(nolock) where orgid="+orgid+" and sku='"+sku+"'";
							if (SQLHelper.intSelect(conn, sql)==0)
							{
								StockManager.StockConfig(conn, sku, Integer.parseInt(tradecontactid)) ;
								Log.info("��Ʒδ���þ�����,SKU:"+sku);
							}
							
							sql="select alarmqty,isneedsyn,addstockqty from ecs_stockconfig with(nolock) "
								+"where orgid="+orgid+" and sku='"+sku+"'";
							Hashtable ht=SQLHelper.oneRowSelect(conn, sql);
							
							int alarmqty=Integer.valueOf(ht.get("alarmqty").toString());
							int isneedsyn=Integer.valueOf(ht.get("isneedsyn").toString());
							int addstockqty=Integer.valueOf(ht.get("addstockqty").toString());
							
							if (isneedsyn==0) continue;  //����Ҫͬ��
							
							int qty=StockManager.getTradeContactUseableStock(conn, Integer.valueOf(tradecontactid).intValue(), sku);

							//������ÿ����������ӵĿ��С�ڵ��ھ�����,�򽫿��ͬ��Ϊ0
							if ((qty+addstockqty)<=alarmqty)
							{
								if (product.getQuantity()!=0L)
								{
									skuids=skuids.concat(product.getPid()+",");								
									origskuqtys=origskuqtys.concat(product.getQuantity()+",");
									skus=skus.concat(product.getOuterId()+",");
									skuqtys=skuqtys.concat("0,");
									
									//���¾���״̬
									sql="update ecs_stockconfig set alarmstatus=1,alarmtime=getdate() "
										+"where orgid="+orgid+" and sku='"+sku+"'";
									SQLHelper.executeSQL(conn, sql);
									Log.warn("ͬ���������","��Ʒ����Ѵﵽ������:"+alarmqty+",SKU:"+sku);
									
									//�¼�
									updateStatus("ͬ���������",product.getPid(),product.getOuterId());
								}
							}
							else
							{
								skuids=skuids.concat(product.getPid()+",");
								origskuqtys=origskuqtys.concat(product.getQuantity()+",");
								skus=skus.concat(product.getOuterId()+",");
								skuqtys=skuqtys.concat(String.valueOf(qty+addstockqty)+",");
								
								sql="update ecs_stockconfig set alarmstatus=0 "
									+"where orgid="+orgid+" and sku='"+sku+"'";
								SQLHelper.executeSQL(conn, sql);
								
								totalqty=totalqty+qty+addstockqty;
								
								Log.info("ͬ���������","��Ʒ�������,SKU:"+sku);
							}						

							if (!skuids.equals(""))
							{
								skuids=skuids.substring(0, skuids.length()-1);
								origskuqtys=origskuqtys.substring(0, origskuqtys.length()-1);
								skus=skus.substring(0, skus.length()-1);
								skuqtys=skuqtys.substring(0, skuqtys.length()-1);
							
								if (totalqty>0)
									StockUtils.updateDistributionStock("ͬ���������","0000000000",url,appkey,appsecret,
										authcode,productid,skuids,skus,origskuqtys,skuqtys,adjustqtys,type,false);
							}
						}
					}
					
					if (pageno==(Double.valueOf(Math.ceil(response.getTotalResults()/20.0))).intValue()) break;
					
					Log.info("ҳ��:"+req.getPageNo());
					pageno=pageno+1;
					req.setPageNo(pageno);			
					response=client.execute(req , authcode);			
				}
				k=10;
				Log.info("�������Ʒ��:"+String.valueOf(i)+" ��SKU��:"+String.valueOf(j));
			
			} catch (Exception e) {
				if (++k >= 10)
					throw e;
				Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
			} finally {
				try {
					if (conn != null)
						conn.close();
				} catch (Exception e) {
					throw new JException("�ر����ݿ�����ʧ��");
				}
			}
		}
	}
	private void synDownStock(Connection conn) throws Exception
	{
		int i=0;
		int j=0;
		long pageno=1L;
		String sql="select orgid from ecs_tradecontactorgcontrast with(nolock) where tradecontactid="+tradecontactid;
		int orgid=SQLHelper.intSelect(conn, sql);
		
		Log.info("��ʼͬ���ֿ���Ʒ���");
		for (int k=0;k<10;)
		{
			try
			{
				
				TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
				FenxiaoProductsGetRequest req=new FenxiaoProductsGetRequest();
				req.setFields("skus");
				req.setStatus("down");
				req.setPageNo(pageno);
			
				req.setPageSize(20L);
				
				FenxiaoProductsGetResponse response = client.execute(req , authcode);					
					

				Document doc = DOMHelper.newDocument(response.getBody(), "GBK");
		           
				Element urlset = doc.getDocumentElement();
				
				while(true)
				{														
					if (!DOMHelper.ElementIsExists(urlset, "products") || response.getProducts()==null || response.getProducts().size()<=0)
					{
						k=10;
						break;
					}
				
					for(Iterator ititems=response.getProducts().iterator();ititems.hasNext();)
					{
					
						i=i+1;
						FenxiaoProduct product=(FenxiaoProduct) ititems.next();
						long productid=product.getPid();
					
						String skuids="";
						String skus="";
						String origskuqtys="";
						String skuqtys="";
						String adjustqtys="";
						int type=1;
						
						long quantity=product.getQuantity();
						
						if (product.getSkus()!=null)
						{
							for(Iterator it=product.getSkus().iterator();it.hasNext();)
							{
								
								j=j+1;
								FenxiaoSku fxsku=(FenxiaoSku) it.next();
								
									
								Log.info("ͬ���������","SKU:"+fxsku.getOuterId()+" ԭ���:"+String.valueOf(fxsku.getQuantity()));
							
								String sku=fxsku.getOuterId();
								quantity=fxsku.getQuantity();
							
								sql="select count(*) from barcode with(nolock) where custombc='"+sku+"'";
								if (SQLHelper.intSelect(conn, sql)==0)
								{
									Log.warn("�Ҳ���SKU��"+sku+"����Ӧ������!");
									continue;
								}
															
								sql="select count(*) from ecs_stockconfig with(nolock) where orgid="+orgid+" and sku='"+sku+"'";
								if (SQLHelper.intSelect(conn, sql)>0)
								{
									sql="select isneedsyn from ecs_stockconfig with(nolock) where orgid="+orgid+" and sku='"+sku+"'";
									int isneedsyn=SQLHelper.intSelect(conn, sql);
									
									if (isneedsyn==0) continue;
								}
								
								skuids=skuids.concat(fxsku.getId()+",");
								origskuqtys=origskuqtys.concat(fxsku.getQuantity()+",");
								skus=skus.concat(fxsku.getOuterId()+",");
								
								int qty=StockManager.getTradeContactUseableStock(conn, Integer.valueOf(tradecontactid).intValue(), sku);
					
								skuqtys=skuqtys.concat(String.valueOf(qty)+",");
		
							}
							
							if (!skuids.equals(""))
							{
								skuids=skuids.substring(0, skuids.length()-1);
								origskuqtys=origskuqtys.substring(0, origskuqtys.length()-1);
								skus=skus.substring(0, skus.length()-1);
								skuqtys=skuqtys.substring(0, skuqtys.length()-1);
							
								StockUtils.updateDistributionStock("ͬ���������","0000000000",url,appkey,appsecret,
										authcode,productid,skuids,skus,origskuqtys,skuqtys,adjustqtys,type,true);
								
							}
						}
						else
						{
							Log.info("ͬ���������","SKU:"+product.getOuterId()+" ԭ���:"+String.valueOf(product.getQuantity()));
							
							String sku=product.getOuterId();
							
							sql="select count(*) from barcode with(nolock) where custombc='"+sku+"'";
							if (SQLHelper.intSelect(conn, sql)==0)
							{
								Log.warn("�Ҳ���SKU��"+sku+"����Ӧ������!");
								continue;
							}
							
							sql="select count(*) from ecs_stockconfig with(nolock) where orgid="+orgid+" and sku='"+sku+"'";
							if (SQLHelper.intSelect(conn, sql)>0)
							{
								sql="select isneedsyn from ecs_stockconfig with(nolock) where orgid="+orgid+" and sku='"+sku+"'";
								int isneedsyn=SQLHelper.intSelect(conn, sql);
								
								if (isneedsyn==0) continue;
							}

							skuids=skuids.concat(product.getPid()+",");
							origskuqtys=origskuqtys.concat(product.getQuantity()+",");
							skus=skus.concat(product.getOuterId()+",");
							
							int qty=StockManager.getTradeContactUseableStock(conn, Integer.valueOf(tradecontactid).intValue(), sku);

							skuqtys=skuqtys.concat(String.valueOf(qty)+",");
								
							if (!skuids.equals(""))
							{
								skuids=skuids.substring(0, skuids.length()-1);
								origskuqtys=origskuqtys.substring(0, origskuqtys.length()-1);
								skus=skus.substring(0, skus.length()-1);
								skuqtys=skuqtys.substring(0, skuqtys.length()-1);
							
								StockUtils.updateDistributionStock("ͬ���������","0000000000",url,appkey,appsecret,
										authcode,productid,skuids,skus,origskuqtys,skuqtys,adjustqtys,type,false);
								
							}
						}
					}
					
					if (pageno==(Double.valueOf(Math.ceil(response.getTotalResults()/20.0))).intValue()) break;
					
					Log.info("ҳ��:"+req.getPageNo());
					pageno=pageno+1;
					req.setPageNo(pageno);			
					response=client.execute(req , authcode);			
				}
				k=10;
				Log.info("�������Ʒ��:"+String.valueOf(i)+" ��SKU��:"+String.valueOf(j));
			
			} catch (Exception e) {
				if (++k >= 10)
					throw e;
				Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
			} finally {
				try {
					if (conn != null)
						conn.close();
				} catch (Exception e) {
					throw new JException("�ر����ݿ�����ʧ��");
				}
			}
		}
	}
	private void downProduct(Connection conn) throws Exception
	{
		int i=0;
		long pageno=1L;
		
		String sql="select defaultalarmqty from tradecontacts with(nolock)where tradecontactid="+tradecontactid;
		int defaultalarmqty=SQLHelper.intSelect(conn, sql);
		
		sql="select orgid from ecs_tradecontactorgcontrast with(nolock) where tradecontactid="+tradecontactid;
		int orgid=SQLHelper.intSelect(conn, sql);
		
		for (int k=0;k<10;)
		{
			try
			{
				
				TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
				FenxiaoProductsGetRequest req=new FenxiaoProductsGetRequest();
				req.setStatus("up");
				req.setPageNo(pageno);			
				req.setPageSize(20L);
				
				FenxiaoProductsGetResponse response = client.execute(req , authcode);					

				Document doc = DOMHelper.newDocument(response.getBody(), "GBK");
		           
				Element urlset = doc.getDocumentElement();
				
				while(true)
				{														
					if (!DOMHelper.ElementIsExists(urlset, "products") || response.getProducts()==null || response.getProducts().size()<=0)
					{
						k=10;
						break;
					}
				
					for(Iterator ititems=response.getProducts().iterator();ititems.hasNext();)
					{
					
						i=i+1;
						boolean needSyn=true;
						FenxiaoProduct product=(FenxiaoProduct) ititems.next();
												
						Log.info("���·�����Ʒ״̬","����:"+product.getOuterId()+" ���:"+String.valueOf(product.getQuantity()));
						
						sql="select count(*) from ecs_stockconfig "
							+"where orgid="+orgid+" and sku like '"+product.getOuterId()+"%' and isneedsyn=0";
						if (SQLHelper.intSelect(conn, sql)>0)
							needSyn=false;
						
						//����Ʒ���С�ھ�����,���Ҳ�Ʒ������SKU����Ҫͬ�����ʱ���¼�
						if ((product.getQuantity()<defaultalarmqty) && needSyn)
						{
							updateStatus("���·�����Ʒ״̬",product.getPid(),product.getOuterId());
						}

					}
					
					if (pageno==(Double.valueOf(Math.ceil(response.getTotalResults()/20.0))).intValue()) break;
					
					Log.info("ҳ��:"+req.getPageNo());
					pageno=pageno+1;
					req.setPageNo(pageno);			
					response=client.execute(req , authcode);			
				}
				k=10;
				Log.info("�������Ʒ��:"+String.valueOf(i));
			
			} catch (Exception e) {
				if (++k >= 10)
					throw e;
				Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
			}
		}
	}
	
	private void updateStatus(String modulename,long pid,String customno) 
	throws JException
	{
		
		try {			
			TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret);

			FenxiaoProductUpdateRequest updatereq=new FenxiaoProductUpdateRequest();
			updatereq.setPid(pid);
			updatereq.setStatus("down");			
			FenxiaoProductUpdateResponse response = client.execute(updatereq,authcode);
				
			Log.info(modulename,"���·�����Ʒ״̬�ɹ�,����:"+customno);
			
		
		} catch (Exception e) {
			throw new JException("���·�����Ʒ״̬ʧ��,����:"+customno+" ������Ϣ:" + e.getMessage());
		}
	}
	
}
