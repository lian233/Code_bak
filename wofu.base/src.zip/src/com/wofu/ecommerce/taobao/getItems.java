package com.wofu.ecommerce.taobao;


import java.sql.Connection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;

import org.w3c.dom.Document;
import org.w3c.dom.Element;


import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.domain.Item;

import com.taobao.api.request.ItemGetRequest;
import com.taobao.api.request.ItemsInventoryGetRequest;
import com.taobao.api.request.ItemsOnsaleGetRequest;

import com.taobao.api.response.ItemGetResponse;
import com.taobao.api.response.ItemsInventoryGetResponse;
import com.taobao.api.response.ItemsOnsaleGetResponse;
import com.wofu.common.tools.sql.PoolHelper;

import com.wofu.common.tools.util.DOMHelper;
import com.wofu.common.tools.util.Formatter;
import com.wofu.common.tools.util.JException;

import com.wofu.common.tools.util.log.Log;
import com.wofu.business.stock.StockManager;
import com.wofu.business.util.PublicUtils;

public class getItems extends Thread {

	private static String jobname = "��ȡ�Ա���Ʒ������ҵ";
	
	private static long daymillis=24*60*60*1000L;
	
	private static String lasttimeconfvalue=Params.username+"ȡ��Ʒ����ʱ��";
	
	SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
	
	private boolean is_importing=false;
	
	private String lasttime;


	public getItems() {
		setDaemon(true);
		setName(jobname);
	}

	public void run() {
		Log.info(jobname, "����[" + jobname + "]ģ��");
		do {		
			Connection connection = null;
			is_importing = true;
			try {												
				connection = PoolHelper.getInstance().getConnection(
						com.wofu.ecommerce.taobao.Params.dbname);
				lasttime=PublicUtils.getConfig(connection,lasttimeconfvalue,"");
				//if (Params.isdistribution)
					//Params.authcode=TaoBaoUtils.getToken(connection, Params.tradecontactid, Params.appkey, Params.appsecret);
	
				getOnSaleItems(connection);

			} catch (Exception e) {
				try {
					if (connection != null && !connection.getAutoCommit())
						connection.rollback();
				} catch (Exception e1) {
					Log.error(jobname, "�ع�����ʧ��");
				}
				Log.error("105", jobname, Log.getErrorMessage(e));
			} finally {
				is_importing = false;
				try {
					if (connection != null)
						connection.close();
				} catch (Exception e) {
					Log.error(jobname, "�ر����ݿ�����ʧ��");
				}
			}
			System.gc();
			long startwaittime = System.currentTimeMillis();
			while (System.currentTimeMillis() - startwaittime < (long) (com.wofu.ecommerce.taobao.Params.waittime * 1000))		
				try {
					sleep(1000L);
				} catch (Exception e) {
					Log.warn(jobname, "ϵͳ��֧�����߲���, ��ҵ������Ӱ���������");
				}
		} while (true);
	}

	
	/*
	 *  ȡ������Ʒ
	 */
	private void getOnSaleItems(Connection conn) throws Exception
	{		
		int i=0;
		int j=0;
		long pageno=1L;
		Date modified=Formatter.parseDate(lasttime,Formatter.DATE_TIME_FORMAT);

		Log.info("��ʼȡ�Ա��ϼ���Ʒ");
		
		for(int k=0;k<10;)
		{
			try
			{
				TaobaoClient client=new DefaultTaobaoClient(Params.url,Params.appkey, Params.appsecret,"xml");
				ItemsOnsaleGetRequest req=new ItemsOnsaleGetRequest();
				req.setFields("num_iid,modified,outer_id");	
				Date startdate=new Date(Formatter.parseDate(lasttime,Formatter.DATE_TIME_FORMAT).getTime()+1000L);
				Date enddate=new Date(Formatter.parseDate(lasttime,Formatter.DATE_TIME_FORMAT).getTime()+daymillis);
				req.setStartModified(startdate);
				req.setEndModified(enddate);
				req.setPageNo(pageno);
				req.setPageSize(40L);
				ItemsOnsaleGetResponse response = client.execute(req , Params.authcode);

			
				while(true)
				{
								
					if (response.getItems()==null || response.getItems().size()<=0)
					{				
						if (i==0)		
						{
							try
							{
								//��һ��֮�ڶ�ȡ�������������ҵ�ǰ����������죬��ȡ��������ʱ�����Ϊ��ǰ������
								if (this.dateformat.parse(Formatter.format(new Date(), Formatter.DATE_FORMAT)).
										compareTo(this.dateformat.parse(Formatter.format(Formatter.parseDate(PublicUtils.getConfig(conn,lasttimeconfvalue,""),Formatter.DATE_TIME_FORMAT),Formatter.DATE_FORMAT)))>0)
								{
									try
				                	{
										String value=Formatter.format((new Date(Formatter.parseDate(PublicUtils.getConfig(conn,lasttimeconfvalue,""),Formatter.DATE_TIME_FORMAT).getTime()+daymillis)),Formatter.DATE_FORMAT)+" 00:00:00";
										PublicUtils.setConfig(conn, lasttimeconfvalue, value);			    
				                	}catch(JException je)
				                	{
				                		Log.error(jobname, je.getMessage());
				                	}
								}
							}catch(ParseException e)
							{
								Log.error(jobname, "�����õ����ڸ�ʽ!"+e.getMessage());
							}
						}
						k=10;
						break;
					}
					
					
					
					for(Iterator ititems=response.getItems().iterator();ititems.hasNext();)
					{
						i=i+1;
						Item item=(Item) ititems.next();
						long num_iid=item.getNumIid();
						
						ItemGetRequest reqitem=new ItemGetRequest();
						reqitem.setFields("num_iid,outer_id,num,sku.num_iid,sku.sku_id,sku.quantity,sku.outer_id,sku.status");
						reqitem.setNumIid(num_iid);
						ItemGetResponse rspitem = client.execute(reqitem , Params.authcode);
						
	
						
						Document itemdoc = DOMHelper.newDocument(rspitem.getBody(), "GBK");
				           
						Element itemele = (Element) itemdoc.getDocumentElement().getElementsByTagName("item").item(0);
						
						if (!DOMHelper.ElementIsExists(itemele, "skus")) 
						{
							Log.info("SKU "+rspitem.getItem().getOuterId()+" "+Formatter.format(item.getModified(),Formatter.DATE_TIME_FORMAT));
							
							if (rspitem.getItem().getOuterId()!=null)								
								StockManager.StockConfig(conn,rspitem.getItem().getOuterId(),Integer.valueOf(Params.tradecontactid));
						}
						else
						{
							for(Iterator it=rspitem.getItem().getSkus().iterator();it.hasNext();)
							{
								j=j+1;
								com.taobao.api.domain.Sku skuinfo=(com.taobao.api.domain.Sku) it.next();						
								
								Log.info("SKU "+skuinfo.getOuterId()+" "+Formatter.format(item.getModified(),Formatter.DATE_TIME_FORMAT));
								
								if (skuinfo.getOuterId()!=null) 								
									StockManager.StockConfig(conn,skuinfo.getOuterId(),Integer.valueOf(Params.tradecontactid));
								
							}
						}
						
						//����ͬ����������ʱ��
		                if (item.getModified().compareTo(modified)>0)
		                {
		                	modified=item.getModified();
		                }
		                		
					}
					if (pageno==(Double.valueOf(Math.ceil(response.getTotalResults()/40.0))).intValue()) break;
					
					Log.info("ҳ��:"+req.getPageNo());
					pageno=pageno+1;
					req.setPageNo(pageno);			
					response=client.execute(req , Params.authcode);			
				}
				Log.info("ȡ���Ա��ϼ�����Ʒ��:"+String.valueOf(i)+" ��SKU��:"+String.valueOf(j));
		
				
				if (modified.compareTo(Formatter.parseDate(lasttime, Formatter.DATE_TIME_FORMAT))>0)
				{
					try
	            	{
	            		String value=Formatter.format(modified,Formatter.DATE_TIME_FORMAT);
	            		PublicUtils.setConfig(conn, lasttimeconfvalue, value);
	            	}catch(JException je)
	            	{
	            		Log.error(jobname,je.getMessage());
	            	}
				}
				//ִ�гɹ�����ѭ��
				break;
			} catch (Exception e) {
				if (++k >= 10)
					throw e;
				Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
				
			}
		}
	}
	
	/*
	 *  ȡ�ֿ���Ʒ
	 */
	private void getInventoryItems(Connection conn) throws Exception
	{		
		int i=0;
		int j=0;
		long pageno=1L;
		Date modified=Formatter.parseDate(lasttime,Formatter.DATE_TIME_FORMAT);

		Log.info("��ʼȡ�Ա��ֿ���Ʒ");
		
		for(int k=0;k<10;)
		{
			try
			{
				TaobaoClient client=new DefaultTaobaoClient(Params.url,Params.appkey, Params.appsecret,"xml");
				ItemsInventoryGetRequest req=new ItemsInventoryGetRequest();
				req.setFields("num_iid,modified,outer_id");	
				Date startdate=new Date(Formatter.parseDate(lasttime,Formatter.DATE_TIME_FORMAT).getTime()+1000L);
				Date enddate=new Date(Formatter.parseDate(lasttime,Formatter.DATE_TIME_FORMAT).getTime()+daymillis);
				req.setStartModified(startdate);
				req.setEndModified(enddate);
				req.setPageNo(pageno);
				req.setPageSize(40L);
				ItemsInventoryGetResponse response = client.execute(req , Params.authcode);

			
				while(true)
				{
								
					if (response.getItems()==null || response.getItems().size()<=0)
					{				
						if (i==0)		
						{
							try
							{
								//��һ��֮�ڶ�ȡ�������������ҵ�ǰ����������죬��ȡ��������ʱ�����Ϊ��ǰ������
								if (this.dateformat.parse(Formatter.format(new Date(), Formatter.DATE_FORMAT)).
										compareTo(this.dateformat.parse(Formatter.format(Formatter.parseDate(PublicUtils.getConfig(conn,lasttimeconfvalue,""),Formatter.DATE_TIME_FORMAT),Formatter.DATE_FORMAT)))>0)
								{
									try
				                	{
										String value=Formatter.format((new Date(Formatter.parseDate(PublicUtils.getConfig(conn,lasttimeconfvalue,""),Formatter.DATE_TIME_FORMAT).getTime()+daymillis)),Formatter.DATE_FORMAT)+" 00:00:00";
										PublicUtils.setConfig(conn, lasttimeconfvalue, value);			    
				                	}catch(JException je)
				                	{
				                		Log.error(jobname, je.getMessage());
				                	}
								}
							}catch(ParseException e)
							{
								Log.error(jobname, "�����õ����ڸ�ʽ!"+e.getMessage());
							}
						}
						k=10;
						break;
					}
					
					
					
					for(Iterator ititems=response.getItems().iterator();ititems.hasNext();)
					{
						i=i+1;
						Item item=(Item) ititems.next();
						long num_iid=item.getNumIid();
						
						ItemGetRequest reqitem=new ItemGetRequest();
						reqitem.setFields("num_iid,outer_id,num,sku.num_iid,sku.sku_id,sku.quantity,sku.outer_id,sku.status");
						reqitem.setNumIid(num_iid);
						ItemGetResponse rspitem = client.execute(reqitem , Params.authcode);
						
	
						
						Document itemdoc = DOMHelper.newDocument(rspitem.getBody(), "GBK");
				           
						Element itemele = (Element) itemdoc.getDocumentElement().getElementsByTagName("item").item(0);
						
						if (!DOMHelper.ElementIsExists(itemele, "skus")) 
						{
							Log.info("SKU "+rspitem.getItem().getOuterId()+" "+Formatter.format(item.getModified(),Formatter.DATE_TIME_FORMAT));
							
							if (rspitem.getItem().getOuterId()!=null)								
								StockManager.StockConfig(conn,rspitem.getItem().getOuterId(),Integer.valueOf(Params.tradecontactid));
						}
						else
						{
							for(Iterator it=rspitem.getItem().getSkus().iterator();it.hasNext();)
							{
								j=j+1;
								com.taobao.api.domain.Sku skuinfo=(com.taobao.api.domain.Sku) it.next();						
								
								Log.info("SKU "+skuinfo.getOuterId()+" "+Formatter.format(item.getModified(),Formatter.DATE_TIME_FORMAT));
								
								if (skuinfo.getOuterId()!=null) 								
									StockManager.StockConfig(conn,skuinfo.getOuterId(),Integer.valueOf(Params.tradecontactid));
								
							}
						}
						
						//����ͬ����������ʱ��
		                if (item.getModified().compareTo(modified)>0)
		                {
		                	modified=item.getModified();
		                }
		                		
					}
					if (pageno==(Double.valueOf(Math.ceil(response.getTotalResults()/40.0))).intValue()) break;
					
					Log.info("ҳ��:"+req.getPageNo());
					pageno=pageno+1;
					req.setPageNo(pageno);			
					response=client.execute(req , Params.authcode);			
				}
				Log.info("ȡ���Ա��ϼ�����Ʒ��:"+String.valueOf(i)+" ��SKU��:"+String.valueOf(j));
		
				
				if (modified.compareTo(Formatter.parseDate(lasttime, Formatter.DATE_TIME_FORMAT))>0)
				{
					try
	            	{
	            		String value=Formatter.format(modified,Formatter.DATE_TIME_FORMAT);
	            		PublicUtils.setConfig(conn, lasttimeconfvalue, value);
	            	}catch(JException je)
	            	{
	            		Log.error(jobname,je.getMessage());
	            	}
				}
				//ִ�гɹ�����ѭ��
				break;
			} catch (Exception e) {
				if (++k >= 10)
					throw e;
				Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
				
			}
		}
	}
	public String toString()
	{
		return jobname + " " + (is_importing ? "[importing]" : "[waiting]");
	}
}
