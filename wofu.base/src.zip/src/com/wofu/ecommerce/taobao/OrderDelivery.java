package com.wofu.ecommerce.taobao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;


import com.taobao.api.ApiException;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;

import com.taobao.api.request.LogisticsConsignResendRequest;
import com.taobao.api.request.LogisticsOfflineSendRequest;

import com.taobao.api.response.LogisticsConsignResendResponse;
import com.taobao.api.response.LogisticsOfflineSendResponse;

import com.wofu.common.tools.sql.JSQLException;
import com.wofu.common.tools.sql.PoolHelper;
import com.wofu.common.tools.sql.SQLHelper;

import com.wofu.common.tools.util.Formatter;
import com.wofu.common.tools.util.StringUtil;
import com.wofu.common.tools.util.log.Log;


public class OrderDelivery extends Thread {

	private static String jobname = "�Ա���������������ҵ";
	
	private boolean is_exporting = false;

	public void run() {
		Log.info(jobname, "����[" + jobname + "]ģ��");
		do {
			Connection connection = null;
			is_exporting = true;
			try {		
				connection = PoolHelper.getInstance().getConnection(
						com.wofu.ecommerce.taobao.Params.dbname);
				//if (Params.isdistribution)
				//	Params.authcode=TaoBaoUtils.getToken(connection, Params.tradecontactid, Params.appkey, Params.appsecret);
	
				delivery(connection);	
				resend(connection);
			} catch (Exception e) {
				try {
					if (connection != null && !connection.getAutoCommit())
						connection.rollback();
				} catch (Exception e1) {
					Log.error(jobname, "�ع�����ʧ��");
				}
				Log.error("105", jobname, Log.getErrorMessage(e));
			} finally {
				is_exporting = false;
				try {
					if (connection != null)
						connection.close();
				} catch (Exception e) {
					Log.error(jobname, "�ر����ݿ�����ʧ��");
				}
			}
			System.gc();
			long startwaittime = System.currentTimeMillis();
			while (System.currentTimeMillis() - startwaittime < (long) (com.wofu.ecommerce.taobao.Params.waittime * 1000))
				try {
					sleep(1000L);
				} catch (Exception e) {
					Log.warn(jobname, "ϵͳ��֧�����߲���, ��ҵ������Ӱ���������");
				}
		} while (true);
	}

	/**
	 * @param conn
	 * @throws Exception
	 */
	private void delivery(Connection conn)  throws Exception
	{
		
		String sql = "select  a.sheetid,b.tid, upper(ltrim(rtrim(b.companycode))) companycode,"
			+"upper(ltrim(rtrim(b.outsid))) outsid from it_upnote a with(nolock), ns_delivery b with(nolock)"
			+ "where a.sheettype=3 and a.sheetid=b.sheetid and a.receiver='"
			+ Params.tradecontactid + "' and b.iswait=0";
		Vector vdeliveryorder=SQLHelper.multiRowSelect(conn, sql);
		for (int i = 0; i < vdeliveryorder.size(); i++) {
			Hashtable hto = (Hashtable) vdeliveryorder.get(i);
			String sheetid = hto.get("sheetid").toString();
			String orderid = hto.get("tid").toString();
			String post_company = hto.get("companycode").toString();
			String post_no = hto.get("outsid").toString();		
			
			//���������˾Ϊ������Դ���
			if (post_company.trim().equals(""))
			{
				Log.warn(jobname, "��ݹ�˾Ϊ�գ�������:"+orderid+"");
				continue;
			}
			
			//���������˾Ϊ������Դ���
			if (post_no.trim().equals(""))
			{
				Log.warn(jobname, "��ݵ���Ϊ�գ�������:"+orderid+"");
				continue;
			}
			
			if (!StringUtil.isNumeric(orderid))
			{
				sql = "insert into IT_UpNoteBak(Owner,SheetID,SheetType,Sender,Receiver,Notetime,HandleTime,Flag) "
					+ " select Owner , SheetID , SheetType , Sender , Receiver , Notetime , getdate() , 1 from IT_UpNote "
					+ " where SheetID = '"+ sheetid+ "' and SheetType = 3";
				SQLHelper.executeSQL(conn, sql);
	
				sql = "delete from IT_UpNote where SheetID='"+ sheetid + "' and sheettype=3";
	
				SQLHelper.executeSQL(conn, sql);
				
				Log.warn(jobname, "�����š�"+orderid+"����ȫ������!");
				continue;
			}
			

			try {
				
					TaobaoClient client=new DefaultTaobaoClient(Params.url,Params.appkey, Params.appsecret);
					LogisticsOfflineSendRequest req=new LogisticsOfflineSendRequest();	
					req.setOutSid(post_no);
					req.setTid(TranTid(orderid));
					req.setCompanyCode(post_company);
					LogisticsOfflineSendResponse rsp = client.execute(req, Params.authcode);
			
					
					if (rsp.isSuccess())
					{			

						try {
							conn.setAutoCommit(false);

							sql = "insert into IT_UpNoteBak(Owner,SheetID,SheetType,Sender,Receiver,Notetime,HandleTime,Flag) "
									+ " select Owner , SheetID , SheetType , Sender , Receiver , Notetime , getdate() , 1 from IT_UpNote "
									+ " where SheetID = '"+ sheetid+ "' and SheetType = 3";
							SQLHelper.executeSQL(conn, sql);

							sql = "delete from IT_UpNote where SheetID='"+ sheetid + "' and sheettype=3";

							SQLHelper.executeSQL(conn, sql);
							conn.commit();
							conn.setAutoCommit(true);
						} catch (SQLException sqle) {
							if (!conn.getAutoCommit())
								try {
									conn.rollback();
								} catch (Exception e1) {
								}
							try {
								conn.setAutoCommit(true);
							} catch (Exception e1) {
							}
							throw new JSQLException(sql, sqle);
						}
						Log.info(jobname,"����������" + orderid + "�������ɹ�,��ݹ�˾��"+ post_company + "��,��ݵ��š�" + post_no + "��");
					}
					else
					{		
						
						if (rsp.getSubMsg().indexOf("�����ظ�����")>=0|| rsp.getSubMsg().indexOf("�������Ͳ�ƥ��")>=0)
						{
							sql = "insert into IT_UpNoteBak(Owner,SheetID,SheetType,Sender,Receiver,Notetime,HandleTime,Flag) "
								+ " select Owner , SheetID , SheetType , Sender , Receiver , Notetime , getdate() , 1 from IT_UpNote "
								+ " where SheetID = '"+ sheetid+ "' and SheetType = 3";
							SQLHelper.executeSQL(conn, sql);

							sql = "delete from IT_UpNote where SheetID='"+ sheetid + "' and sheettype=3";

							SQLHelper.executeSQL(conn, sql);
							Log.info(jobname,"������" + orderid + "�������ظ�����,��ݹ�˾��"+ post_company + "��,��ݵ��š�" + post_no + "��");
						}
						
						else if((rsp.getSubMsg().indexOf("û��Ȩ�޽��з���")>=0)||rsp.getSubMsg().indexOf("û��Ȩ�޷���")>=0
								||rsp.getSubMsg().indexOf("��ǰ����״̬��֧���޸�")>=0) 
						{
							sql = "insert into IT_UpNoteBak(Owner,SheetID,SheetType,Sender,Receiver,Notetime,HandleTime,Flag) "
								+ " select Owner , SheetID , SheetType , Sender , Receiver , Notetime , getdate() , 1 from IT_UpNote "
								+ " where SheetID = '"+ sheetid+ "' and SheetType = 3";
							SQLHelper.executeSQL(conn, sql);

							sql = "delete from IT_UpNote where SheetID='"+ sheetid + "' and sheettype=3";

							SQLHelper.executeSQL(conn, sql);
							Log.info(jobname,"û��Ȩ�޷���,������" + orderid + "��,��ݹ�˾��"+ post_company + "��,��ݵ��š�" + post_no + "��");
						} else if (rsp.getSubMsg().indexOf("��������������") >=0 || rsp.getSubMsg().indexOf("�����Ѿ�����") >=0
								 || rsp.getSubMsg().indexOf("��ǰ�����Ķ����ǲ𵥶���") >=0)
						{
							TaobaoClient subclient=new DefaultTaobaoClient(Params.url,Params.appkey, Params.appsecret);
							LogisticsOfflineSendRequest subreq=new LogisticsOfflineSendRequest();	
							subreq.setOutSid(post_no);
							subreq.setTid(TranTid(orderid));
							subreq.setCompanyCode(post_company);
							subreq.setIsSplit(1L);
							
							String subtids="";
							
							sql="select oid from customerorderitem a with(nolock),customerorder b with(nolock)," 
									+"customerdelive c with(nolock) where a.sheetid=b.sheetid and a.sheetid=c.refsheetid "
									+"and c.customersheetid='"+orderid+"' and c.delivery='"+post_company+"' "
									+"and c.deliverysheetid='"+post_no+"'";
							List sublist=SQLHelper.multiRowListSelect(conn, sql);
							for(Iterator it=sublist.iterator();it.hasNext();)
							{
								String oid=(String) it.next();
								subtids=oid+","+subtids;
							}
							
							subtids=subtids.substring(0, subtids.length()-1);
							
							subreq.setSubTid(subtids);
							
	
							
							LogisticsOfflineSendResponse subrsp = client.execute(subreq, Params.authcode);
							
				
							
							if (subrsp.isSuccess())
							{		
								Log.info(jobname,"����������" + orderid + "��,�Ӷ�����"+subtids+"�������ɹ�,��ݹ�˾��"+ post_company + "��,��ݵ��š�" + post_no + "��");
							}
							
							sql = "insert into IT_UpNoteBak(Owner,SheetID,SheetType,Sender,Receiver,Notetime,HandleTime,Flag) "
								+ " select Owner , SheetID , SheetType , Sender , Receiver , Notetime , getdate() , 1 from IT_UpNote "
								+ " where SheetID = '"+ sheetid+ "' and SheetType = 3";
							SQLHelper.executeSQL(conn, sql);

							sql = "delete from IT_UpNote where SheetID='"+ sheetid + "' and sheettype=3";

							SQLHelper.executeSQL(conn, sql);
							
							Log.info(jobname,"�������������ڻ򶩵��Ѿ�����,������" + orderid + "��,��ݹ�˾��"+ post_company + "��,��ݵ��š�" + post_no + "��");
						} else if (rsp.getSubMsg().indexOf("�˵��Ų����Ϲ�����Ѿ���ʹ��") >=0)
	                    {
							//��˾�ڲ����ᷢ������
							if ((post_no.toUpperCase().indexOf("1111111")>=0) ||
								(post_no.toUpperCase().indexOf("YJ")>=0))
							{
								sql = "insert into IT_UpNoteBak(Owner,SheetID,SheetType,Sender,Receiver,Notetime,HandleTime,Flag) "
									+ " select Owner , SheetID , SheetType , Sender , Receiver , Notetime , getdate() , 1 from IT_UpNote "
									+ " where SheetID = '"+ sheetid+ "' and SheetType = 3";
								SQLHelper.executeSQL(conn, sql);

								sql = "delete from IT_UpNote where SheetID='"+ sheetid + "' and sheettype=3";

								SQLHelper.executeSQL(conn, sql);
							}
							else
							{
								String cc="";
		                        if (post_no.toUpperCase().indexOf("EH") == 0)
		                        {
		                            cc = "EMS";
		                        }
		                        else if (post_no.toUpperCase().indexOf("101") == 0)
		                        {
		                            cc = "SF";
		                        }
		                        else if (post_no.toUpperCase().indexOf("368") == 0)
		                        {
		                            cc = "STO";
		                        }
		                        else if (post_no.toUpperCase().indexOf("W") == 0)
		                        {
		                            cc = "YTO";
		                        }
		                        else
		                        	cc=post_company;
	
		                        sql = "update ns_delivery set companycode='" + cc + "' where SheetID = '" + sheetid + "'";
		                        SQLHelper.executeSQL(conn, sql);
							}
							/*
							sql = "insert into IT_UpNoteBak(Owner,SheetID,SheetType,Sender,Receiver,Notetime,HandleTime,Flag) "
								+ " select Owner , SheetID , SheetType , Sender , Receiver , Notetime , getdate() , 1 from IT_UpNote "
								+ " where SheetID = '"+ sheetid+ "' and SheetType = 3";
							SQLHelper.executeSQL(conn, sql);

							sql = "delete from IT_UpNote where SheetID='"+ sheetid + "' and sheettype=3";

							SQLHelper.executeSQL(conn, sql);
							*/
	                        Log.info(jobname,"�˵��Ų����Ϲ�����Ѿ���ʹ��,������" + orderid + "��,��ݹ�˾��"+ post_company + "��,��ݵ��š�" + post_no + "��");
	                    }
						else
							Log.info(jobname,"����������" + orderid + "������ʧ��,��ݹ�˾��"+ post_company + "��,��ݵ��š�" + post_no + "��"+"������Ϣ:"+rsp.getSubMsg()+rsp.getMsg());
					}
				
			
			} catch (ApiException e) {
		
				Log.error(jobname,"����������" + orderid + "������ʧ��,��ݹ�˾��"	+ post_company + "��,��ݵ��š�" + post_no	+ "��,������Ϣ:" + e.getMessage());
			}
			catch(SQLException e)
			{
				Log.error(jobname, "���ݷ������ݳ���!"+e.getMessage());
			}
		}
	}
	


	private void resend(Connection conn)  throws Exception
	{
		
		String sql = "select  a.sheetid,b.tid, upper(ltrim(rtrim(b.companycode))) companycode,"
			+" upper(ltrim(rtrim(b.outsid))) outsid from it_upnote a with(nolock), ns_delivery b with(nolock)"
			+ "where a.sheettype=4 and a.sheetid=b.sheetid and a.receiver='"
			+ Params.tradecontactid + "' and b.iswait=0";
		Vector vdeliveryorder=SQLHelper.multiRowSelect(conn, sql);
		for (int i = 0; i < vdeliveryorder.size(); i++) {
			Hashtable hto = (Hashtable) vdeliveryorder.get(i);
			String sheetid = hto.get("sheetid").toString();
			String orderid = hto.get("tid").toString();
			String post_company = hto.get("companycode").toString().trim();
			String post_no = hto.get("outsid").toString().trim();	
			
			//���������˾Ϊ������Դ���
			if (post_company.trim().equals(""))
			{
				Log.warn(jobname, "��ݹ�˾Ϊ�գ�������:"+orderid+"");
				continue;
			}
			
			//���������˾Ϊ������Դ���
			if (post_no.trim().equals(""))
			{
				Log.warn(jobname, "��ݵ���Ϊ�գ�������:"+orderid+"");
				continue;
			}
			
			if (!StringUtil.isNumeric(orderid))
			{
				sql = "insert into IT_UpNoteBak(Owner,SheetID,SheetType,Sender,Receiver,Notetime,HandleTime,Flag) "
					+ " select Owner , SheetID , SheetType , Sender , Receiver , Notetime , getdate() , 1 from IT_UpNote "
					+ " where SheetID = '"+ sheetid+ "' and SheetType = 4";
				SQLHelper.executeSQL(conn, sql);
	
				sql = "delete from IT_UpNote where SheetID='"+ sheetid + "' and sheettype=4";
	
				SQLHelper.executeSQL(conn, sql);
				
				Log.warn(jobname, "�����š�"+orderid+"����ȫ������!");
				continue;
			}
			
			/*
			sql="select count(*) from ns_delivery with(nolock) where tid='"+orderid+"' "
				+"and companycode='"+post_company+"' and outsid='"+post_no+"' and sheettype=3 ";
			if (SQLHelper.intSelect(conn, sql)>0)
			{
				sql = "insert into IT_UpNoteBak(Owner,SheetID,SheetType,Sender,Receiver,Notetime,HandleTime,Flag) "
					+ " select Owner , SheetID , SheetType , Sender , Receiver , Notetime , getdate() , 1 from IT_UpNote "
					+ " where SheetID = '"+ sheetid+ "' and SheetType = 4";
				SQLHelper.executeSQL(conn, sql);

				sql = "delete from IT_UpNote where SheetID='"+ sheetid + "' and sheettype=4";

				SQLHelper.executeSQL(conn, sql);
				
				Log.warn(jobname,"ת����ݹ�˾�͵��Ÿ�ԭ��Ϣ��ͬ,������" + orderid + "��,��ݹ�˾��"+ post_company + "��,��ݵ��š�" + post_no + "��");
				continue;
			}
			
			sql="select count(*) from it_upnotebak a with(nolock),ns_delivery b with(nolock) "
				+"where b.tid='"+orderid+"' and a.sheetid=b.sheetid and a.sheettype=3 ";
			if (SQLHelper.intSelect(conn, sql)==0)
			{
				Log.warn(jobname,"������ԭ������,������" + orderid + "��,��ݹ�˾��"+ post_company + "��,��ݵ��š�" + post_no + "��");
				continue;
			}
			*/
			
			/*
			sql="select handletime from it_upnotebak a with(nolock),ns_delivery b with(nolock) "
				+"where b.tid='"+orderid+"' and a.sheetid=b.sheetid and a.sheettype=3 ";
			Date  handletime=Formatter.parseDate(SQLHelper.strSelect(conn, sql),Formatter.DATE_TIME_FORMAT);
			Calendar calhandletime=Calendar.getInstance();
			calhandletime.setTime(handletime);
			calhandletime.add(Calendar.DAY_OF_YEAR, 1);
			Calendar currtime=Calendar.getInstance();
			
			currtime.setTime(new Date());

			if (calhandletime.compareTo(currtime)<0)
			{
				sql = "insert into IT_UpNoteBak(Owner,SheetID,SheetType,Sender,Receiver,Notetime,HandleTime,Flag) "
					+ " select Owner , SheetID , SheetType , Sender , Receiver , Notetime , getdate() , 1 from IT_UpNote "
					+ " where SheetID = '"+ sheetid+ "' and SheetType = 4";
				SQLHelper.executeSQL(conn, sql);
	
				sql = "delete from IT_UpNote where SheetID='"+ sheetid + "' and sheettype=4";
	
				SQLHelper.executeSQL(conn, sql);
				
				Log.warn(jobname,"ת���ѳ���һ��,������" + orderid + "��,��ݹ�˾��"+ post_company + "��,��ݵ��š�" + post_no + "��");
				continue;
			}
			*/

			try {
				
					TaobaoClient client=new DefaultTaobaoClient(Params.url,Params.appkey, Params.appsecret);
					LogisticsConsignResendRequest req=new LogisticsConsignResendRequest();	
					req.setOutSid(post_no);
					req.setTid(TranTid(orderid));					
					req.setCompanyCode(post_company);
					LogisticsConsignResendResponse rsp = client.execute(req, Params.authcode);
					
					
					if (rsp.isSuccess())
					{			

						try {
							conn.setAutoCommit(false);

							sql = "insert into IT_UpNoteBak(Owner,SheetID,SheetType,Sender,Receiver,Notetime,HandleTime,Flag) "
									+ " select Owner , SheetID , SheetType , Sender , Receiver , Notetime , getdate() , 1 from IT_UpNote "
									+ " where SheetID = '"+ sheetid+ "' and SheetType = 4";
							SQLHelper.executeSQL(conn, sql);

							sql = "delete from IT_UpNote where SheetID='"+ sheetid + "' and sheettype=4";

							SQLHelper.executeSQL(conn, sql);
							conn.commit();
							conn.setAutoCommit(true);
						} catch (SQLException sqle) {
							if (!conn.getAutoCommit())
								try {
									conn.rollback();
								} catch (Exception e1) {
								}
							try {
								conn.setAutoCommit(true);
							} catch (Exception e1) {
							}
							throw new JSQLException(sql, sqle);
						}
						Log.info(jobname,"����������" + orderid + "�������ɹ�,��ݹ�˾��"+ post_company + "��,��ݵ��š�" + post_no + "��");
					}
					else
					{		
						
						if (rsp.getSubMsg().indexOf("�����ظ�����")>=0|| rsp.getSubMsg().indexOf("�������Ͳ�ƥ��")>=0)
						{
							sql = "insert into IT_UpNoteBak(Owner,SheetID,SheetType,Sender,Receiver,Notetime,HandleTime,Flag) "
								+ " select Owner , SheetID , SheetType , Sender , Receiver , Notetime , getdate() , 1 from IT_UpNote "
								+ " where SheetID = '"+ sheetid+ "' and SheetType = 4";
							SQLHelper.executeSQL(conn, sql);

							sql = "delete from IT_UpNote where SheetID='"+ sheetid + "' and sheettype=4";

							SQLHelper.executeSQL(conn, sql);
							Log.info(jobname,"������" + orderid + "�������ظ�����,��ݹ�˾��"+ post_company + "��,��ݵ��š�" + post_no + "��");
						}
						else if((rsp.getSubMsg().indexOf("û��Ȩ�޽��з���")>=0)||rsp.getSubMsg().indexOf("û��Ȩ�޷���")>=0 
								||rsp.getSubMsg().indexOf("��ǰ����״̬��֧���޸�")>=0 ) 
						{
							sql = "insert into IT_UpNoteBak(Owner,SheetID,SheetType,Sender,Receiver,Notetime,HandleTime,Flag) "
								+ " select Owner , SheetID , SheetType , Sender , Receiver , Notetime , getdate() , 1 from IT_UpNote "
								+ " where SheetID = '"+ sheetid+ "' and SheetType = 4";
							SQLHelper.executeSQL(conn, sql);

							sql = "delete from IT_UpNote where SheetID='"+ sheetid + "' and sheettype=4";

							SQLHelper.executeSQL(conn, sql);
							Log.info(jobname,"û��Ȩ�޷���,������" + orderid + "��,��ݹ�˾��"+ post_company + "��,��ݵ��š�" + post_no + "��");
							
						}
						else if (rsp.getSubMsg().indexOf("��������������") >=0 || rsp.getSubMsg().indexOf("�����Ѿ�����") >=0
								 || rsp.getSubMsg().indexOf("��ǰ�����Ķ����ǲ𵥶���") >=0)
						{
							TaobaoClient subclient=new DefaultTaobaoClient(Params.url,Params.appkey, Params.appsecret);
							LogisticsOfflineSendRequest subreq=new LogisticsOfflineSendRequest();	
							subreq.setOutSid(post_no);
							subreq.setTid(TranTid(orderid));
							subreq.setCompanyCode(post_company);
							subreq.setIsSplit(1L);
							String subtids="";
							
							sql="select oid from customerorderitem a with(nolock),customerorder b with(nolock)," 
									+"customerdelive c with(nolock) where a.sheetid=b.sheetid and a.sheetid=c.refsheetid "
									+"and c.customersheetid='"+orderid+"' and c.delivery='"+post_company+"' "
									+"and c.deliverysheetid='"+post_no+"'";
							List sublist=SQLHelper.multiRowListSelect(conn, sql);
							for(Iterator it=sublist.iterator();it.hasNext();)
							{
								String oid=(String) it.next();
								subtids=oid+","+subtids;
							}
							
							subtids=subtids.substring(0, subtids.length()-1);
							
							subreq.setSubTid(subtids);
							
							LogisticsOfflineSendResponse subrsp = client.execute(subreq, Params.authcode);
							if (subrsp.isSuccess())
							{		
								Log.info(jobname,"����������" + orderid + "��,�Ӷ�����"+subtids+"�������ɹ�,��ݹ�˾��"+ post_company + "��,��ݵ��š�" + post_no + "��");
							}
							
							sql = "insert into IT_UpNoteBak(Owner,SheetID,SheetType,Sender,Receiver,Notetime,HandleTime,Flag) "
								+ " select Owner , SheetID , SheetType , Sender , Receiver , Notetime , getdate() , 1 from IT_UpNote "
								+ " where SheetID = '"+ sheetid+ "' and SheetType = 3";
							SQLHelper.executeSQL(conn, sql);

							sql = "delete from IT_UpNote where SheetID='"+ sheetid + "' and sheettype=3";

							SQLHelper.executeSQL(conn, sql);
							Log.info(jobname,"�������������ڻ򶩵��Ѿ�����,������" + orderid + "��,��ݹ�˾��"+ post_company + "��,��ݵ��š�" + post_no + "��");
						} else if (rsp.getSubMsg().indexOf("�˵��Ų����Ϲ�����Ѿ���ʹ��") >=0)
	                    {
							//��˾�ڲ����ᷢ������
							if ((post_no.toUpperCase().indexOf("1111111")>=0) ||
								(post_no.toUpperCase().indexOf("YJ")>=0))
							{
								sql = "insert into IT_UpNoteBak(Owner,SheetID,SheetType,Sender,Receiver,Notetime,HandleTime,Flag) "
									+ " select Owner , SheetID , SheetType , Sender , Receiver , Notetime , getdate() , 1 from IT_UpNote "
									+ " where SheetID = '"+ sheetid+ "' and SheetType = 4";
								SQLHelper.executeSQL(conn, sql);

								sql = "delete from IT_UpNote where SheetID='"+ sheetid + "' and sheettype=4";

								SQLHelper.executeSQL(conn, sql);
							}
							else
							{
								String cc="";
		                        if (post_no.toUpperCase().indexOf("EH") == 0)
		                        {
		                            cc = "EMS";
		                        }
		                        else if (post_no.toUpperCase().indexOf("101") == 0)
		                        {
		                            cc = "SF";
		                        }
		                        else if (post_no.toUpperCase().indexOf("368") == 0)
		                        {
		                            cc = "STO";
		                        }
		                        else if (post_no.toUpperCase().indexOf("W") == 0)
		                        {
		                            cc = "YTO";
		                        }
		                        else
		                        	cc=post_company;
	
		                        sql = "update ns_delivery set companycode='" + cc + "' where SheetID = '" + sheetid + "'";
		                        SQLHelper.executeSQL(conn, sql);
							}
							/*
							sql = "insert into IT_UpNoteBak(Owner,SheetID,SheetType,Sender,Receiver,Notetime,HandleTime,Flag) "
								+ " select Owner , SheetID , SheetType , Sender , Receiver , Notetime , getdate() , 1 from IT_UpNote "
								+ " where SheetID = '"+ sheetid+ "' and SheetType = 4";
							SQLHelper.executeSQL(conn, sql);

							sql = "delete from IT_UpNote where SheetID='"+ sheetid + "' and sheettype=4";

							SQLHelper.executeSQL(conn, sql);
							*/
	                        Log.info(jobname,"�˵��Ų����Ϲ�����Ѿ���ʹ��,������" + orderid + "��,��ݹ�˾��"+ post_company + "��,��ݵ��š�" + post_no + "��");
	                    }
						else
							Log.info(jobname,"����������" + orderid + "������ʧ��,��ݹ�˾��"+ post_company + "��,��ݵ��š�" + post_no + "��"+"������Ϣ:"+rsp.getSubMsg()+rsp.getMsg());
					}
				
			
			} catch (ApiException e) {
		
				Log.error(jobname,"����������" + orderid + "������ʧ��,��ݹ�˾��"	+ post_company + "��,��ݵ��š�" + post_no	+ "��,������Ϣ:" + e.getMessage());
			}
			catch(SQLException e)
			{
				Log.error(jobname, "���ݷ������ݳ���!"+e.getMessage());
			}
		}
	}
	
	
    private long TranTid(String tid)
    {
        tid = tid.trim();
        tid = tid.toLowerCase();
        String t = "";
        for (int i=0; i<tid.length();i++)
        {
        	char c=tid.charAt(i);
            if ((c >= 48) && (c <= 57))
            {
                t = t + c;
            }
        }

        long id = 0;
        if (t != "")
        {
            id = Long.parseLong(t);
        }
        return id;
    }
	
	public String toString()
	{
		return jobname + " " + (is_exporting ? "[exporting]" : "[waiting]");
	}
}
