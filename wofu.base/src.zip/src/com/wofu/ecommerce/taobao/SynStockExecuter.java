package com.wofu.ecommerce.taobao;

import java.sql.Connection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.taobao.api.ApiException;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.domain.Item;
import com.taobao.api.request.ItemGetRequest;

import com.taobao.api.request.ItemsInventoryGetRequest;
import com.taobao.api.request.ItemsOnsaleGetRequest;
import com.taobao.api.response.ItemGetResponse;
import com.taobao.api.response.ItemsInventoryGetResponse;
import com.taobao.api.response.ItemsOnsaleGetResponse;
import com.wofu.business.stock.StockManager;
import com.wofu.common.tools.sql.PoolHelper;
import com.wofu.common.tools.sql.SQLHelper;
import com.wofu.common.tools.util.DOMHelper;
import com.wofu.common.tools.util.JException;
import com.wofu.common.tools.util.StringUtil;
import com.wofu.common.tools.util.log.Log;
import com.wofu.base.job.timer.TimerJob;
import com.wofu.base.job.Executer;


public class SynStockExecuter extends Executer {
	
	private String url="";

	private String appkey="";

	private String appsecret="";

	private String authcode="";

	private String tradecontactid="";

	private String dbname="";
	
	private String username="";
	
	private String status="";


	public void execute() throws Exception {
		// TODO Auto-generated method stub
		TimerJob job=(TimerJob) this.getExecuteobj();
		Properties prop=StringUtil.getStringProperties(job.getParams());
		
		url=prop.getProperty("url");
		appkey=prop.getProperty("appkey");
		appsecret=prop.getProperty("appsecret");
		authcode=prop.getProperty("authcode");
		tradecontactid=prop.getProperty("tradecontactid");
		dbname=prop.getProperty("dbname");
		username=prop.getProperty("username");
		status=prop.getProperty("status");
		
		Connection conn=null;
		try {			 
			conn= PoolHelper.getInstance().getConnection(dbname);
			//if (job.getNotes().indexOf("����")>=0)		
			//		authcode=TaoBaoUtils.getToken(conn, tradecontactid, appkey, appsecret);
			if (status.equalsIgnoreCase("onsale"))
				SynOnSaleStock(conn);
			else
			{
				SynInStockStock(conn,"for_shelved");
				SynInStockStock(conn,"sold_out");
			}
		}catch (ApiException e) {
			//Log.error("����Ա�δ�붩��","����Զ�̷���ʧ��,������Ϣ:" + e.getMessage());
			throw new JException("����Զ�̷���ʧ��,������Ϣ:" + e.getMessage());
			
		} catch (Exception e) {
			try {
				if (conn != null && !conn.getAutoCommit())
					conn.rollback();
			} catch (Exception e1) {
				throw new JException("�ع�����ʧ��");
			}
			throw new JException("ͬ���Ա����"+Log.getErrorMessage(e));
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				throw new JException("�ر����ݿ�����ʧ��");
			}
		}
		
	
	}
	
	private void SynOnSaleStock(Connection conn) throws Exception
	{
		int i=0;
		int j=0;
		long pageno=1L;
		
		Log.info(username,"��ʼͬ���ϼ���Ʒ���");
		String sql="select orgid from ecs_tradecontactorgcontrast with(nolock) where tradecontactid="+tradecontactid;
		int orgid=SQLHelper.intSelect(conn, sql);
		
		for (int k=0;k<20;)
		{
			try
			{
				TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
				ItemsOnsaleGetRequest reqitems=new ItemsOnsaleGetRequest();
				reqitems.setFields("num_iid,modified,outer_id,title,approve_status");	
				reqitems.setPageNo(pageno);
				reqitems.setPageSize(40L);
				ItemsOnsaleGetResponse rspitems = client.execute(reqitems , authcode);				
				
				Document doc = DOMHelper.newDocument(rspitems.getBody(), "GBK");
		           
				Element urlset = doc.getDocumentElement();
				
				while(true)
				{				
					
					
					if (!DOMHelper.ElementIsExists(urlset, "items") || (rspitems.getItems().size()<=0)|| rspitems.getItems()==null)
					{
						k=20;
						break;
					}
					for(Iterator ititems=rspitems.getItems().iterator();ititems.hasNext();)
					{
						i=i+1;
						Item item=(Item) ititems.next();
						long num_iid=item.getNumIid();
						
						Log.info("��ƷID:"+item.getNumIid()+" ����:"+item.getOuterId()+" ״̬:"+item.getApproveStatus());
						
						if (item.getTitle().indexOf("Ʒ������")>=0) continue;
												
						
						ItemGetRequest reqitem=new ItemGetRequest();
						reqitem.setFields("num_iid,outer_id,title,num,sku.num_iid,sku.sku_id,sku.quantity,sku.outer_id,sku.status");
						reqitem.setNumIid(num_iid);
						ItemGetResponse rspitem = client.execute(reqitem , authcode);
						
						
						long quantity=rspitem.getItem().getNum();
						
						Document itemdoc = DOMHelper.newDocument(rspitem.getBody(), "GBK");
				           
						Element itemele = (Element) itemdoc.getDocumentElement().getElementsByTagName("item").item(0);
						
						if (!DOMHelper.ElementIsExists(itemele, "skus")) 
						{
							Log.info(username,"SKU:"+rspitem.getItem().getOuterId()+" ԭ���:"+String.valueOf(rspitem.getItem().getNum()));
							
		
							
							if (rspitem.getItem().getOuterId()!=null)
							{
								String sku=rspitem.getItem().getOuterId();
								
								boolean ismulti=false;
								
								sql="select count(*) from barcode with(nolock) where custombc='"+sku+"'";
								if (SQLHelper.intSelect(conn, sql)==0)
								{
									sql="select count(*) from MultiSKURef where refcustomercode='"+sku+"'";
									if (SQLHelper.intSelect(conn, sql)==0)
									{
										Log.warn(username,"�Ҳ���SKU��"+sku+"����Ӧ������,��Ʒ����:"+rspitem.getItem().getTitle());									
										continue;
									}
									
									ismulti=true;
								}
								
								
								sql="select count(*) from ecs_stockconfig with(nolock) "
									+"where orgid="+orgid+" and sku='"+sku+"'";
								if (SQLHelper.intSelect(conn, sql)==0)
								{
									StockManager.StockConfig(conn, sku, Integer.parseInt(tradecontactid)) ;
									Log.info("�ϼ���Ʒδ���þ�����,SKU:"+sku);
								}
								
								sql="select alarmqty,isneedsyn,addstockqty from ecs_stockconfig with(nolock) "
									+"where orgid="+orgid+" and sku='"+sku+"'";
								Hashtable ht=SQLHelper.oneRowSelect(conn, sql);
								
								int alarmqty=Integer.valueOf(ht.get("alarmqty").toString());
								int isneedsyn=Integer.valueOf(ht.get("isneedsyn").toString());
								int addstockqty=Integer.valueOf(ht.get("addstockqty").toString());
								
								if (isneedsyn==0)
								{
									Log.info(username,"���ò���Ҫͬ�����,SKU:"+sku);
									continue;  //����Ҫͬ��
								}
								
								Hashtable<String,String> htskuinfo=new Hashtable<String,String>();
						
								int qty =0;
								
								if (ismulti)
								{
									int minqty=1000000;
									sql="select customercode from MultiSKURef where refcustomercode='"+sku+"'";
									List multiskulist=SQLHelper.multiRowListSelect(conn, sql);
									for(Iterator it=multiskulist.iterator();it.hasNext();)
									{
										String customercode=(String) it.next();
										qty=StockManager.getTradeContactUseableStock(conn, Integer.valueOf(tradecontactid).intValue(), customercode);
										
										if (qty<minqty)
										{
											minqty=qty;
										}
									}
									
									qty=minqty;
								}
								else
								{
									qty=StockManager.getTradeContactUseableStock(conn, Integer.valueOf(tradecontactid).intValue(), sku);
								}
								
								if (qty<0) qty=0;

								//������ÿ����������ӵĿ��С�ڵ��ھ�����,�򽫿��ͬ��Ϊ0
								if ((qty+addstockqty)<=alarmqty)
								{
									if (quantity!=0)
									{
										htskuinfo.put("type", "1");
										htskuinfo.put("sku", sku);		
										htskuinfo.put("numiid", String.valueOf(num_iid));							
										htskuinfo.put("outerid", sku);
										htskuinfo.put("quantity", String.valueOf(quantity));
										htskuinfo.put("qty", "0");
										
										//���¾���״̬
										sql="update ecs_stockconfig set alarmstatus=1,alarmtime=getdate() "
											+"where orgid="+orgid+" and sku='"+sku+"'";
										SQLHelper.executeSQL(conn, sql);
										Log.info(username,"��Ʒ����Ѵﵽ������:"+alarmqty+",SKU:"+sku);
									}
								}
								else
								{
									htskuinfo.put("type", "1");
									htskuinfo.put("sku", sku);		
									htskuinfo.put("numiid", String.valueOf(num_iid));							
									htskuinfo.put("outerid", sku);
									htskuinfo.put("quantity", String.valueOf(quantity));
									htskuinfo.put("qty", String.valueOf(qty+addstockqty));
									
									sql="update ecs_stockconfig set alarmstatus=0 "
										+"where orgid="+orgid+" and sku='"+sku+"'";
									SQLHelper.executeSQL(conn, sql);
									Log.info(username,"��Ʒ�������,SKU:"+sku);
								}
								
								if (htskuinfo.keySet().size()>0)
								{
									sql="update ecs_stockconfig set stockcount="+htskuinfo.get("qty").toString()
									+" where orgid="+orgid+" and sku='"+sku+"'";
									SQLHelper.executeSQL(conn, sql);
									
									htskuinfo.put("status", "onsale");
									StockUtils.updateStock(username,"0000000000",url,appkey,appsecret,authcode,htskuinfo,false);
								}
							
							}
						}
						else
						{
							for(Iterator it=rspitem.getItem().getSkus().iterator();it.hasNext();)
							{
								j=j+1;
								com.taobao.api.domain.Sku skuinfo=(com.taobao.api.domain.Sku) it.next();
											
								
								if (skuinfo.getOuterId()!=null)
								{
									
									Log.info(username,"SKU:"+skuinfo.getOuterId()+" ԭ���:"+String.valueOf(skuinfo.getQuantity()));
									
									String sku=skuinfo.getOuterId();
									quantity=skuinfo.getQuantity();
									
		
								
									boolean ismulti=false;
									
									sql="select count(*) from barcode with(nolock) where custombc='"+sku+"'";
									if (SQLHelper.intSelect(conn, sql)==0)
									{
										sql="select count(*) from MultiSKURef where refcustomercode='"+sku+"'";
										if (SQLHelper.intSelect(conn, sql)==0)
										{
											Log.warn(username,"�Ҳ���SKU��"+sku+"����Ӧ������,��Ʒ����:"+rspitem.getItem().getTitle());									
											continue;
										}
										
										ismulti=true;
									}
									
							
									
									sql="select count(*) from ecs_stockconfig with(nolock) "
										+"where orgid="+orgid+" and sku='"+sku+"'";
									if (SQLHelper.intSelect(conn, sql)==0)
									{
										StockManager.StockConfig(conn, sku, Integer.parseInt(tradecontactid)) ;
										Log.info("�ϼ���Ʒδ���þ�����,SKU:"+sku);
									}
										
					
									sql="select alarmqty,isneedsyn,addstockqty from ecs_stockconfig with(nolock) "
										+"where orgid="+orgid+" and sku='"+sku+"'";
									Hashtable ht=SQLHelper.oneRowSelect(conn, sql);
									
									int alarmqty=Integer.valueOf(ht.get("alarmqty").toString());
									int isneedsyn=Integer.valueOf(ht.get("isneedsyn").toString());
									int addstockqty=Integer.valueOf(ht.get("addstockqty").toString());
									
									if (isneedsyn==0)
									{
										Log.info(username,"���ò���Ҫͬ�����,SKU:"+sku);
										continue;  //����Ҫͬ��
									}
									
									Hashtable<String,String> htskuinfo=new Hashtable<String,String>();
									
									int qty =0;
							
									
									if (ismulti)
									{
										int minqty=1000000;
										sql="select customercode from MultiSKURef where refcustomercode='"+sku+"'";
										List multiskulist=SQLHelper.multiRowListSelect(conn, sql);
										for(Iterator itmulti=multiskulist.iterator();itmulti.hasNext();)
										{
											String customercode=(String) itmulti.next();
											qty=StockManager.getTradeContactUseableStock(conn, Integer.valueOf(tradecontactid).intValue(), customercode);
											
											if (qty<minqty)
											{
												minqty=qty;
											}
										}
										
										qty=minqty;
									}
									else
									{
										qty=StockManager.getTradeContactUseableStock(conn, Integer.valueOf(tradecontactid).intValue(), sku);
									}
								
									
									//������ÿ����������ӵĿ��С�ڵ��ھ�����,�򽫿��ͬ��Ϊ0
									if ((qty+addstockqty)<=alarmqty)
									{
										
										htskuinfo.put("type", "1");
										htskuinfo.put("sku", sku);
										htskuinfo.put("skuid", String.valueOf(skuinfo.getSkuId()));
										htskuinfo.put("numiid", String.valueOf(num_iid));							
										htskuinfo.put("outerid", sku);
										htskuinfo.put("quantity", String.valueOf(quantity));
										htskuinfo.put("qty", "0");
										
										//���¾���״̬
										sql="update ecs_stockconfig set alarmstatus=1,alarmtime=getdate() "
											+"where orgid="+orgid+" and sku='"+sku+"'";
										SQLHelper.executeSQL(conn, sql);
										Log.info(username,"��Ʒ����Ѵﵽ������:"+alarmqty+",SKU:"+sku);
										
									}
									else
									{								
										htskuinfo.put("type", "1");
										htskuinfo.put("sku", sku);
										htskuinfo.put("skuid", String.valueOf(skuinfo.getSkuId()));
										htskuinfo.put("numiid", String.valueOf(num_iid));							
										htskuinfo.put("outerid", sku);
										htskuinfo.put("quantity", String.valueOf(quantity));
										htskuinfo.put("qty", String.valueOf(qty+addstockqty));
										
										sql="update ecs_stockconfig set alarmstatus=0 "
											+"where orgid="+orgid+" and sku='"+sku+"'";
										SQLHelper.executeSQL(conn, sql);
										Log.info(username,"��Ʒ�������,SKU:"+sku);
									}
									
									if (htskuinfo.keySet().size()>0)
									{
										sql="update ecs_stockconfig set stockcount="+htskuinfo.get("qty").toString()
										+" where orgid="+orgid+" and sku='"+sku+"'";
										SQLHelper.executeSQL(conn, sql);
										
										htskuinfo.put("status", "onsale");
										StockUtils.updateStock(username,"0000000000",url,appkey,appsecret,authcode,htskuinfo,true);
									}
									
								}
							
							}
						}
					}
					if (pageno==(Double.valueOf(Math.ceil(rspitems.getTotalResults()/40.0))).intValue()) break;
					
					Log.info("ҳ��:"+reqitems.getPageNo());
					pageno=pageno+1;
					reqitems.setPageNo(pageno);			
					rspitems=client.execute(reqitems , authcode);	
					k=0;
				}
				Log.info("�������Ʒ��:"+String.valueOf(i)+" ��SKU��:"+String.valueOf(j));
				break;
			
			} catch (Exception e) {
				if (++k >= 20)
					throw e;
				Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
			
				Thread.sleep(10000L);
			} 
		}
	}
	

	private void SynInStockStock(Connection conn,String banner) throws Exception
	{
		int i=0;
		int j=0;
		long pageno=1L;
		
		Log.info(username,"��ʼͬ���ֿ���Ʒ���");
		
		String sql="select orgid from ecs_tradecontactorgcontrast with(nolock) where tradecontactid="+tradecontactid;
		int orgid=SQLHelper.intSelect(conn, sql);
		
		for (int k=0;k<10;)
		{
			try
			{
				TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
				ItemsInventoryGetRequest reqitems=new ItemsInventoryGetRequest();
				reqitems.setFields("num_iid,modified,outer_id,title");	
				reqitems.setBanner(banner);
				reqitems.setPageNo(pageno);
				reqitems.setPageSize(40L);
				ItemsInventoryGetResponse rspitems = client.execute(reqitems , authcode);
			
	
				
				Document doc = DOMHelper.newDocument(rspitems.getBody(), "GBK");
		           
				Element urlset = doc.getDocumentElement();
				
				while(true)
				{				
					
					
					if (!DOMHelper.ElementIsExists(urlset, "items") || (rspitems.getItems().size()<=0)|| rspitems.getItems()==null)
					{
						k=10;
						break;
					}
					for(Iterator ititems=rspitems.getItems().iterator();ititems.hasNext();)
					{
						i=i+1;
						Item item=(Item) ititems.next();
						long num_iid=item.getNumIid();
						
						if (item.getTitle().indexOf("Ʒ������")>=0) continue;
						
						ItemGetRequest reqitem=new ItemGetRequest();
						reqitem.setFields("num_iid,outer_id,num,sku.num_iid,sku.sku_id,sku.quantity,sku.outer_id,sku.status");
						reqitem.setNumIid(num_iid);
						ItemGetResponse rspitem = client.execute(reqitem , authcode);
						
						
						if (rspitem.getBody().indexOf("sub_msg")>=0)
							if (rspitem.getSubMsg().equalsIgnoreCase("��ȡ������Ʒʧ��")) continue;
						
						long quantity=rspitem.getItem().getNum();
						
						Document itemdoc = DOMHelper.newDocument(rspitem.getBody(), "GBK");
				           
										
							
						Element itemele = (Element) itemdoc.getDocumentElement().getElementsByTagName("item").item(0);
						
						if (!DOMHelper.ElementIsExists(itemele, "skus")) 
						{
							Log.info(username,"SKU:"+rspitem.getItem().getOuterId()+" ԭ���:"+String.valueOf(rspitem.getItem().getNum()));
							
							if (rspitem.getItem().getOuterId()!=null)
							{
								String sku=rspitem.getItem().getOuterId();
								
								sql="select count(*) from barcode with(nolock) where custombc='"+sku+"'";
								if (SQLHelper.intSelect(conn, sql)==0)
								{
									Log.warn(username,"�Ҳ���SKU��"+sku+"����Ӧ������,���ţ�"+rspitem.getItem().getOuterId()+" ��Ʒ����:"+rspitem.getItem().getTitle());
									sql="insert into ecs_notfund(customno,custombc,title) values('"+rspitem.getItem().getOuterId()+"','"+sku+"','"+rspitem.getItem().getTitle()+"')";
									SQLHelper.executeSQL(conn, sql);
									continue;
								}
								
								sql="select count(*) from ecs_stockconfig with(nolock) where orgid="+orgid+" and sku='"+sku+"'";
								if (SQLHelper.intSelect(conn, sql)>0)
								{
									sql="select isneedsyn from ecs_stockconfig with(nolock) where orgid="+orgid+" and sku='"+sku+"'";
									int isneedsyn=SQLHelper.intSelect(conn, sql);
									
									if (isneedsyn==0) continue;
								}

								Hashtable<String,String> htskuinfo=new Hashtable<String,String>();
								htskuinfo.put("type", "1");
								htskuinfo.put("sku", sku);
				
								htskuinfo.put("numiid", String.valueOf(num_iid));							
								htskuinfo.put("outerid", sku);
								htskuinfo.put("quantity", String.valueOf(quantity));
								
								int qty=StockManager.getTradeContactUseableStock(conn, Integer.valueOf(tradecontactid).intValue(), sku);
								
								if (qty<0) qty=0;
								
						
								
								htskuinfo.put("qty", String.valueOf(qty));
								htskuinfo.put("status", "instock");	
								
								sql="update ecs_stockconfig set stockcount="+htskuinfo.get("qty").toString()
								+" where orgid="+orgid+" and sku='"+sku+"'";
								SQLHelper.executeSQL(conn, sql);
								
								StockUtils.updateStock(username,"0000000000",url,appkey,appsecret,authcode,htskuinfo,false);
							
							}
						}
						else
						{
							for(Iterator it=rspitem.getItem().getSkus().iterator();it.hasNext();)
							{
								j=j+1;
								com.taobao.api.domain.Sku skuinfo=(com.taobao.api.domain.Sku) it.next();
											
								
								if (skuinfo.getOuterId()!=null)
								{
									
									Log.info(username,"SKU:"+skuinfo.getOuterId()+" ԭ���:"+String.valueOf(skuinfo.getQuantity()));
									
									String sku=skuinfo.getOuterId();
									quantity=skuinfo.getQuantity();
								
									sql="select count(*) from barcode with(nolock) where custombc='"+sku+"'";
									if (SQLHelper.intSelect(conn, sql)==0)
									{
										Log.warn(username,"�Ҳ���SKU��"+sku+"����Ӧ������,���ţ�"+rspitem.getItem().getOuterId()+" ��Ʒ����:"+rspitem.getItem().getTitle());
										sql="insert into ecs_notfund(customno,custombc,title) values('"+rspitem.getItem().getOuterId()+"','"+sku+"','"+rspitem.getItem().getTitle()+"')";
										SQLHelper.executeSQL(conn, sql);
										continue;
									}
									
									sql="select count(*) from ecs_stockconfig with(nolock) where orgid="+orgid+" and sku='"+sku+"'";
									if (SQLHelper.intSelect(conn, sql)>0)
									{
										sql="select isneedsyn from ecs_stockconfig with(nolock) where orgid="+orgid+" and sku='"+sku+"'";
										int isneedsyn=SQLHelper.intSelect(conn, sql);
										
										if (isneedsyn==0) continue;
									}

									
									Hashtable<String,String> htskuinfo=new Hashtable<String,String>();
									htskuinfo.put("type", "1");
									htskuinfo.put("sku", sku);
									htskuinfo.put("skuid", String.valueOf(skuinfo.getSkuId()));
									htskuinfo.put("numiid", String.valueOf(num_iid));							
									htskuinfo.put("outerid", sku);
									htskuinfo.put("quantity", String.valueOf(quantity));
									
									int qty=StockManager.getTradeContactUseableStock(conn, Integer.valueOf(tradecontactid).intValue(), sku);
									if (qty<0) qty=0;
									
									htskuinfo.put("qty", String.valueOf(qty));
									htskuinfo.put("status", "instock");	
									
									sql="update ecs_stockconfig set stockcount="+htskuinfo.get("qty").toString()
									+" where orgid="+orgid+" and sku='"+sku+"'";
									SQLHelper.executeSQL(conn, sql);
									
									StockUtils.updateStock(username,"0000000000",url,appkey,appsecret,authcode,htskuinfo,true);
								}
							
							}
						}
					}
					if (pageno==(Double.valueOf(Math.ceil(rspitems.getTotalResults()/40.0))).intValue()) break;
					
					Log.info("ҳ��:"+reqitems.getPageNo());
					pageno=pageno+1;
					reqitems.setPageNo(pageno);			
					rspitems=client.execute(reqitems , authcode);	
					k=0;
				}
				Log.info("�������Ʒ��:"+String.valueOf(i)+" ��SKU��:"+String.valueOf(j));
				break;
			
			} catch (Exception e) {
				if (++k >= 10)
					throw e;
				Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
			
				Thread.sleep(10000L);
			} 
		}
	}
	
}
