package com.wofu.ecommerce.taobao;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.domain.Cooperation;
import com.taobao.api.domain.Order;
import com.taobao.api.domain.PurchaseOrder;
import com.taobao.api.domain.SubPurchaseOrder;
import com.taobao.api.domain.Trade;

import com.taobao.api.request.FenxiaoCooperationGetRequest;
import com.taobao.api.request.FenxiaoDistributorsGetRequest;
import com.taobao.api.request.FenxiaoOrdersGetRequest;
import com.taobao.api.request.TradesSoldIncrementGetRequest;

import com.taobao.api.response.FenxiaoCooperationGetResponse;
import com.taobao.api.response.FenxiaoDistributorsGetResponse;
import com.taobao.api.response.FenxiaoOrdersGetResponse;
import com.taobao.api.response.TradesSoldIncrementGetResponse;
import com.wofu.common.tools.sql.PoolHelper;
import com.wofu.common.tools.sql.SQLHelper;

import com.wofu.common.tools.util.DOMHelper;
import com.wofu.common.tools.util.Formatter;
import com.wofu.common.tools.util.JException;

import com.wofu.common.tools.util.log.Log;
import com.wofu.business.stock.StockManager;
import com.wofu.business.util.PublicUtils;
import com.wofu.business.order.OrderManager;

public class getDistributor extends Thread {

	private static String jobname = "��ȡ�Ա�����ȡ��������ҵ";
	
	private static long daymillis=24*60*60*1000L;
	
	private static String lasttimeconfvalue=Params.username+"����ȡ����������ʱ��";
	
	SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
	
	private boolean is_importing=false;
	
	private String lasttime;


	public getDistributor() {
		setDaemon(true);
		setName(jobname);
	}

	public void run() {
		Log.info(jobname, "����[" + jobname + "]ģ��");
		do {		
			Connection connection = null;
			is_importing = true;
			try {												
				connection = PoolHelper.getInstance().getConnection(
						com.wofu.ecommerce.taobao.Params.dbname);
				lasttime=PublicUtils.getConfig(connection,lasttimeconfvalue,"");
				//if (Params.isdistribution)
				//	Params.authcode=TaoBaoUtils.getToken(connection, Params.tradecontactid, Params.appkey, Params.appsecret);
					
				getDistributor(connection);
			} catch (Exception e) {
				try {
					if (connection != null && !connection.getAutoCommit())
						connection.rollback();
				} catch (Exception e1) {
					Log.error(jobname, "�ع�����ʧ��");
				}
				Log.error("105", jobname, Log.getErrorMessage(e));
			} finally {
				is_importing = false;
				try {
					if (connection != null)
						connection.close();
				} catch (Exception e) {
					Log.error(jobname, "�ر����ݿ�����ʧ��");
				}
			}
			System.gc();
			long startwaittime = System.currentTimeMillis();
			while (System.currentTimeMillis() - startwaittime < (long) (com.wofu.ecommerce.taobao.Params.waittime * 1000))		
				try {
					sleep(1000L);
				} catch (Exception e) {
					Log.warn(jobname, "ϵͳ��֧�����߲���, ��ҵ������Ӱ���������");
				}
		} while (true);
	}

	
	/*
	 * ��ȡһ��֮������ж���
	 */
	private void getDistributor(Connection conn) throws Exception
	{		
		long pageno=1L;
		Date modified=Formatter.parseDate(lasttime,Formatter.DATE_TIME_FORMAT);
		for(int k=0;k<10;)
		{
			try
			{
				TaobaoClient client=new DefaultTaobaoClient(Params.url,Params.appkey, Params.appsecret,"xml");
				FenxiaoCooperationGetRequest req=new FenxiaoCooperationGetRequest();		
				Date startdate=new Date(Formatter.parseDate(lasttime,Formatter.DATE_TIME_FORMAT).getTime()+1000L);
				Date enddate=new Date(Formatter.parseDate(lasttime,Formatter.DATE_TIME_FORMAT).getTime()+daymillis);
				//req.setStartDate(startdate);
				//req.setEndDate(enddate);
				req.setPageNo(pageno);
				req.setPageSize(40L);
				FenxiaoCooperationGetResponse response = client.execute(req , Params.authcode);
				
		
				int i=1;
			
				while(true)
				{
								
					if (response.getCooperations()==null || response.getCooperations().size()<=0)
					{				
						if (i==1)		
						{
							try
							{
								//��һ��֮�ڶ�ȡ�������������ҵ�ǰ����������죬��ȡ��������ʱ�����Ϊ��ǰ������
								if (this.dateformat.parse(Formatter.format(new Date(), Formatter.DATE_FORMAT)).
										compareTo(this.dateformat.parse(Formatter.format(Formatter.parseDate(PublicUtils.getConfig(conn,lasttimeconfvalue,""),Formatter.DATE_TIME_FORMAT),Formatter.DATE_FORMAT)))>0)
								{
									try
				                	{
										String value=Formatter.format((new Date(Formatter.parseDate(PublicUtils.getConfig(conn,lasttimeconfvalue,""),Formatter.DATE_TIME_FORMAT).getTime()+daymillis)),Formatter.DATE_FORMAT)+" 00:00:00";
										PublicUtils.setConfig(conn, lasttimeconfvalue, value);			    
				                	}catch(JException je)
				                	{
				                		Log.error(jobname, je.getMessage());
				                	}
								}
							}catch(ParseException e)
							{
								Log.error(jobname, "�����õ����ڸ�ʽ!"+e.getMessage());
							}
						}
						break;
					}
					
					
					
					for(Iterator it=response.getCooperations().iterator();it.hasNext();)
					{
						Cooperation cop=(Cooperation) it.next();
												
						Log.info(cop.getDistributorId()+" "+cop.getDistributorNick()+" "+Formatter.format(cop.getStartDate(),Formatter.DATE_TIME_FORMAT));
						
						String shopname=getDistributorShopName(cop.getDistributorNick());
						
						
						String sql="select count(*) from ecs_distributor with(nolock) where distributorid="+cop.getDistributorId();
						if (SQLHelper.intSelect(conn, sql)==0)
						{
							sql="insert into ecs_distributor(distributorid,distributorname,startdate,shopname,manager,creator,operator,updator) "
								+"values("+cop.getDistributorId()+",'"+cop.getDistributorNick()+"','"
								+Formatter.format(cop.getStartDate(),Formatter.DATE_TIME_FORMAT)+"','"+shopname+"','','system','system','system')";
							SQLHelper.executeSQL(conn, sql);
						}
						else
						{
							sql="update ecs_distributor set distributorname='"+cop.getDistributorNick()+"',startdate='"+
								Formatter.format(cop.getStartDate(),Formatter.DATE_TIME_FORMAT)+"',"
								+"updatetime='"+Formatter.format(new Date(),Formatter.DATE_TIME_FORMAT)+"', "
								+"shopname='"+shopname+"' "
								+"where distributorid="+cop.getDistributorId();
							SQLHelper.executeSQL(conn, sql);
						}
						
					}
				
					if (pageno==(Double.valueOf(Math.ceil(response.getTotalResults()/40.0))).intValue()) break;
					
					pageno++;
					req.setPageNo(pageno);
					response=client.execute(req , Params.authcode);
					i=i+1;
				}
				
	
				if (modified.compareTo(Formatter.parseDate(lasttime, Formatter.DATE_TIME_FORMAT))>0)
				{
				
					try
	            	{
	            		String value=Formatter.format(modified,Formatter.DATE_TIME_FORMAT);
	            		PublicUtils.setConfig(conn, lasttimeconfvalue, value);
	            	}catch(JException je)
	            	{
	            		Log.error(jobname,je.getMessage());
	            	}
				}
				//ִ�гɹ�����ѭ��
				break;
			}catch (JException e) {
				
				throw e;
				
			} catch (Exception e) {
				if (++k >= 10)
					throw e;
				Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
				
			}
		}
	}
	
	private String getDistributorShopName(String nick) throws Exception
	{
		String shopname="";
		
		TaobaoClient client=new DefaultTaobaoClient(Params.url,Params.appkey, Params.appsecret,"xml");
		FenxiaoDistributorsGetRequest req=new FenxiaoDistributorsGetRequest();
		req.setNicks(nick);
		FenxiaoDistributorsGetResponse response = client.execute(req , Params.authcode);

		if (DOMHelper.ElementIsExists(DOMHelper.newDocument(response.getBody(), "GBK").getDocumentElement(), "distributors"))
		{
			String shopurl=response.getDistributors().get(0).getShopWebLink();
				
			String html=getOneHtml(shopurl);
			
			if (html.equals("")) return "";
				
			String title= getTitle(html);

			shopname=title;
			/*
		
			if (title.indexOf("--")>=0)
			{
				if(title.lastIndexOf("--")==title.indexOf("--"))
					if (title.indexOf("--")>title.indexOf("-"))
						shopname= title.substring(title.indexOf("-")+1, title.lastIndexOf("--"));
					else
						shopname= title.substring(title.indexOf("--")+2, title.lastIndexOf("-"));
				else
					shopname= title.substring(title.indexOf("--")+2, title.lastIndexOf("--"));
			}
			else 
			{
				if (title.substring(title.indexOf("-")+1).indexOf("-")>=0)
					shopname=title.substring(title.indexOf("-")+1).substring(0, title.substring(title.indexOf("-")+1).indexOf("-"));
				else
					shopname=title;
			}
			*/
				
		}
		return shopname;
		
	}
	
	
	private String getOneHtml(String htmlurl) throws IOException {

		if (htmlurl.toLowerCase().indexOf("http")<0)
			htmlurl="http://"+htmlurl;
		

		URL url;
		String temp;
		StringBuffer sb = new StringBuffer();
		try {
			url = new URL(htmlurl);
			BufferedReader in = new BufferedReader(new InputStreamReader(
					url.openStream(), "GBK"));// ��ȡ��ҳȫ������
			while ((temp = in.readLine()) != null) {
				sb.append(temp);
			}
			in.close();
		} catch (MalformedURLException me) {
			System.out.println("�������URL��ʽ�����⣡����ϸ����");
			me.getMessage();
			throw me;
		}catch(UnknownHostException une)
		{
			une.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
			throw e;
		} 
		return sb.toString();
	}

	private  String getTitle(String s) {
		String regex;
		String title = "";
		final List<String> list = new ArrayList<String>();
		regex = "<title>.*?</title>";
		final Pattern pa = Pattern.compile(regex, Pattern.CANON_EQ);
		final Matcher ma = pa.matcher(s);
		while (ma.find()) {
			list.add(ma.group());
		}
		for (int i = 0; i < list.size(); i++) {
			title = title + list.get(i);
		}
		return outTag(title);
	}

	private String outTag(final String s) {
		return s.replaceAll("<.*?>", "");
	}
	
	public String toString()
	{
		return jobname + " " + (is_importing ? "[importing]" : "[waiting]");
	}
}
