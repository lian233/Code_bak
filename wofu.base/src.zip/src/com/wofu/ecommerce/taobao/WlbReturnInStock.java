package com.wofu.ecommerce.taobao;


import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;


import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;

import com.taobao.api.request.WlbOrderCreateRequest;

import com.taobao.api.response.WlbOrderCreateResponse;
import com.wofu.common.tools.sql.PoolHelper;
import com.wofu.common.tools.sql.SQLHelper;

import com.wofu.common.tools.util.log.Log;
import com.wofu.business.intf.IntfUtils;


public class WlbReturnInStock extends Thread {

	private static String jobname = "�����������˻������ҵ";
	
	SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
	
	private boolean is_importing=false;
	
	private String lasttime;


	public WlbReturnInStock() {
		setDaemon(true);
		setName(jobname);
	}

	public void run() {
		Log.info(jobname, "����[" + jobname + "]ģ��");
		do {		
			Connection connection = null;
			is_importing = true;
			try {												
				connection = PoolHelper.getInstance().getConnection(
						com.wofu.ecommerce.taobao.Params.dbname);

				createReturnOrder(connection,IntfUtils.getintfsheetlist(connection,Params.wlbinterfacesystem,"2222"));
			} catch (Exception e) {
				try {
					if (connection != null && !connection.getAutoCommit())
						connection.rollback();
				} catch (Exception e1) {
					Log.error(jobname, "�ع�����ʧ��");
				}
				Log.error("105", jobname, Log.getErrorMessage(e));
			} finally {
				is_importing = false;
				try {
					if (connection != null)
						connection.close();
				} catch (Exception e) {
					Log.error(jobname, "�ر����ݿ�����ʧ��");
				}
			}
			System.gc();
			long startwaittime = System.currentTimeMillis();
			while (System.currentTimeMillis() - startwaittime < (long) (com.wofu.ecommerce.taobao.Params.waittime * 1000))		
				try {
					sleep(1000L);
				} catch (Exception e) {
					Log.warn(jobname, "ϵͳ��֧�����߲���, ��ҵ������Ӱ���������");
				}
		} while (true);
	}

		
	private void createReturnOrder(Connection conn,List sheetlist) throws Exception
	{
		for(Iterator it=sheetlist.iterator();it.hasNext();)
		{
			String sheetid=(String) it.next();
			String sql="select b.sheetid,b.refsheetid  "
					+"from customerretrcv0 a,refund b where a.refsheetid=b.sheetid and a.sheetid='"+sheetid+"'";
			Hashtable ht=SQLHelper.oneRowSelect(conn, sql);
			String tid=ht.get("refsheetid").toString();
			String buzcode=ht.get("sheetid").toString();
	
			sql="select delivery,deliverysheetid from customerdelive where customersheetid='"+tid+"'";
			Hashtable htdelivry=SQLHelper.oneRowSelect(conn, sql);
			String delivery=htdelivry.get("delivery").toString();
			String deliverysheetid=htdelivry.get("deliverysheetid").toString();
			
			for (int k=0;k<10;)
			{
				try			
				{
					TaobaoClient client=new DefaultTaobaoClient(Params.url,Params.appkey,Params.appsecret,"xml");
					WlbOrderCreateRequest req=new WlbOrderCreateRequest();
					
					req.setOutBizCode(buzcode);
					req.setPrevOrderCode(tid);
					req.setStoreCode(Params.storecode);
					req.setOrderType("NORMAL_IN");
					req.setOrderSubType("TAOBAO_TRADE");
					req.setIsFinished(true);
										
					req.setTmsOrderCode(deliverysheetid);
					req.setTmsServiceCode(delivery);
					
					String tmsinfo=delivery.concat("^^^").concat("NA").concat("^^^").concat(deliverysheetid).concat("^^^").concat("NA").concat("^^^").concat("NA");
					
					req.setTmsInfo(tmsinfo);
					
				
					StringBuffer strbuf=new StringBuffer();
					strbuf.append("{\"order_item_list\":[");
					
					sql="select b.custombc,outqty,retprice from customerretrcvitem0 a,barcode b "
						+"where a.barcodeid=b.barcodeid and a.sheeetid='"+sheetid+"'";
					Vector vt=SQLHelper.multiRowSelect(conn, sql);
					
					for(int i=0;i<vt.size();i++)
					{
						strbuf.append("{");
						Hashtable hto=(Hashtable) vt.get(i);
						String sku=hto.get("custombc").toString();
						String qty=hto.get("outqty").toString();
						String price=hto.get("retprice").toString();
						
						int itemid=WLBUtils.getItemIDBySku(sku);
						
						strbuf.append("\"item_id\":\""+itemid+"\",");
						strbuf.append("\"inventory_type\":\"1\",");
						strbuf.append("\"trade_code\":\""+tid+"\",");
						strbuf.append("\"sub_trade_code\":\""+tid+"\",");
						strbuf.append("\"owner_user_nick\":\""+Params.username+"\",");
						strbuf.append("\"flag\":\"0\",");  //�Ƿ���Ʒ
						strbuf.append("\"item_code\":\""+sku+"\",");
						strbuf.append("\"item_quantity\":\""+qty+"\",");
						strbuf.append("\"item_price\":\""+price+"\"");
						strbuf.append("},");				
					}
					strbuf.deleteCharAt(strbuf.length()-1);
					strbuf.append("]}");	
					
					req.setOrderItemList(strbuf.toString());
					
					WlbOrderCreateResponse response = client.execute(req , Params.authcode);
					
					String ordercode=response.getOrderCode();
					
					IntfUtils.backupIntfSheetList(conn,sheetid,Params.wlbinterfacesystem,"2222");
					
					Log.info(jobname,"�����������˻���ⵥ�ɹ�,�������˻���ⵥ��:"+ordercode+" �˻�����:"+buzcode);
				} catch (Exception e) {
					if (++k >= 10)
						throw e;
					Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
					Thread.sleep(10000L);
				}
			}
		}
	}
	
	
	
	
	public String toString()
	{
		return jobname + " " + (is_importing ? "[importing]" : "[waiting]");
	}
}
