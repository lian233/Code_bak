package com.wofu.ecommerce.taobao;


import java.sql.Connection;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;
import java.util.Vector;


import com.taobao.api.ApiException;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;

import com.taobao.api.domain.WlbOrder;
import com.taobao.api.domain.WlbOrderItem;


import com.taobao.api.request.WlbOrderPageGetRequest;
import com.taobao.api.request.WlbOrderitemPageGetRequest;
import com.taobao.api.request.WlbTmsorderQueryRequest;

import com.taobao.api.response.WlbOrderPageGetResponse;
import com.taobao.api.response.WlbOrderitemPageGetResponse;
import com.taobao.api.response.WlbTmsorderQueryResponse;
import com.wofu.common.tools.sql.PoolHelper;
import com.wofu.common.tools.sql.SQLHelper;


import com.wofu.common.tools.util.Formatter;
import com.wofu.common.tools.util.JException;
import com.wofu.common.tools.util.StringUtil;

import com.wofu.common.tools.util.log.Log;
import com.wofu.base.job.timer.TimerJob;
import com.wofu.base.job.Executer;
import com.wofu.business.intf.IntfUtils;

public class WlbInStockExecuter extends Executer {

	
	private String url="";

	private String appkey="";

	private String appsecret="";

	private String authcode="";

	private String tradecontactid="";

	private String dbname="";
	
	private String wlbinterfacesystem="";

	private Date nextactive=null;

	public void execute() throws Exception {
		TimerJob job=(TimerJob) this.getExecuteobj();
		Properties prop=StringUtil.getStringProperties(job.getParams());
		
		url=prop.getProperty("url");
		appkey=prop.getProperty("appkey");
		appsecret=prop.getProperty("appsecret");
		authcode=prop.getProperty("authcode");
		tradecontactid=prop.getProperty("tradecontactid");
		dbname=prop.getProperty("dbname");
		nextactive=job.getNextactive();
		wlbinterfacesystem=prop.getProperty("wlbinterfacesystem");
		
		Connection conn=null;
		try {			 
			conn= PoolHelper.getInstance().getConnection(dbname);
			getAllocateOutOrder(conn);
			
		}catch (ApiException e) {
			throw new JException("����Զ�̷���ʧ��,������Ϣ:" + e.getMessage());
			
		} catch (Exception e) {
			try {
				if (conn != null && !conn.getAutoCommit())
					conn.rollback();
			} catch (Exception e1) {
				throw new JException("�ع�����ʧ��");
			}
			throw new JException("ȡ�ͷ���Ϣ"+Log.getErrorMessage(e));
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				throw new JException("�ر����ݿ�����ʧ��");
			}
		}

	}	
	/*
	 * ��ȡһ��֮������з�������
	 */
	private void getAllocateOutOrder(Connection conn) throws Exception
	{		
		String sql="select sheetid,refsheetid,outshopid,inshopid,customersheetid from transfer0 with(nolock) where customersheetid is not null ";
		Vector vt=SQLHelper.multiRowSelect(conn, sql);
		for (int j=0;j<vt.size();j++)
		{
			Hashtable ht=(Hashtable) vt.get(j);
			String sheetid=ht.get("sheetid").toString();
			String outshopid=ht.get("outshopid").toString();
			String inshopid=ht.get("inshopid").toString();
			String pursheetid=ht.get("refsheetid").toString();
			String ordercode=ht.get("customersheetid").toString();
			
			for(int k=0;k<10;)
			{
				try
				{
					TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
					WlbOrderPageGetRequest req=new WlbOrderPageGetRequest();
					req.setOrderType("NORMAL_IN");
					req.setOrderSubType("PURCHASE");		
					req.setOrderCode(ordercode);			
					
		
					WlbOrderPageGetResponse response = client.execute(req , authcode);
				
					if (response.getOrderList()==null || response.getOrderList().size()<=0)
					{
						k=10;					
						break;
					}

					for(Iterator it=response.getOrderList().iterator();it.hasNext();)
					{
					
						WlbOrder o=(WlbOrder) it.next();
					
						if (o.getOrderStatus().equalsIgnoreCase("100"))
						{
					
							sql="select vertifycode from IT_SystemInfo  with(nolock) where interfacesystem='"+wlbinterfacesystem+"'";
							String owner=SQLHelper.strSelect(conn, sql);
							
							conn.setAutoCommit(false);
					
							sql="declare @Err int ; declare @NewSheetID char(16); "
								+"execute  @Err = TL_GetNewSheetID 1103, @NewSheetID output;select @NewSheetID;";			
							String commsheetid=SQLHelper.strSelect(conn, sql);
					
							String note="";
							if (o.getRemark()!=null)
								note.concat(o.getRemark());
							if (o.getOrderStatusReason()!=null)
								note.concat(" ").concat(o.getOrderStatusReason());
	
							sql="insert into wms_instock0(sheetid,refsheetid,pursheetid,"
								+"custompursheetid,owner,outid,inid,purday,transfertype,flag,"
								+"purdate,notifyOper,notifydate,operator,dealdate,checker,checkdate,note)"
								+"values('"+commsheetid+"','"+sheetid+"','"+pursheetid+"','"+ordercode+"','"+owner+"',"
								+"'"+outshopid+"','"+inshopid+"',30,23421,100,getdate(),'WLB',getdate(),'�ӿ�',getdate(),'WLB',getdate(),"
								+"'"+note+"')";
					
							SQLHelper.executeSQL(conn, sql);
					
							getInstockDetail(conn,commsheetid,ordercode);
					
							IntfUtils.upNote(conn, owner, commsheetid, 23421, wlbinterfacesystem, "020V10");
					
							conn.commit();
							conn.setAutoCommit(true);
					
							Log.info("�������������ɹ������������ⵥ��:"+ordercode+" ��������:"+sheetid);
						}					
					
					
					}
					k=10;
					//ִ�гɹ�����ѭ��
					break;
				} catch (Exception e) {
					if (++k >= 10)
						throw e;
					Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
					Thread.sleep(10000L);
					
				}
			}
		}
	}

	//������ⵥ��ϸ
	
	private void getInstockDetail(Connection conn,String commsheetid,String ordercode) throws Exception
	{				
		TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
		WlbOrderitemPageGetRequest req=new WlbOrderitemPageGetRequest();
		req.setOrderCode(ordercode);
		WlbOrderitemPageGetResponse response = client.execute(req , authcode);
		for (int i=0;i<response.getOrderItemList().size();i++)
		{
			WlbOrderItem item=response.getOrderItemList().get(i);
			
			long itemprice=0L;
			if 	(item.getItemPrice()!=null)
				itemprice=item.getItemPrice();
			
			String sql="select count(*) from combinebarcode with(nolock) where newcustombc='"+item.getItemCode()+"'";
			if (SQLHelper.intSelect(conn, sql)>0)
			{				
				sql="insert into wms_instockitem0(sheetid,customermid,"
					+"barcodeid,badflag,NotifyPrice,price,notifyqty,inqty,pknum,pkname,pkspec,Taxrate,InPQty) "
					+" select '"+commsheetid+"',goodsid,barcodeid,1,'"+String.valueOf(Float.valueOf(itemprice)/100)
					+"','"+String.valueOf(Float.valueOf(itemprice)/100)+"',"+item.getPlanQuantity()+","+item.getRealQuantity()+",pknum,pkname,pkspec,17.00,0.00 "				
					+"from barcode a,combinebarcode b where (a.custombc=b.custombc and b.newcustombc='"+item.getItemCode()+"') "
					+"or (a.barcodeid=b.custombc and b.newcustombc='"+item.getItemCode()+"')";
			}
			else
			{
				sql="insert into wms_instockitem0(sheetid,customermid,"
					+"barcodeid,badflag,NotifyPrice,price,notifyqty,inqty,pknum,pkname,pkspec,Taxrate,InPQty) "
					+" select '"+commsheetid+"',goodsid,barcodeid,1,'"+String.valueOf(Float.valueOf(itemprice)/100)
					+"','"+String.valueOf(Float.valueOf(itemprice)/100)+"',"+item.getPlanQuantity()+","+item.getRealQuantity()+",pknum,pkname,pkspec,17.00,0.00 "
					+"from barcode where custombc='"+item.getItemCode()+"' or barcodeid='"+item.getItemCode()+"'";
			}
			SQLHelper.executeSQL(conn, sql);
		}
	
	}
	
}
