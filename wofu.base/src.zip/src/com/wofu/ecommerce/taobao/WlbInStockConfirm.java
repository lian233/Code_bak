package com.wofu.ecommerce.taobao;


import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;


import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.domain.Order;
import com.taobao.api.domain.Trade;
import com.taobao.api.domain.WlbOrder;
import com.taobao.api.domain.WlbOrderItem;

import com.taobao.api.request.TradesSoldIncrementGetRequest;
import com.taobao.api.request.WlbOrderPageGetRequest;
import com.taobao.api.request.WlbOrderitemPageGetRequest;
import com.taobao.api.request.WlbTmsorderQueryRequest;

import com.taobao.api.response.TradesSoldIncrementGetResponse;
import com.taobao.api.response.WlbOrderPageGetResponse;
import com.taobao.api.response.WlbOrderitemPageGetResponse;
import com.taobao.api.response.WlbTmsorderQueryResponse;
import com.wofu.common.tools.sql.PoolHelper;
import com.wofu.common.tools.sql.SQLHelper;

import com.wofu.common.tools.util.Formatter;
import com.wofu.common.tools.util.JException;

import com.wofu.common.tools.util.log.Log;
import com.wofu.business.stock.StockManager;
import com.wofu.business.util.PublicUtils;
import com.wofu.business.intf.IntfUtils;
import com.wofu.business.order.OrderManager;

public class WlbInStockConfirm extends Thread {

	private static String jobname = "��ȡ���������ȷ�ϵ���ҵ";
		
	private boolean is_importing=false;


	public WlbInStockConfirm() {
		setDaemon(true);
		setName(jobname);
	}

	public void run() {
		Log.info(jobname, "����[" + jobname + "]ģ��");
		do {		
			Connection connection = null;
			is_importing = true;
			try {												
				connection = PoolHelper.getInstance().getConnection(
						com.wofu.ecommerce.taobao.Params.dbname);
				
				getLogisticsOrderList(connection);
			} catch (Exception e) {
				try {
					if (connection != null && !connection.getAutoCommit())
						connection.rollback();
				} catch (Exception e1) {
					Log.error(jobname, "�ع�����ʧ��");
				}
				Log.error("105", jobname, Log.getErrorMessage(e));
			} finally {
				is_importing = false;
				try {
					if (connection != null)
						connection.close();
				} catch (Exception e) {
					Log.error(jobname, "�ر����ݿ�����ʧ��");
				}
			}
			System.gc();
			long startwaittime = System.currentTimeMillis();
			while (System.currentTimeMillis() - startwaittime < (long) (com.wofu.ecommerce.taobao.Params.waittime * 1000))		
				try {
					sleep(1000L);
				} catch (Exception e) {
					Log.warn(jobname, "ϵͳ��֧�����߲���, ��ҵ������Ӱ���������");
				}
		} while (true);
	}

	
	/*
	 * ��ȡһ��֮������з�������
	 */
	private void getLogisticsOrderList(Connection conn) throws Exception
	{		
		long pageno=1L;	
		for(int k=0;k<10;)
		{
			try
			{
				TaobaoClient client=new DefaultTaobaoClient(Params.url,Params.appkey, Params.appsecret,"xml");
				WlbOrderPageGetRequest req=new WlbOrderPageGetRequest();
				req.setOrderType("NORMAL_IN");
				req.setOrderSubType("PURCHASE");				
				req.setPageNo(pageno);
				req.setPageSize(40L);
				req.setOrderStatus(200L);
				
				int i=1;
			
				while(true)
				{
					WlbOrderPageGetResponse response = client.execute(req , Params.authcode);
					
					if (response.getOrderList()==null || response.getOrderList().size()<=0)
					{
						break;
					}

					for(Iterator it=response.getOrderList().iterator();it.hasNext();)
					{
						
						WlbOrder o=(WlbOrder) it.next();
						
						String refsheetid=o.getPrevOrderCode();  //����֪ͨ����
						String sheetid=o.getOrderSourceCode();   //��������
						String ordercode=o.getOrderCode();
						
						//ȡԭ������ⵥ
						String sql="select count(*) from transfer where sheetid='"+sheetid+"'";
						
						if (SQLHelper.intSelect(conn, sql)==0) continue; //����Ѿ���� ��������
						
						sql="select vertifycode from IT_SystemInfo where interfacesystem='"+Params.wlbinterfacesystem+"'";
						String owner=SQLHelper.strSelect(conn, sql);
						
						sql="declare @Err int ; declare @NewSheetID char(16); "
							+"execute  @Err = TL_GetNewSheetID 1103, @NewSheetID output;select @NewSheetID;";			
						String commsheetid=SQLHelper.strSelect(conn, sql);
						
						sql="insert into wms_instock0(sheetid,refsheetid,pursheetid,"
							+"custompursheetid,owner,outid,inid,purday,transfertype,flag,"
							+"purdate,notifyOper,notifydate,operator,dealdate,checker,checkdate,note)"
							+"select '"+commsheetid+"',sheetid,refsheetid,'"+ordercode+"','"+owner+"',"
							+"outshopid,inshopid,purday,23421,100,getdate(),'WLB',getdate(),'�ӿ�',getdate(),'WLB',getdate(),"
							+"'"+o.getRemark()+"' from transfer0 "
							+" where sheetid='"+sheetid+"'";
						SQLHelper.executeSQL(conn, sql);
						
						getInstockDetail(conn,commsheetid,ordercode);
						
						sql="select value from config where name='�����'";
						String mySHOPID=SQLHelper.strSelect(conn, sql);
						
						IntfUtils.upNote(conn, owner, commsheetid, 23421, Params.wlbinterfacesystem, mySHOPID);
						Log.info(jobname,"���������ɹ�����������ⵥ��:"+ordercode+" ����֪ͨ����:"+refsheetid+" ��������:"+sheetid);
					}
					pageno++;
					req.setPageNo(pageno);
					response=client.execute(req , Params.authcode);
					i=i+1;			
				}
				//ִ�гɹ�����ѭ��
				break;
			} catch (Exception e) {
				if (++k >= 10)
					throw e;
				Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
				
			}
		}
	}
	
	//������ⵥ��ϸ
	
	private void getInstockDetail(Connection conn,String commsheetid,String ordercode) throws Exception
	{
		TaobaoClient client=new DefaultTaobaoClient(Params.url,Params.appkey, Params.appsecret,"xml");
		WlbOrderitemPageGetRequest req=new WlbOrderitemPageGetRequest();
		req.setOrderCode(ordercode);
		WlbOrderitemPageGetResponse response = client.execute(req , Params.authcode);
		for (int i=0;i<response.getOrderItemList().size();i++)
		{
			WlbOrderItem item=response.getOrderItemList().get(i);
			
			String sql="insert into wms_outstockitem0(sheetid,customermid,"
				+"barcodeid,badflag,price,notifyqty,inqty,pknum,pkname,pkspec) "
				+" select '"+commsheetid+"',goodsid,barcodeid,1,'"+item.getItemPrice()
				+"',"+item.getPlanQuantity()+","+item.getRealQuantity()+",pknum,pkname,pkspec "
				+"from barcode where custombc='"+item.getItemCode()+"'";
			SQLHelper.executeSQL(conn, sql);
		}
	}
	
	
	public String toString()
	{
		return jobname + " " + (is_importing ? "[importing]" : "[waiting]");
	}
}
