package com.wofu.ecommerce.taobao;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;


import java.sql.Connection;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import java.util.Map;
import java.util.Properties;
import java.util.Vector;

import com.taobao.api.ApiException;
import com.wofu.common.json.JSONObject;
import com.wofu.common.tools.sql.PoolHelper;
import com.wofu.common.tools.sql.SQLHelper;
import com.wofu.common.tools.util.Formatter;

import com.wofu.common.tools.util.JException;
import com.wofu.common.tools.util.RemoteHelper;
import com.wofu.common.tools.util.StreamUtil;
import com.wofu.common.tools.util.StringUtil;
import com.wofu.common.tools.util.log.Log;

import com.wofu.base.job.timer.TimerJob;
import com.wofu.base.job.Executer;

public class getRefundExecuter extends Executer {

	private String sellernick="";
	private String dbname="";
	private String tradecontactid="";

	
	private final String jobname="�����Ա��˻�����ҵ";

	@Override
	public void execute() throws Exception {
		TimerJob job=(TimerJob) this.getExecuteobj();
		Properties prop=StringUtil.getStringProperties(job.getParams());
		
		sellernick=prop.getProperty("sellernick");	
		tradecontactid=prop.getProperty("tradecontactid");
		dbname=prop.getProperty("dbname");
		
		Connection conn=null;
		try {			 
			conn= PoolHelper.getInstance().getConnection(dbname);
			
			
			String sql="select batchid from eco_rds_refund with(nolock) where flag=0 and seller_nick='"+sellernick+"' order by batchid";
			
			List batchlist=SQLHelper.multiRowListSelect(conn, sql);
			
			for(Iterator itbatch=batchlist.iterator();itbatch.hasNext();)
			{
				int batchid=(Integer) itbatch.next();
				
				sql="select jdp_response from eco_rds_refund with(nolock) "
					+"where flag=0 and seller_nick='"+sellernick+" and batchid="+batchid;
				
				List responselist=SQLHelper.multiRowListSelect(conn, sql);
				
				for(Iterator itresponse=responselist.iterator();itresponse.hasNext();)
				{
					String jdpresponse=(String) itresponse.next();
					
					Refund r=new Refund();
					
					JSONObject jsonobj=new JSONObject(jdpresponse);
					
					JSONObject refundjsobobj=jsonobj.getJSONObject("refund_get_response").getJSONObject("refund");
					
					r.setObjValue(r, refundjsobobj);
					
					RDSUtils.processRefund(jobname,conn,r,tradecontactid,sellernick);					
				}
				
				sql="update eco_rds_refund set status=1 "
					+"where status=0 and seller_nick='"+sellernick+" and batchid="+batchid;
				SQLHelper.executeSQL(conn, sql);
				
			}
			
		} catch (Exception e) {
			try {
				if (conn != null && !conn.getAutoCommit())
					conn.rollback();
			} catch (Exception e1) {
				throw new JException("�ع�����ʧ��");
			}
			throw new JException("����Ա�δ�붩��"+Log.getErrorMessage(e));
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				throw new JException("�ر����ݿ�����ʧ��");
			}
		}

		
	
	}

}
 