package com.wofu.ecommerce.taobao;


import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;


import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.domain.Order;
import com.taobao.api.domain.Trade;
import com.taobao.api.domain.WlbOrder;
import com.taobao.api.domain.WlbOrderItem;

import com.taobao.api.request.TradesSoldIncrementGetRequest;
import com.taobao.api.request.WlbOrderPageGetRequest;
import com.taobao.api.request.WlbOrderitemPageGetRequest;
import com.taobao.api.request.WlbTmsorderQueryRequest;

import com.taobao.api.response.TradesSoldIncrementGetResponse;
import com.taobao.api.response.WlbOrderPageGetResponse;
import com.taobao.api.response.WlbOrderitemPageGetResponse;
import com.taobao.api.response.WlbTmsorderQueryResponse;
import com.wofu.common.tools.sql.PoolHelper;
import com.wofu.common.tools.sql.SQLHelper;

import com.wofu.common.tools.util.Formatter;
import com.wofu.common.tools.util.JException;

import com.wofu.common.tools.util.log.Log;
import com.wofu.business.stock.StockManager;
import com.wofu.business.util.PublicUtils;
import com.wofu.business.intf.IntfUtils;
import com.wofu.business.order.OrderManager;

public class WlbOutStock extends Thread {

	private static String jobname = "��ȡ���������ⵥ��ҵ";
		
	private boolean is_importing=false;


	public WlbOutStock() {
		setDaemon(true);
		setName(jobname);
	}

	public void run() {
		Log.info(jobname, "����[" + jobname + "]ģ��");
		do {		
			Connection connection = null;
			is_importing = true;
			try {												
				connection = PoolHelper.getInstance().getConnection(
						com.wofu.ecommerce.taobao.Params.dbname);
				
				getOutStockList(connection);
			} catch (Exception e) {
				try {
					if (connection != null && !connection.getAutoCommit())
						connection.rollback();
				} catch (Exception e1) {
					Log.error(jobname, "�ع�����ʧ��");
				}
				Log.error("105", jobname, Log.getErrorMessage(e));
			} finally {
				is_importing = false;
				try {
					if (connection != null)
						connection.close();
				} catch (Exception e) {
					Log.error(jobname, "�ر����ݿ�����ʧ��");
				}
			}
			System.gc();
			long startwaittime = System.currentTimeMillis();
			while (System.currentTimeMillis() - startwaittime < (long) (com.wofu.ecommerce.taobao.Params.waittime * 1000))		
				try {
					sleep(1000L);
				} catch (Exception e) {
					Log.warn(jobname, "ϵͳ��֧�����߲���, ��ҵ������Ӱ���������");
				}
		} while (true);
	}

	
	/*
	 * 
	 */
	private void getOutStockList(Connection conn) throws Exception
	{		
		long pageno=1L;	
		for(int k=0;k<10;)
		{
			try
			{
				TaobaoClient client=new DefaultTaobaoClient(Params.url,Params.appkey, Params.appsecret,"xml");
				WlbOrderPageGetRequest req=new WlbOrderPageGetRequest();
				req.setOrderType("NORMAL_OUT");
				req.setOrderSubType("OTHER");				
				req.setPageNo(pageno);
				req.setPageSize(40L);
				req.setOrderStatus(100L);
				
				int i=1;
			
				while(true)
				{
					WlbOrderPageGetResponse response = client.execute(req , Params.authcode);
					
					if (response.getOrderList()==null || response.getOrderList().size()<=0)
					{
						break;
					}

					for(Iterator it=response.getOrderList().iterator();it.hasNext();)
					{
						
						WlbOrder o=(WlbOrder) it.next();
										
						String ordercode=o.getOrderCode();
						
						//�Ѿ����ڸõ�
						String sql="select count(*) from transfer where refsheetid='"+ordercode+"'";
						
						if (SQLHelper.intSelect(conn, sql)==0) continue; //����Ѿ����� ��������
						
						sql="select value from config where name='�����'";
						String mySHOPID=SQLHelper.strSelect(conn, sql);
						
						sql="select vertifycode from IT_SystemInfo where interfacesystem='"+Params.wlbinterfacesystem+"'";
						String owner=SQLHelper.strSelect(conn, sql);				
								
						//ȡͨѶ����
						sql="declare @Err int ; declare @NewSheetID char(16); "
							+"execute  @Err = TL_GetNewSheetID 1103, @NewSheetID output;select @NewSheetID;";			
						String commsheetid=SQLHelper.strSelect(conn, sql);
						
						//���ɵ�������
						sql="declare @Err int ; declare @NewSheetID char(16); "
							+"execute  @Err = TL_GetNewSheetID 2341, @NewSheetID output;select @NewSheetID;";			
						String sheetid=SQLHelper.strSelect(conn, sql);
						
						sql="insert into wms_outstock0(sheetid,refsheetid,pursheetid,"
							+"custompursheetid,owner,inid,purday,transfertype,flag,"
							+"notifyOper,notifydate,operator,checker,checkdate,note,address,"
							+"linktele,linkman,delivery,deliverysheetid,zipcode,detailid)"
							+"values('"+commsheetid+"','"+sheetid+"','"+ordercode+"','"+ordercode+"','"+owner+"',"
							+"'"+Params.mainstorecode+"',30,23411,100,'WLB',getdate(),'�ӿ�','WLB',getdate(),"
							+"'"+o.getRemark()+"','"+o.getReceiverProvince()+" "+o.getReceiverCity()+" "
							+o.getReceiverArea()+" "+o.getReceiverAddress()+"','"+o.getReceiverPhone()+"',"
							+"'"+o.getReceiverName()+"','"+o.getTmsTpCode()+"','"+getDeliveryCode(ordercode)+"',"
							+"'"+o.getReceiverZipCode()+"','"+o.getBuyerNick()+"')";						
						SQLHelper.executeSQL(conn, sql);
						
						getDeliveryDetail(conn,commsheetid,ordercode);
						
						IntfUtils.upNote(conn, owner, commsheetid, 22091, Params.wlbinterfacesystem, mySHOPID);
					
					}
					pageno++;
					req.setPageNo(pageno);
					response=client.execute(req , Params.authcode);
					i=i+1;			
				}
				//ִ�гɹ�����ѭ��
				break;
			} catch (Exception e) {
				if (++k >= 10)
					throw e;
				Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
				
			}
		}
	}
	//���������������Ż�ȡ�˵���
	private String getDeliveryCode(String ordercode) throws Exception
	{
		TaobaoClient client=new DefaultTaobaoClient(Params.url,Params.appkey, Params.appsecret,"xml");
		WlbTmsorderQueryRequest req=new WlbTmsorderQueryRequest();
		req.setOrderCode(ordercode);
		WlbTmsorderQueryResponse response = client.execute(req , Params.authcode);
		return response.getTmsOrderList().get(0).getCode();
	}
	
	//������������ϸ
	
	private void getDeliveryDetail(Connection conn,String commsheetid,String ordercode) throws Exception
	{
		TaobaoClient client=new DefaultTaobaoClient(Params.url,Params.appkey, Params.appsecret,"xml");
		WlbOrderitemPageGetRequest req=new WlbOrderitemPageGetRequest();
		req.setOrderCode(ordercode);
		WlbOrderitemPageGetResponse response = client.execute(req , Params.authcode);
		for (int i=0;i<response.getOrderItemList().size();i++)
		{
			WlbOrderItem item=response.getOrderItemList().get(i);
			
			String sql="insert into wms_outstockitem0(sheetid,customermid,"
				+"barcodeid,badflag,price,notifyqty,outqty,pknum,pkname,pkspec) "
				+" select '"+commsheetid+"',goodsid,barcodeid,1,'"+item.getItemPrice()
				+"',"+item.getPlanQuantity()+","+item.getRealQuantity()+",pknum,pkname,pkspec "
				+"from barcode where custombc='"+item.getItemCode()+"'";
			SQLHelper.executeSQL(conn, sql);
		}
	}
	
	
	public String toString()
	{
		return jobname + " " + (is_importing ? "[importing]" : "[waiting]");
	}
}
