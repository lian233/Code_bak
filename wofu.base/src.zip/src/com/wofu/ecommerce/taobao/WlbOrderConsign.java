package com.wofu.ecommerce.taobao;


import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;


import com.taobao.api.ApiException;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.domain.Order;
import com.taobao.api.domain.Trade;
import com.taobao.api.domain.WlbOrder;

import com.taobao.api.request.TradesSoldIncrementGetRequest;
import com.taobao.api.request.WlbItemQueryRequest;
import com.taobao.api.request.WlbOrderConsignRequest;
import com.taobao.api.request.WlbOrderCreateRequest;
import com.taobao.api.request.WlbTradeorderGetRequest;

import com.taobao.api.response.TradesSoldIncrementGetResponse;
import com.taobao.api.response.WlbItemQueryResponse;
import com.taobao.api.response.WlbOrderConsignResponse;
import com.taobao.api.response.WlbOrderCreateResponse;
import com.taobao.api.response.WlbTradeorderGetResponse;
import com.wofu.common.tools.sql.PoolHelper;
import com.wofu.common.tools.sql.SQLHelper;

import com.wofu.common.tools.util.Formatter;
import com.wofu.common.tools.util.JException;

import com.wofu.common.tools.util.log.Log;
import com.wofu.business.stock.StockManager;
import com.wofu.business.util.PublicUtils;
import com.wofu.business.intf.IntfUtils;
import com.wofu.business.order.OrderManager;

public class WlbOrderConsign extends Thread {

	private static String jobname = "����������ȷ��";

	
	private boolean is_importing=false;
	


	public WlbOrderConsign() {
		setDaemon(true);
		setName(jobname);
	}

	public void run() {
		Log.info(jobname, "����[" + jobname + "]ģ��");
		do {		
			Connection connection = null;
			is_importing = true;
			try {												
				connection = PoolHelper.getInstance().getConnection(
						com.wofu.ecommerce.taobao.Params.dbname);

				orderConsign(connection);
			} catch (Exception e) {
				try {
					if (connection != null && !connection.getAutoCommit())
						connection.rollback();
				} catch (Exception e1) {
					Log.error(jobname, "�ع�����ʧ��");
				}
				Log.error("105", jobname, Log.getErrorMessage(e));
			} finally {
				is_importing = false;
				try {
					if (connection != null)
						connection.close();
				} catch (Exception e) {
					Log.error(jobname, "�ر����ݿ�����ʧ��");
				}
			}
			System.gc();
			long startwaittime = System.currentTimeMillis();
			while (System.currentTimeMillis() - startwaittime < (long) (com.wofu.ecommerce.taobao.Params.waittime * 1000))		
				try {
					sleep(1000L);
				} catch (Exception e) {
					Log.warn(jobname, "ϵͳ��֧�����߲���, ��ҵ������Ӱ���������");
				}
		} while (true);
	}

	

	
	private void orderConsign(Connection conn) throws Exception
	{
		String sql="select sheetid from it_infsheetlist_bak1104 "
			+"where executeflag=1 and sheetid<>'7211110300000044'";
		List lst=SQLHelper.multiRowListSelect(conn, sql);
		for(int i=0;i<lst.size();i++)
		{
			String sheetid=(String) lst.get(i);
			sql="select count(*) from customerdelive where refsheetid='"+sheetid+"'";
			if (SQLHelper.intSelect(conn, sql)>0)
			{
				sql="select refsheetid from customerorder where sheetid='"+sheetid+"'";
				String tid=SQLHelper.strSelect(conn, sql);
				
				for (int j=0;j<10;)
				{
					try
					{
						TaobaoClient client=new DefaultTaobaoClient(Params.url,Params.appkey,Params.appsecret);
						WlbTradeorderGetRequest req=new WlbTradeorderGetRequest();
						req.setTradeType("TAOBAO");
						req.setTradeId(tid);
						WlbTradeorderGetResponse response = client.execute(req,Params.authcode);
						for (int k=0;k<response.getWlbOrderList().size();k++)
						{
							WlbOrder wo=response.getWlbOrderList().get(k);
							String ordercode=wo.getOrderCode();
							orderConsign(ordercode);
							sql="insert into it_infsheetlist_1104 select * from it_infsheetlist_bak1104 "
								+"where sheetid='"+sheetid+"'";
							SQLHelper.executeSQL(conn, sql);
							sql="delete from it_infsheetlist_bak1104 "
								+"where sheetid='"+sheetid+"'";
							SQLHelper.executeSQL(conn, sql);
							Log.info("ȷ������������","����������:"+ordercode+" �Ա�����:"+tid);
						}
						j=10;
					}catch(Exception e)
					{
						if (++j >= 10)
							throw e;
						Log.warn("Զ������ʧ��[" + i + "], 10����Զ�����. "+ Log.getErrorMessage(e));
						Thread.sleep(10000L);
					}
				}
			}
		}
	}
	private void orderConsign(String ordercode) throws Exception
	{
			
		TaobaoClient client=new DefaultTaobaoClient(Params.url, Params.appkey, Params.appsecret,"xml");
		WlbOrderConsignRequest  reqitem=new WlbOrderConsignRequest();
		reqitem.setWlbOrderCode(ordercode);
		WlbOrderConsignResponse rspitem = client.execute(reqitem , Params.authcode);				
	
	}
	
	
	
	public String toString()
	{
		return jobname + " " + (is_importing ? "[importing]" : "[waiting]");
	}
}
