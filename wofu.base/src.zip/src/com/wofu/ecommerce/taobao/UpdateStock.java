package com.wofu.ecommerce.taobao;

import java.sql.Connection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import com.taobao.api.ApiException;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.domain.WlbInventory;
import com.taobao.api.request.SkusCustomGetRequest;
import com.taobao.api.request.WlbInventoryDetailGetRequest;
import com.taobao.api.request.WlbItemMapGetByExtentityRequest;
import com.taobao.api.response.SkusCustomGetResponse;
import com.taobao.api.response.WlbInventoryDetailGetResponse;
import com.taobao.api.response.WlbItemMapGetByExtentityResponse;
import com.wofu.ecommerce.taobao.Params;
import com.wofu.business.stock.StockManager;
import com.wofu.common.tools.sql.JSQLException;
import com.wofu.common.tools.sql.PoolHelper;
import com.wofu.common.tools.sql.SQLHelper;
import com.wofu.common.tools.util.JException;
import com.wofu.common.tools.util.log.Log;

public class UpdateStock extends Thread{
	
	private static String jobname = "�����Ա������ҵ";
	
	private boolean is_updating=false;
	

	public UpdateStock() {
		setDaemon(true);
		setName(jobname);
	}

	public void run() {
		Log.info(jobname, "����[" + jobname + "]ģ��");
		do {		
			Connection connection = null;
			is_updating = true;
			try {					
				connection = PoolHelper.getInstance().getConnection(
						com.wofu.ecommerce.taobao.Params.dbname);

	
				doUpdateStock(connection,getGoodsInfo(connection));
		
			} catch (Exception e) {
				try {
					if (connection != null && !connection.getAutoCommit())
						connection.rollback();
				} catch (Exception e1) {
					Log.error(jobname, "�ع�����ʧ��");
				}
				Log.error("105", jobname, Log.getErrorMessage(e));
			} finally {
				is_updating = false;
				try {
					if (connection != null)
						connection.close();
				} catch (Exception e) {
					Log.error(jobname, "�ر����ݿ�����ʧ��");
				}
			}
			System.gc();
			long startwaittime = System.currentTimeMillis();
			while (System.currentTimeMillis() - startwaittime < (long) (com.wofu.ecommerce.taobao.Params.waittime * 1000))		
				try {
					sleep(1000L);
				} catch (Exception e) {
					Log.warn(jobname, "ϵͳ��֧�����߲���, ��ҵ������Ӱ���������");
				}
		} while (true);
	}

	private void doUpdateStock(Connection conn,Vector vtinfo) throws Exception
	{

		for(int i=0;i<vtinfo.size();i++)
		{
		
			Hashtable htinfo=(Hashtable) vtinfo.get(i);
			String tid=htinfo.get("tid").toString();
			String sku=htinfo.get("sku").toString();
			int qty=Integer.valueOf(htinfo.get("qty").toString()).intValue();
			try 
			{		
		
				String sql="select customno from v_barcodeall with(nolock) where custombc='"+sku+"'";
				String customno=SQLHelper.strSelect(conn, sql).trim();
				if (customno==null || customno.equals(""))						
						customno=sku;
				
	
				sql="select orgid from ecs_tradecontactorgcontrast with(nolock) where tradecontactid="+Params.tradecontactid;
				int orgid=SQLHelper.intSelect(conn, sql);
			
	

				
					
				if (Params.isdistribution)
				{
				
					List dskuinfos=StockUtils.getDistributionSkuInfo(Params.url,Params.appkey,Params.appsecret,Params.authcode,customno,sku);
				
					for (Iterator itdsku=dskuinfos.iterator();itdsku.hasNext();)
					{
					
						Hashtable distribitionskuinfo=(Hashtable) itdsku.next();
						distribitionskuinfo.put("type", "2");
						distribitionskuinfo.put("sku", sku);
						
						int quantity=Integer.valueOf(distribitionskuinfo.get("quantity").toString()).intValue();
						
						if (quantity==0) continue;
				
						sql="select count(*) from ecs_stockconfig with(nolock) where orgid="+orgid+" and sku='"+sku+"'";
						if (SQLHelper.intSelect(conn, sql)==0)
							throw new JException("��Ʒδ���þ�����,SKU:"+sku);
						
						sql="select alarmqty,isneedsyn from ecs_stockconfig with(nolock) where orgid="+orgid+" and sku='"+sku+"'";
						Hashtable ht=SQLHelper.oneRowSelect(conn, sql);
						
						int alarmqty=Integer.valueOf(ht.get("alarmqty").toString());
						int isneedsyn=Integer.valueOf(ht.get("isneedsyn").toString());
						
						if (isneedsyn==0)
						{
							Log.info("������Ʒ���ò���Ҫͬ�����,SKU:"+sku);
							continue;  //����Ҫͬ��
						}

						//���ԭ�����ϱ�����ͬ���Ŀ��С�ڵ��ھ�����,����¿��Ϊ��
						if ((quantity+qty)<=alarmqty)
						{
							distribitionskuinfo.put("qty", String.valueOf(-quantity));
							
							//���¾���״̬
							sql="update ecs_stockconfig set alarmstatus=1,alarmtime=getdate() "
								+"where orgid="+orgid+" and sku='"+sku+"'";
							SQLHelper.executeSQL(conn, sql);
							Log.warn("���·������","��Ʒ����Ѵﵽ������:"+alarmqty+",SKU:"+sku);
						}
						else
						{
							distribitionskuinfo.put("qty", String.valueOf(qty));
							
							sql="update ecs_stockconfig set alarmstatus=0 "
								+"where orgid="+orgid+" and sku='"+sku+"'";
							SQLHelper.executeSQL(conn, sql);
							Log.info("���·������","��Ʒ�������,SKU:"+sku);
						}
						
						sql="update ecs_stockconfig set stockcount=stockcount+("+distribitionskuinfo.get("qty").toString()+")"
						+" where orgid="+orgid+" and sku='"+sku+"'";
						SQLHelper.executeSQL(conn, sql);
					
						
						StockUtils.updateDistributionStock("���·������",tid,Params.url,Params.appkey,Params.appsecret,Params.authcode,
									Long.valueOf(distribitionskuinfo.get("productid").toString()).longValue(),
									distribitionskuinfo.get("skuid").toString(),sku,
									distribitionskuinfo.get("quantity").toString(),
									String.valueOf(Integer.valueOf(distribitionskuinfo.get("quantity").toString()).intValue()+Integer.valueOf(distribitionskuinfo.get("qty").toString()).intValue()),
									distribitionskuinfo.get("qty").toString(),2,
									Boolean.valueOf(distribitionskuinfo.get("issku").toString()).booleanValue());
						
					}
			
				}else
				{
					List skuinfos=StockUtils.getSkuInfo(Params.url,Params.appkey,Params.appsecret,Params.authcode,customno,sku);
					
					
					for (Iterator itsku=skuinfos.iterator();itsku.hasNext();)
					{
						Hashtable skuinfo=(Hashtable) itsku.next();
										
						skuinfo.put("type", "2");
						skuinfo.put("sku", sku);
					
						int quantity=Integer.valueOf(skuinfo.get("quantity").toString()).intValue();
						
						//ԭ���Ϊ��ʱͬ����棬�����������ط�ȡ�������ӿ�浼�³���,�����Ҫͬ��
						//if (quantity==0 && qty==1)
						//{
						//	Log.info("ԭ���Ϊ��,SKU:"+sku);						
						//	continue;
						//}
						
						if (skuinfo.get("iswlb").toString().equals("1"))
						{
							Log.info("Ʒ��������Ʒ,SKU:"+sku);						
							continue;
						}
						
						//�����е���Ʒ���龯������Ƿ���Ҫͬ��,�ֿ��еĲ���Ҫ���
						//if (skuinfo.get("status").equals("onsale"))
						//{
							sql="select count(*) from ecs_stockconfig with(nolock) where orgid="+orgid+" and sku='"+sku+"'";
							if (SQLHelper.intSelect(conn, sql)==0)
								throw new JException("�ϼ���Ʒδ���þ�����,SKU:"+sku);
							
							sql="select alarmqty,isneedsyn from ecs_stockconfig with(nolock) where orgid="+orgid+" and sku='"+sku+"'";
							Hashtable ht=SQLHelper.oneRowSelect(conn, sql);
							
							int alarmqty=Integer.valueOf(ht.get("alarmqty").toString());
							int isneedsyn=Integer.valueOf(ht.get("isneedsyn").toString());
							
							if (isneedsyn==0)
							{
								Log.info("���ò���Ҫͬ�����,SKU:"+sku);
								continue;  //����Ҫͬ��
							}

							//���ԭ�����ϱ�����ͬ���Ŀ��С�ڵ��ھ�����,����¿��Ϊ��
							if ((quantity+qty)<=alarmqty)
							{
								skuinfo.put("qty", String.valueOf(-quantity));
								
								//���¾���״̬
								sql="update ecs_stockconfig set alarmstatus=1,alarmtime=getdate() "
									+"where orgid="+orgid+" and sku='"+sku+"'";
								SQLHelper.executeSQL(conn, sql);
								Log.warn("�����Ա����","��Ʒ����Ѵﵽ������:"+alarmqty+",SKU:"+sku);
							}
							else
							{
								skuinfo.put("qty", String.valueOf(qty));
								
								sql="update ecs_stockconfig set alarmstatus=0 "
									+"where orgid="+orgid+" and sku='"+sku+"'";
								SQLHelper.executeSQL(conn, sql);
								Log.info("�����Ա����","��Ʒ�������,SKU:"+sku);
							}
							
							sql="update ecs_stockconfig set stockcount=stockcount+("+skuinfo.get("qty").toString()+")"
								+" where orgid="+orgid+" and sku='"+sku+"'";
							SQLHelper.executeSQL(conn, sql);
						
			
						StockUtils.updateStock(jobname,tid,Params.url,Params.appkey,Params.appsecret,Params.authcode,skuinfo,Boolean.valueOf(skuinfo.get("issku").toString()).booleanValue());
				
					}
				}
				
				StockManager.bakSynReduceStore(jobname, conn, Params.tradecontactid, tid, sku);	
				
			}catch(JException je)
			{
				if (je.getMessage().indexOf("�Ҳ���")>=0)
				{
					try
					{
						StockManager.bakSynReduceStore(jobname, conn, Params.tradecontactid, tid, sku);
					}catch(JException e)
					{
						System.out.println("��������ʧ��!");
						Log.error(jobname,e.getMessage());
					}
				}
				StockManager.bakSynReduceStore(jobname, conn, Params.tradecontactid, tid, sku);	
				Log.error(jobname,"�����Ա����ʧ��:" + je.getMessage());
			}
		}
	}
	
	/*����SKU�Ϳ������
	 * SKU qty
	 */
	private Vector getGoodsInfo(Connection conn)
	{
		Vector vtinfo=null;
		try
		{			
			String sql="select tid,sku,qty from ECO_SynReduceStore "
				+"where tradecontactid='"+Params.tradecontactid+"' "
				+"and synflag=0 and sku is not null and sku<>'' ";
			vtinfo=SQLHelper.multiRowSelect(conn, sql);
		}
		catch(JSQLException e)
		{
			Log.error(jobname, "ȡ��Ʒ��������Ϣ����:"+e.getMessage());
		}
		return vtinfo;
	}
	
	public String toString()
	{
		return jobname + " " + (is_updating ? "[updating]" : "[waiting]");
	}

}
