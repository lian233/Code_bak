package com.wofu.ecommerce.taobao;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;


import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;

import java.util.Map;
import java.util.Properties;
import java.util.Vector;

import com.wofu.common.tools.util.Formatter;

import com.wofu.common.tools.util.RemoteHelper;
import com.wofu.common.tools.util.StreamUtil;
import com.wofu.common.tools.util.StringUtil;
import com.wofu.common.tools.util.log.Log;

import com.wofu.base.job.timer.TimerJob;
import com.wofu.base.job.Executer;

public class RDSGetOrdersExecuter extends Executer {

			
	private String sellernick="";


	@Override
	public void execute() throws Exception {
		TimerJob job=(TimerJob) this.getExecuteobj();
		Properties prop=StringUtil.getStringProperties(job.getParams());
		sellernick=prop.getProperty("sellernick");
	
		copy();

	}

	
	private void copy() throws Exception
	{
		
		long l = System.currentTimeMillis();
		
		String sql="select * from eco_seller_config where sellernick='"+sellernick+"'";
		Hashtable htconfig=this.getDao().oneRowSelect(sql);
		
		String lastordertime=htconfig.get("lastordertime").toString();
		String lastrefundtime=htconfig.get("lastrefundtime").toString();
		String lastitemtime=htconfig.get("lastitemtime").toString();
		String lastfxordertime=htconfig.get("lastfxordertime").toString();
		String lastfxrefundtime=htconfig.get("lastfxrefundtime").toString();
		
		//��������
		sql="if object_id( 'tempdb..#tmp_trade') is not null  drop table #tmp_trade";
		this.getDao().execute(sql);		
		
		int batchid=this.getExtdao().IDGenerator("eco_rds_trade", "batchid");
		
		sql="select "+batchid+" as batchid,cast(tid as varchar(32)) as tid,status,type,seller_nick,buyer_nick,created,"
			+"modified,jdp_hashcode,isnull(jdp_response,'') as jdp_response,jdp_created,"
			+"jdp_modified,0 as flag into #tmp_trade from sys_info..jdp_tb_trade where seller_nick='"+sellernick+"' and modified>'"+lastordertime+"'";
		
		this.getDao().execute(sql);
		
		int tradecount=this.getDao().intSelect("select count(*) from #tmp_trade");
		
		
		//�����˻���
		sql="if object_id( 'tempdb..#tmp_refund') is not null  drop table #tmp_refund";
		this.getDao().execute(sql);		

		batchid=this.getExtdao().IDGenerator("eco_rds_refund", "batchid");
		
		sql="select "+batchid+" as batchid,cast(refund_id as varchar(32)) as refund_id,cast(tid as varchar(32)) as tid,cast(oid as varchar(32)) as oid,status,seller_nick,buyer_nick,"
			+"created,modified,jdp_hashcode,isnull(jdp_response,'') as jdp_response,jdp_created,jdp_modified,0 as flag "
			+"into #tmp_refund from sys_info..jdp_tb_refund where seller_nick='"+sellernick+"' and  modified>'"+lastrefundtime+"'";
		this.getDao().execute(sql);
		
		int refundcount=this.getDao().intSelect("select count(*) from #tmp_refund");
			
		
		//������Ʒ����
		sql="if object_id( 'tempdb..#tmp_item') is not null  drop table #tmp_item";
		this.getDao().execute(sql);		
		
		batchid=this.getExtdao().IDGenerator("eco_rds_item", "batchid");
		sql="select "+batchid+" as batchid,cast(num_iid as varchar(32)) as num_iid,nick,approve_status,has_showcase,cid,"
			+"has_discount,created,modified,jdp_hashcode,isnull(jdp_response,'') as jdp_response,jdp_delete,jdp_created,"
			+"jdp_modified,0 as flag into #tmp_item from sys_info..jdp_tb_item where nick='"+sellernick+"' and modified>'"+lastitemtime+"'";
		this.getDao().execute(sql);
		int itemcount=this.getDao().intSelect("select count(*) from #tmp_item");

		
		//������������
		sql="if object_id( 'tempdb..#tmp_fx_trade') is not null  drop table #tmp_fx_trade";
		this.getDao().execute(sql);		
		batchid=this.getExtdao().IDGenerator("eco_rds_fx_trade", "batchid");
		sql="select "+batchid+" as batchid,cast(fenxiao_id as varchar(32)) as fenxiao_id,status,cast(tc_order_id as varchar(32)) as tc_order_id,supplier_username,"
			+"distributor_username,created,modified,jdp_hashcode,isnull(jdp_response,'') as jdp_response,jdp_created,"+
			"jdp_modified,0 as flag into #tmp_fx_trade from sys_info..jdp_fx_trade where supplier_username='"+sellernick+"' and  modified>'"+lastfxordertime+"'";
		this.getDao().execute(sql);
		int fxtradecount=this.getDao().intSelect("select count(*) from #tmp_fx_trade");


		
		//���������˵�
		sql="if object_id( 'tempdb..#tmp_fx_refund') is not null  drop table #tmp_fx_refund";
		this.getDao().execute(sql);		
		batchid=this.getExtdao().IDGenerator("eco_rds_fx_refund", "batchid");
		sql="select "+batchid+" as batchid,cast(sub_order_id as varchar(32)) as sub_order_id,refund_status,supplier_nick,"
			+"distributor_nick,refund_create_time,modified,jdp_hashcode,isnull(jdp_response,'') as jdp_response,"
			+"jdp_created,jdp_modified,0 as flag into #tmp_fx_refund from sys_info..jdp_fx_refund where supplier_nick='"+sellernick+"' and modified>'"+lastfxrefundtime+"'";		
		this.getDao().execute(sql);
		int fxrefundcount=this.getDao().intSelect("select count(*) from #tmp_fx_refund");
		//дԶ�����ݿ�
		

		
		Properties prop=new Properties();
		if (tradecount>0) prop.setProperty("eco_rds_trade", "select * from #tmp_trade");
		if (refundcount>0) prop.setProperty("eco_rds_refund", "select * from #tmp_refund");
		if (itemcount>0) prop.setProperty("eco_rds_item", "select * from #tmp_item");
		if (fxtradecount>0) prop.setProperty("eco_rds_fx_trade", "select * from #tmp_fx_trade");
		if (fxrefundcount>0) prop.setProperty("eco_rds_fx_refund", "select * from #tmp_fx_refund");
		
		if (tradecount>0 
				|| refundcount>0 
				|| itemcount>0 
				|| fxtradecount>0 
				|| fxrefundcount>0)
			this.getDao().copyTo(this.getExtdao(), prop);
		

		if (tradecount>0)
		{
			sql="select max(modified) from #tmp_trade";		
			lastordertime=this.getDao().strSelect(sql);
		}
		
		if (refundcount>0)
		{
			sql="select max(modified) from #tmp_refund";		
			lastrefundtime=this.getDao().strSelect(sql);
		}
		
		if (itemcount>0)
		{
			sql="select max(modified) from #tmp_item";		
			lastitemtime=this.getDao().strSelect(sql);
		}
		
		if (fxtradecount>0)
		{
			sql="select max(modified) from #tmp_fx_trade";		
			lastfxordertime=this.getDao().strSelect(sql);
		}
		
		if (fxrefundcount>0)
		{
			sql="select max(modified) from #tmp_fx_refund";		
			lastfxrefundtime=this.getDao().strSelect(sql);
		}
		
		
		sql="update eco_seller_config set lastordertime='"+lastordertime
			+"',lastrefundtime='"+lastrefundtime+"',lastitemtime='"+lastitemtime+"',"
			+"lastfxordertime='"+lastfxordertime+"',lastfxrefundtime='"+lastfxrefundtime+"' "
			+"where sellernick='"+sellernick+"'";
		
		this.getDao().execute(sql);
		
		
		l = System.currentTimeMillis()-l;
		
		Log.info("����ʱ��(ms): " + l);
			
	}
	

}
 