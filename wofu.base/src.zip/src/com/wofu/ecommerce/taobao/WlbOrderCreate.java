package com.wofu.ecommerce.taobao;


import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;


import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.domain.Order;
import com.taobao.api.domain.Trade;
import com.taobao.api.domain.WlbOrder;

import com.taobao.api.request.TradesSoldIncrementGetRequest;
import com.taobao.api.request.WlbItemQueryRequest;
import com.taobao.api.request.WlbOrderCreateRequest;
import com.taobao.api.request.WlbTradeorderGetRequest;

import com.taobao.api.response.TradesSoldIncrementGetResponse;
import com.taobao.api.response.WlbItemQueryResponse;
import com.taobao.api.response.WlbOrderCreateResponse;
import com.taobao.api.response.WlbTradeorderGetResponse;
import com.wofu.common.tools.sql.PoolHelper;
import com.wofu.common.tools.sql.SQLHelper;

import com.wofu.common.tools.util.Formatter;
import com.wofu.common.tools.util.JException;

import com.wofu.common.tools.util.log.Log;
import com.wofu.business.stock.StockManager;
import com.wofu.business.util.PublicUtils;
import com.wofu.business.intf.IntfUtils;
import com.wofu.business.order.OrderManager;

public class WlbOrderCreate extends Thread {

	private static String jobname = "����������������ҵ";
	
	SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
	
	private boolean is_importing=false;
	
	private String lasttime;


	public WlbOrderCreate() {
		setDaemon(true);
		setName(jobname);
	}

	public void run() {
		Log.info(jobname, "����[" + jobname + "]ģ��");
		do {		
			Connection connection = null;
			is_importing = true;
			try {												
				connection = PoolHelper.getInstance().getConnection(
						com.wofu.ecommerce.taobao.Params.dbname);

				createOrder(connection,IntfUtils.getintfsheetlist(connection,Params.wlbinterfacesystem,"2209"));
			} catch (Exception e) {
				try {
					if (connection != null && !connection.getAutoCommit())
						connection.rollback();
				} catch (Exception e1) {
					Log.error(jobname, "�ع�����ʧ��");
				}
				Log.error("105", jobname, Log.getErrorMessage(e));
			} finally {
				is_importing = false;
				try {
					if (connection != null)
						connection.close();
				} catch (Exception e) {
					Log.error(jobname, "�ر����ݿ�����ʧ��");
				}
			}
			System.gc();
			long startwaittime = System.currentTimeMillis();
			while (System.currentTimeMillis() - startwaittime < (long) (com.wofu.ecommerce.taobao.Params.waittime * 1000))		
				try {
					sleep(1000L);
				} catch (Exception e) {
					Log.warn(jobname, "ϵͳ��֧�����߲���, ��ҵ������Ӱ���������");
				}
		} while (true);
	}

	

	
	private void createOrder(Connection conn,List sheetlist) throws Exception
	{
		for(Iterator it=sheetlist.iterator();it.hasNext();)
		{
			String sheetid=(String) it.next();
			String sql="select sheetid,refsheetid,customersheetid,detailid,address,linkman,linktele,zipcode "
					+"from customerdelive0 with(nolock) where refsheetid='"+sheetid+"'";
			Hashtable ht=SQLHelper.oneRowSelect(conn, sql);
			String outsheetid=ht.get("sheetid").toString();
			String buzcode=ht.get("refsheetid").toString();
			String customersheetid=ht.get("customersheetid").toString();
			String buyernick=ht.get("detailid").toString().trim();
			String address=ht.get("address").toString().trim();
			String linkman=ht.get("linkman").toString().trim();
			String linktele=ht.get("linktele").toString().trim();
			String zipcode=ht.get("zipcode").toString().trim();
			
			
			
			if (orderIsExists(conn,customersheetid,buyernick))
			{
				IntfUtils.backupIntfSheetList(conn,sheetid,Params.wlbinterfacesystem,"2209");
				continue;
			}
			
			for (int k=0;k<10;)
			{
				try			
				{
					TaobaoClient client=new DefaultTaobaoClient(Params.url,Params.appkey,Params.appsecret,"xml");
					WlbOrderCreateRequest req=new WlbOrderCreateRequest();
					
					req.setOutBizCode(buzcode);
					req.setPrevOrderCode(customersheetid);
					req.setStoreCode(Params.storecode);
					req.setOrderType("NORMAL_OUT");
					req.setOrderSubType("TAOBAO_TRADE");
					req.setBuyerNick(buyernick);
					req.setOrderFlag("CONSIGN");
					req.setIsFinished(true);
					
				
					
					
					//��ַ��ǰ�����ո��滻Ϊ^^^
					address=address.replaceFirst(" ", "^^^");
					if (address.substring(address.indexOf(" "), address.indexOf(" ")+2).equalsIgnoreCase("  "))
						address=address.replaceFirst("  ", "^^^NA^^^");
					else
						address=address.replaceFirst(" ", "^^^").replaceFirst(" ", "^^^");
					String receiveinfo=zipcode.concat("^^^").concat(address).concat("^^^").concat(linkman).concat("^^^").concat(linktele).concat("^^^NA");
					
					req.setReceiverInfo(receiveinfo);					
					
					String sendaddress=Params.wlbprovince.concat("^^^").concat(Params.wlbcity).concat("^^^").concat(Params.wlbdistrict).concat("^^^").concat(Params.wlbaddress);
					String sendinfo=Params.wlbzipcode.concat("^^^").concat(sendaddress).concat("^^^").concat(Params.wlblinkman).concat("^^^").concat(Params.wlbmobile).concat("^^^").concat(Params.wlbphone);				
					
					req.setSenderInfo(sendinfo);
	
					
					StringBuffer strbuf=new StringBuffer();
					strbuf.append("{\"order_item_list\":[");
					
					sql="select b.barcodeid,b.custombc,purqty,customprice from customerdeliveitem0 a with(nolock),barcode b with(nolock) "
						 +"where a.barcodeid=b.barcodeid and a.sheetid='"+outsheetid+"'" 
						 +" and b.custombc not in(select custombc from combinebarcode with(nolock))"
						 +" union "	
						 +" select distinct '' barcodeid,newcustombc custombc,purqty,combineprice outprice "
						 +" from combinebarcode a,customerdeliveitem0 b with(nolock),barcode c with(nolock) "
						 +" where b.barcodeid=c.barcodeid and b.sheetid='"+outsheetid+"' "
						 +" and c.custombc=a.custombc ";
						
					Vector vt=SQLHelper.multiRowSelect(conn, sql);
					
					for(int i=0;i<vt.size();i++)
					{
						strbuf.append("{");
						Hashtable hto=(Hashtable) vt.get(i);
						String sku=hto.get("custombc").toString();
						String qty=hto.get("purqty").toString();
						String price=String.valueOf(Float.valueOf(hto.get("customprice").toString())*100);
						
						if (hto.get("barcodeid").toString().startsWith("69")) sku=hto.get("barcodeid").toString();
						
	
						int itemid=WLBUtils.getItemIDBySku(sku);
						
						System.out.println(itemid);
						
						sql="select max(sheetid) from erpnsbmstock..ns_customerorder  with(nolock) where tid='"+customersheetid+"'";
						String commsheetid=SQLHelper.strSelect(conn, sql);
						
				
						sql="select oid from erpnsbmstock..ns_orderitem  with(nolock) "
							+"where sheetid='"+commsheetid+"' and outerskuid='"+hto.get("custombc").toString()+"'";
						
						String subtradecode=SQLHelper.strSelect(conn, sql);

						
						strbuf.append("\"item_id\":\""+itemid+"\",");
						strbuf.append("\"inventory_type\":\"1\",");
						strbuf.append("\"trade_code\":\""+customersheetid+"\",");
						strbuf.append("\"sub_trade_code\":\""+subtradecode+"\",");
						strbuf.append("\"owner_user_nick\":\""+Params.username+"\",");
						strbuf.append("\"flag\":\"0\",");  //�Ƿ���Ʒ
						strbuf.append("\"item_code\":\""+sku+"\",");
						strbuf.append("\"item_quantity\":\""+Float.valueOf(qty).intValue()+"\",");
						strbuf.append("\"item_price\":\""+Float.valueOf(price).intValue()+"\"");
						strbuf.append("},");
					
						
					}
					strbuf.deleteCharAt(strbuf.length()-1);
					strbuf.append("]}");

	
					req.setOrderItemList(strbuf.toString());
					
					WlbOrderCreateResponse response = client.execute(req , Params.authcode);
					
	
					
					String ordercode=response.getOrderCode();					
					
					IntfUtils.backupIntfSheetList(conn,sheetid,Params.wlbinterfacesystem,"2209");
					
					if (ordercode ==null || ordercode.equalsIgnoreCase(""))
					{
						sql="insert into createwlborderfailure(tid,msg) values('"+customersheetid+"','"+response.getSubMsg()+"')";
						SQLHelper.executeSQL(conn, sql);
						Log.info(jobname,"��������������ʧ��,�ͻ�������:"+buzcode+" �Ա�����:"+customersheetid+"�ͻ��ǳ�:"+buyernick+" ������Ϣ:"+response.getMsg()+" "+response.getSubMsg());
					}
					else
					{
						sql="update customerdelive0 set outbuzcode='"+ordercode+"' where sheetid='"+outsheetid+"'";
						SQLHelper.executeSQL(conn, sql);
						Log.info(jobname,"���������������ɹ�,������������:"+ordercode+" �ͻ�������:"+buzcode+" �Ա�����:"+customersheetid+"�ͻ��ǳ�:"+buyernick);
					}
					k=10;
				} catch (Exception e) {
					if (++k >= 10)
						throw e;
					Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
					Thread.sleep(10000L);
				}
			}
		}
	}
	
	private boolean orderIsExists(Connection conn,String tid,String buyernick) throws Exception
	{
		boolean isexists=false;
		TaobaoClient client=new DefaultTaobaoClient(Params.url,Params.appkey,Params.appsecret);
		WlbTradeorderGetRequest req=new WlbTradeorderGetRequest();
		req.setTradeType("TAOBAO");
		req.setTradeId(tid);
		WlbTradeorderGetResponse response = client.execute(req,Params.authcode);
		

		if ((response.getWlbOrderList()==null) || (response.getWlbOrderList().size()==0))
		{
			isexists=false;
		}
		else
		{
			for (int k=0;k<response.getWlbOrderList().size();k++)
			{
				WlbOrder wo=response.getWlbOrderList().get(k);
				if (wo.getOperateType().equalsIgnoreCase("OUT") 
						&& wo.getOrderType().equalsIgnoreCase("NORMAL") 
						&& (wo.getOrderStatus().equalsIgnoreCase("0") 
								||wo.getOrderStatus().equalsIgnoreCase("10")
								||wo.getOrderStatus().equalsIgnoreCase("11")
								||wo.getOrderStatus().equalsIgnoreCase("100") 
								|| wo.getOrderStatus().equalsIgnoreCase("200")))
				{
					isexists=true;
					String sql="update customerdelive0 set outbuzcode='"+wo.getOrderCode()+"' where customersheetid='"+tid+"'";
					SQLHelper.executeSQL(conn,sql);		
					Log.info(jobname,"�����������Ѵ���,������������:"+wo.getOrderCode()+" �Ա�����:"+tid+" �ͻ��ǳ�:"+buyernick);
					break;
				}
			}
		}
		return isexists;
	}
	
	public String toString()
	{
		return jobname + " " + (is_importing ? "[importing]" : "[waiting]");
	}
}
