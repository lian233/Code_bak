package com.wofu.ecommerce.taobao;


import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;


import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.request.WlbOrderCreateRequest;
import com.taobao.api.response.WlbOrderCreateResponse;
import com.wofu.common.tools.sql.PoolHelper;
import com.wofu.common.tools.sql.SQLHelper;
import com.wofu.common.tools.util.Formatter;
import com.wofu.common.tools.util.log.Log;
import com.wofu.business.intf.IntfUtils;


public class WlbInStock extends Thread {

	private static String jobname = "���������������ҵ";
	
	SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
	
	private boolean is_importing=false;

	public WlbInStock() {
		setDaemon(true);
		setName(jobname);
	}

	public void run() {
		Log.info(jobname, "����[" + jobname + "]ģ��");
		do {		
			Connection connection = null;
			is_importing = true;
			try {												
				connection = PoolHelper.getInstance().getConnection(
						com.wofu.ecommerce.taobao.Params.dbname);

				createOrder(connection,IntfUtils.getintfsheetlist(connection,Params.wlbinterfacesystem,"2342"));
			} catch (Exception e) {
				try {
					if (connection != null && !connection.getAutoCommit())
						connection.rollback();
				} catch (Exception e1) {
					Log.error(jobname, "�ع�����ʧ��");
				}
				Log.error("105", jobname, Log.getErrorMessage(e));
			} finally {
				is_importing = false;
				try {
					if (connection != null)
						connection.close();
				} catch (Exception e) {
					Log.error(jobname, "�ر����ݿ�����ʧ��");
				}
			}
			System.gc();
			long startwaittime = System.currentTimeMillis();
			while (System.currentTimeMillis() - startwaittime < (long) (com.wofu.ecommerce.taobao.Params.waittime * 1000))		
				try {
					sleep(1000L);
				} catch (Exception e) {
					Log.warn(jobname, "ϵͳ��֧�����߲���, ��ҵ������Ӱ���������");
				}
		} while (true);
	}

		
	private void createOrder(Connection conn,List sheetlist) throws Exception
	{
		for(Iterator it=sheetlist.iterator();it.hasNext();)
		{
			String sheetid=(String) it.next();
			String sql="select refsheetid,boxcount,delivery,deliverysheetid  "
					+"from transfer0 where sheetid='"+sheetid+"'";
			Hashtable ht=SQLHelper.oneRowSelect(conn, sql);
			String refsheetid=ht.get("refsheetid").toString();
			String boxcount=ht.get("boxcount").toString();
			String delivery=ht.get("delivery").toString();
			String deliverysheetid=ht.get("deliverysheetid").toString();
			
			for (int k=0;k<10;)
			{
				try			
				{
					TaobaoClient client=new DefaultTaobaoClient(Params.url,Params.appkey,Params.appsecret,"xml");
					WlbOrderCreateRequest req=new WlbOrderCreateRequest();
					
					req.setOutBizCode(getOutBuzCode(conn,sheetid,"2342"));
					req.setPrevOrderCode(refsheetid);
					req.setStoreCode(Params.storecode);
					req.setOrderType("NORMAL_IN");
					req.setOrderSubType("PURCHASE");
					req.setPackageCount(Long.valueOf(boxcount));
					req.setIsFinished(true);
					
					String sendaddress=Params.province.concat("^^^").concat(Params.city).concat("^^^").concat(Params.district).concat("^^^").concat(Params.address);
					String sendinfo=Params.zipcode.concat("^^^").concat(sendaddress).concat("^^^").concat(Params.linkman).concat("^^^").concat(Params.mobile).concat("^^^").concat(Params.phone);
					
					req.setSenderInfo(sendinfo);
					
			
					String receiveaddress=Params.wlbprovince.concat("^^^").concat(Params.wlbcity).concat("^^^").concat(Params.wlbdistrict).concat("^^^").concat(Params.wlbaddress);
					String receiveinfo=Params.wlbzipcode.concat("^^^").concat(receiveaddress).concat("^^^").concat(Params.wlblinkman).concat("^^^").concat(Params.wlbmobile).concat("^^^").concat(Params.wlbphone);
					
					req.setReceiverInfo(receiveinfo);
					
					String tmsinfo=delivery.concat("^^^").concat("֣����").concat("^^^").concat(deliverysheetid).concat("^^^").concat("18688495363").concat("^^^").concat("432524198107281639");
							
					req.setTmsInfo(tmsinfo);					
			
					Calendar cd = Calendar.getInstance();
					cd.setTime(new Date());
					cd.add(Calendar.DATE, Params.wlbdays);
										
					req.setExpectStartTime(Formatter.parseDate(Formatter.format(cd.getTime(),Formatter.DATE_TIME_FORMAT),Formatter.DATE_TIME_FORMAT));
					cd.add(Calendar.DATE, 1);
					req.setExpectEndTime(Formatter.parseDate(Formatter.format(cd.getTime(),Formatter.DATE_TIME_FORMAT),Formatter.DATE_TIME_FORMAT));
					
					cd.add(Calendar.DATE, 2);
					
					//�ջ����������
					req.setExpectEndTime(Formatter.parseDate(Formatter.format(cd.getTime(),Formatter.DATE_TIME_FORMAT),Formatter.DATE_TIME_FORMAT));
					
					StringBuffer strbuf=new StringBuffer();
					
					strbuf.append("{\"order_item_list\":[");
					
					sql="select b.custombc,outqty,outprice from transferitem0 a,v_barcodeall b "
					 +"where a.barcodeid=b.barcodeid and a.sheetid='"+sheetid+"'" 
					 +" and b.custombc not in(select custombc from combinebarcode) and b.deptid/10000<>90 "
					 +" union "
					 +" select distinct newcustombc custombc,outqty,combineprice outprice "
					 +" from combinebarcode a,transferitem0 b,v_barcodeall c "
					 +" where b.barcodeid=c.barcodeid and b.sheetid='"+sheetid+"' "
					 +" and c.custombc=a.custombc and c.deptid/10000<>90";
					
					Vector vt=SQLHelper.multiRowSelect(conn, sql);
					
					if (vt.size()==0) 
					{
						IntfUtils.backupIntfSheetList(conn,sheetid,Params.wlbinterfacesystem,"2342");
						continue;
					}
					
					for(int i=0;i<vt.size();i++)
					{
						strbuf.append("{");
						Hashtable hto=(Hashtable) vt.get(i);
						String sku=hto.get("custombc").toString();
						String qty=hto.get("outqty").toString();
						String price=String.valueOf(Float.valueOf(hto.get("outprice").toString())*100);
												
						int itemid=WLBUtils.getItemIDBySku(sku);
						
						strbuf.append("\"item_id\":\""+itemid+"\",");
						strbuf.append("\"inventory_type\":\"1\",");
						strbuf.append("\"flag\":\"0\",");  //�Ƿ���Ʒ
						strbuf.append("\"item_code\":\""+sku+"\",");
						strbuf.append("\"item_quantity\":\""+qty+"\",");
						strbuf.append("\"item_price\":\""+price+"\"");
						strbuf.append("},");				
					}
					strbuf.deleteCharAt(strbuf.length()-1);
					strbuf.append("]}");					
				
					req.setOrderItemList(strbuf.toString());
					
					WlbOrderCreateResponse response = client.execute(req , Params.authcode);				
					
					
					String ordercode=response.getOrderCode();
					
					IntfUtils.backupIntfSheetList(conn,sheetid,Params.wlbinterfacesystem,"2342");
					
					k=10;
					if (ordercode ==null || ordercode.equalsIgnoreCase(""))
					{
						sql="insert into createwlborderfailure(tid,msg) values('"+sheetid+"','"+response.getSubMsg()+"')";
						SQLHelper.executeSQL(conn, sql);
						Log.info(jobname,"������������ⵥʧ��,��������:"+sheetid);
					}
					else
					{
						sql="update transfer0 set customersheetid='"+ordercode+"' where sheetid='"+sheetid+"'";
						SQLHelper.executeSQL(conn, sql);
						
						Log.info(jobname,"������������ⵥ�ɹ�,��������ⵥ��:"+ordercode+" ��������:"+sheetid);
					}
				} catch (Exception e) {
					if (++k >= 10)
						throw e;
					Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
					Thread.sleep(10000L);
				}
			}
		}
	}
	
	
	private String getOutBuzCode(Connection conn,String outbuzcode,String sheettype) throws Exception
	{
		String newoutbuzcode="";
		String sql="select count(*) from createwlbordertime "
				+"where sheetid='"+outbuzcode+"' and sheettype="+sheettype;
		if (SQLHelper.intSelect(conn, sql)==0)
		{
			sql="insert into createwlbordertime(sheetid,sheettype,seq) "
				+"values('"+outbuzcode+"',"+sheettype+",1)";
			SQLHelper.executeSQL(conn,sql);
			newoutbuzcode=outbuzcode;
		}
		else
		{
			sql="update createwlbordertime set seq=seq+1 "
				+"where sheetid='"+outbuzcode+"' and sheettype="+sheettype;
			SQLHelper.executeSQL(conn,sql);
			
			sql="select seq from createwlbordertime "
				+"where sheetid='"+outbuzcode+"' and sheettype="+sheettype;
			int seq=SQLHelper.intSelect(conn, sql);
			newoutbuzcode=outbuzcode+String.valueOf(seq).trim();
		}
		return newoutbuzcode;
	}
	
	public String toString()
	{
		return jobname + " " + (is_importing ? "[importing]" : "[waiting]");
	}
}
