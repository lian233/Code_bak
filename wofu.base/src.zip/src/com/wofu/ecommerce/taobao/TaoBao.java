package com.wofu.ecommerce.taobao;

import java.sql.Connection;
import java.util.Properties;

import com.wofu.ecommerce.taobao.GenCustomerOrder;
import com.wofu.ecommerce.taobao.Params;
import com.wofu.ecommerce.taobao.Version;
import com.wofu.ecommerce.taobao.getOrders;
import com.wofu.common.service.Service;
import com.wofu.common.tools.sql.PoolHelper;
import com.wofu.common.tools.sql.SQLHelper;

public class TaoBao extends Service {

	@Override
	public String description() {
		// TODO Auto-generated method stub
		return "�Ա���������ϵͳ [V " + Version.version + "]";
	}

	@Override
	public void end() throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void init(Properties prop) throws Exception {
		// TODO Auto-generated method stub	
		Params.init(prop);
		this.setParams(prop);		
	}

	@Override
	public void process() {
		// TODO Auto-generated method stub

	}

	@Override
	public void start() throws Exception {
		
		if (!Params.iswlb)
		{

			UpdateStock updatestock=new UpdateStock();
			updatestock.start();
			
			if (!Params.isrds && !Params.isdistribution)
			{							
				getOrders getorders = new getOrders();
				getorders.start();
			}
			
			GenCustomerOrder gencustomerorder = new GenCustomerOrder();
			gencustomerorder.start();
			
			OrderDelivery orderdelivery=new OrderDelivery();
			orderdelivery.start();
			
		
		
		
			if (Params.isdistribution)
			{		
				
				getDistributor getdistributor=new getDistributor();
				getdistributor.start();
				
				getDistributionOrders getdistributionorders=new getDistributionOrders();
				getdistributionorders.start();
				
				getDistributionProduct getdistributionproduct=new getDistributionProduct();
				getdistributionproduct.start();
				
				
			}
			
			genCustomerRet gencustomerret=new genCustomerRet();
			gencustomerret.start();
			
			//getGoodsNum getgoodsnum=new getGoodsNum();
			//getgoodsnum.start();
		}
		else
		{
			WlbOrderCreate createorder=new WlbOrderCreate();
			createorder.start();
			
			//WlbInStock wlbinstock=new WlbInStock();
			//wlbinstock.start();
			
			//WlbOrderConsign orderconsign=new WlbOrderConsign();
			//orderconsign.start();
		}
	}

}
