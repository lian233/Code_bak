package com.wofu.ecommerce.taobao;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;
import com.taobao.api.ApiException;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.domain.Order;
import com.taobao.api.domain.Trade;
import com.taobao.api.request.TradeCloseRequest;
import com.taobao.api.request.TradesSoldGetRequest;
import com.taobao.api.response.TradeCloseResponse;
import com.taobao.api.response.TradesSoldGetResponse;
import com.wofu.business.stock.StockManager;
import com.wofu.common.tools.sql.PoolHelper;
import com.wofu.common.tools.sql.SQLHelper;
import com.wofu.common.tools.util.Formatter;
import com.wofu.common.tools.util.JException;
import com.wofu.common.tools.util.StringUtil;
import com.wofu.common.tools.util.log.Log;
import com.wofu.base.job.timer.TimerJob;
import com.wofu.base.job.Executer;
import com.wofu.business.order.OrderManager;
import com.wofu.business.util.PublicUtils;

public class CheckOrderExecuter extends Executer {
	private String url="";

	private String appkey="";

	private String appsecret="";

	private String authcode="";

	private String tradecontactid="";

	private String dbname="";
	
	private String username="";
	
	private String lasttimeconfvalue="";
	
	private String lastchecktimeconfvalue="";
	
	private static long daymillis=24*60*60*1000L;
	
	private Date nextactive=null;
	
	private static String TradeFields="seller_nick,buyer_nick,title,type,created,tid,"
		+"seller_rate,buyer_flag,buyer_rate,status,payment,"
		+"adjust_fee,post_fee,total_fee,pay_time,end_time,modified,"
		+"consign_time,buyer_obtain_point_fee,point_fee,real_point_fee,"
		+"received_payment,commission_fee,buyer_memo,seller_memo,"
		+"alipay_no,buyer_message,pic_path,num_iid,num,price,buyer_alipay_no,"
		+"receiver_name,receiver_state,receiver_city,receiver_district,"
		+"receiver_address,receiver_zip,receiver_mobile,receiver_phone,"
		+"buyer_email,seller_flag,seller_alipay_no,seller_mobile,trade_from,"
		+"seller_phone,seller_name,seller_email,available_confirm_fee,alipay_url,"
		+"has_post_fee,timeout_action_time,Snapshot,snapshot_url,cod_fee,cod_status,"
		+"shipping_type,trade_memo,is_3D,buyer_email,buyer_memo,buyer_flag,promotion,promotion_details,orders";
	
	private boolean waitbuyerpayisin=false;
	

	@Override
	public void execute() throws Exception {
		TimerJob job=(TimerJob) this.getExecuteobj();
		Properties prop=StringUtil.getStringProperties(job.getParams());
		
		url=prop.getProperty("url");
		appkey=prop.getProperty("appkey");
		appsecret=prop.getProperty("appsecret");
		authcode=prop.getProperty("authcode");
		tradecontactid=prop.getProperty("tradecontactid");
		dbname=prop.getProperty("dbname");
		username=prop.getProperty("username");
		lasttimeconfvalue=username+"ȡ��������ʱ��";
		lastchecktimeconfvalue=username+"��鶩��ʱ��";
		nextactive=job.getNextactive();
		
		
		
		Connection conn=null;
		try {			 
			conn= PoolHelper.getInstance().getConnection(dbname);
			
			String sql="select isnull(value,0) from config where name='�ȴ�������Ƿ��ϵͳ'";
			if (SQLHelper.strSelect(conn, sql).equals("1"))
				waitbuyerpayisin=true;
			
			checkWaitSendGoods(conn); 
			//checkconfirmgoods(conn);
			checkWaitBuyerPay(conn);
			checkClosedByTaobao(conn);		
			//checkTradeFinished(conn);
			//hurryWaitBuyerPay(conn);
		}catch (ApiException e) {
			//Log.error("����Ա�δ�붩��","����Զ�̷���ʧ��,������Ϣ:" + e.getMessage());
			throw new JException("����Զ�̷���ʧ��,������Ϣ:" + e.getMessage());
			
		} catch (Exception e) {
			try {
				if (conn != null && !conn.getAutoCommit())
					conn.rollback();
			} catch (Exception e1) {
				throw new JException("�ع�����ʧ��");
			}
			throw new JException("����Ա�δ�붩��"+Log.getErrorMessage(e));
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				throw new JException("�ر����ݿ�����ʧ��");
			}
		}
	}
	
	private void checkconfirmgoods(Connection conn) throws Exception
	{
		
		long pageno=1L;
		
		for (int i=0;i<10;)
		{
			try
			{
				TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret);
				TradesSoldGetRequest req=new TradesSoldGetRequest();
				req.setFields(TradeFields);
				req.setStatus("WAIT_BUYER_CONFIRM_GOODS");
				//req.setEndCreated(Formatter.parseDate(PublicUtils.getConfig(conn,lasttimeconfvalue,""),Formatter.DATE_TIME_FORMAT));
				req.setPageNo(pageno);
				req.setPageSize(100L);
				TradesSoldGetResponse rsp = client.execute(req , authcode);
					
				while(true)
				{
					if (rsp.getTrades()==null || rsp.getTrades().size()<=0)
					{	
						i=10;
						break;
					}
					for(Iterator it=rsp.getTrades().iterator();it.hasNext();)
					{
						Trade td=(Trade) it.next();
						
						td=OrderUtils.getFullTrade(String.valueOf(td.getTid()),url,appkey,appsecret,authcode);
						
						Log.info(td.getTid()+" "+td.getStatus()+" "+Formatter.format(td.getCreated(),Formatter.DATE_TIME_FORMAT));
						
						//�����˻�
						//Log.info("������:"+String.valueOf(td.getTid())+" �˻�ID:"+String.valueOf(o.getRefundId()));
						for(Iterator ito=td.getOrders().iterator();ito.hasNext();)
						{
							Order o=(Order) ito.next();
							if (o.getRefundId()>0)
							{
								if (!OrderManager.RefundisCheck("����Ա�����", conn, String.valueOf(td.getTid()), o.getOuterSkuId()))
								{
									OrderUtils.getRefund("����Ա�����",conn,url,appkey,
										appsecret,authcode,tradecontactid,td,o,
										 String.valueOf(td.getTid()),o.getRefundId());
								}
							}
						}
						
					}
					pageno++;
					req.setPageNo(pageno);
					rsp=client.execute(req , authcode);
				}
			}catch(Exception e)
			{
				if (++i >= 10)
					throw e;
				Log.warn("Զ������ʧ��[" + i + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
			}
		}
	}
	private void checkWaitSendGoods(Connection conn) throws Exception
	{
		
		//String sql="select value from config where name='"+lastchecktimeconfvalue+"'";
		
		//Date lastchecktime=Formatter.parseDate(SQLHelper.strSelect(conn, sql), Formatter.DATE_TIME_FORMAT);
		
		//Date created=lastchecktime;
		
		long pageno=1L;
		
		for (int i=0;i<100;)
		{
			try
			{
				
				TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret);
				TradesSoldGetRequest req=new TradesSoldGetRequest();
				req.setFields(TradeFields);
				req.setStatus("WAIT_SELLER_SEND_GOODS");
				//req.setStartCreated(Formatter.parseDate("2013-09-23 10:30:00",Formatter.DATE_TIME_FORMAT));
				//req.setStartCreated(lastchecktime);
				//req.setEndCreated(Formatter.parseDate("2013-09-23 10:35:00",Formatter.DATE_TIME_FORMAT));
				req.setPageNo(pageno);
				req.setPageSize(20L);
				TradesSoldGetResponse rsp = client.execute(req , authcode);
				
				while(true)
				{
					if (rsp.getTrades()==null || rsp.getTrades().size()<=0)
					{	
						i=100;
						break;
					}
					for(Iterator it=rsp.getTrades().iterator();it.hasNext();)
					{
						Trade td=(Trade) it.next();
						
				
						td=OrderUtils.getFullTrade(String.valueOf(td.getTid()),url,appkey,appsecret,authcode);
					
						
						Log.info(td.getTid()+" "+td.getStatus()+" "+Formatter.format(td.getCreated(),Formatter.DATE_TIME_FORMAT));
						
						for(Iterator ito=td.getOrders().iterator();ito.hasNext();)
						{
							Order o=(Order) ito.next();
							StockManager.deleteWaitPayStock("����Ա�����", conn,tradecontactid, String.valueOf(td.getTid()), o.getOuterSkuId());
							
							if (o.getRefundId()>0)
							{
								if (!OrderManager.RefundisCheck("����Ա�����", conn, String.valueOf(td.getTid()), o.getOuterSkuId()))
								{
									OrderUtils.getRefund("����Ա�����",conn,url,appkey,
										appsecret,authcode,tradecontactid,td,o,
										 String.valueOf(td.getTid()),o.getRefundId());
								}
							}
							
						}
						
						if (!OrderManager.isCheck("����Ա�����", conn, String.valueOf(td.getTid())))
						{
							if (!OrderManager.TidLastModifyIntfExists("����Ա�����", conn, String.valueOf(td.getTid()),td.getModified()))
							{
								try
								{
															
									OrderUtils.createInterOrder("����Ա�����",conn,td,tradecontactid,username,true);
									
									for(Iterator ito=td.getOrders().iterator();ito.hasNext();)
									{
										Order o=(Order) ito.next();
										StockManager.deleteWaitPayStock("����Ա�����", conn,tradecontactid, String.valueOf(td.getTid()), o.getOuterSkuId());
										//StockManager.addSynReduceStore("����Ա�����", conn, tradecontactid, td.getStatus(),String.valueOf(td.getTid()), o.getOuterSkuId(), -o.getNum(),false);
																
									}
									
								} catch(SQLException sqle)
								{
									throw new JException("���ɽӿڶ�������!" + sqle.getMessage());
								}
							}
						}
						/*
						String sql="select count(*) from ns_delivery where tid='"+String.valueOf(td.getTid())+"'";
						if (SQLHelper.intSelect(conn, sql)>0)
						{
							sql="insert into tmp_tid(tid) values('"+String.valueOf(td.getTid())+"')";
							SQLHelper.executeSQL(conn, sql);
						}*/
						
//						����ͬ����������ʱ��
		                //if (td.getCreated().compareTo(created)>0)
		               // {
		              //  	created=td.getCreated();
		               // }
					}
					pageno++;
					req.setPageNo(pageno);
					rsp=client.execute(req , authcode);
				}
				
				/*
				if (created.compareTo(lastchecktime)>0)
				{
					try
	            	{
	            		String value=Formatter.format(created,Formatter.DATE_TIME_FORMAT);
	            		PublicUtils.setConfig(conn, lastchecktimeconfvalue, value);
	            	}catch(JException je)
	            	{
	            		Log.error("����Ա�����",je.getMessage());
	            	}
				}
				*/
				
				i=100;
			}catch(Exception e)
			{
				if (++i >= 100)
					throw e;
				Log.warn("Զ������ʧ��[" + i + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
			}
		}
	}
	
	private void checkClosedByTaobao(Connection conn) throws Exception
	{
		
		long pageno=1L;
		
		for (int i=0;i<10;)
		{
			try
			{
				TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret);
				TradesSoldGetRequest req=new TradesSoldGetRequest();
				req.setFields(TradeFields);
				req.setStatus("TRADE_CLOSED_BY_TAOBAO");
				//req.setStatus("TRADE_CLOSED");		
				req.setStartCreated(Formatter.parseDate(Formatter.format(new Date((new Date()).getTime()-1*24*60*60*1000),Formatter.DATE_TIME_FORMAT),Formatter.DATE_TIME_FORMAT));
				req.setEndCreated(new Date());
				req.setPageNo(pageno);
				req.setPageSize(20L);
				TradesSoldGetResponse rsp = client.execute(req , authcode);
				
				while(true)
				{
					if (rsp.getTrades()==null || rsp.getTrades().size()<=0)
					{	
						i=10;
						break;
					}
					for(Iterator it=rsp.getTrades().iterator();it.hasNext();)
					{
						Trade td=(Trade) it.next();
						
						td=OrderUtils.getFullTrade(String.valueOf(td.getTid()),url,appkey,appsecret,authcode);
						
						Log.info(td.getTid()+" "+td.getStatus()+" "+Formatter.format(td.getCreated(),Formatter.DATE_TIME_FORMAT));
						
						if (waitbuyerpayisin)
						{
							if (!OrderManager.TidLastModifyIntfExists("����Ա�����", conn, String.valueOf(td.getTid()),td.getModified()))
							{
								OrderUtils.createInterOrder("����Ա�����",conn,td,tradecontactid,username,false);
								
							}
						}
						
						for(Iterator ito=td.getOrders().iterator();ito.hasNext();)
						{
							Order o=(Order) ito.next();
							String sku=o.getOuterSkuId();
				
							StockManager.deleteWaitPayStock("����Ա�δ�붩��", conn,tradecontactid, String.valueOf(td.getTid()), sku);
							if (StockManager.WaitPayStockExists("����Ա�δ�붩��",conn,tradecontactid, String.valueOf(td.getTid()), sku))  //�л�ȡ���ȴ���Ҹ���״̬ʱ�żӿ��
								StockManager.addSynReduceStore("����Ա�δ�붩��", conn, tradecontactid, td.getStatus(),String.valueOf(td.getTid()), sku, o.getNum(),false);
						}
					}
					//Log.info("ҳ��:"+String.valueOf(req.getPageNo()));
					pageno=pageno+1;
					req.setPageNo(pageno);
					rsp=client.execute(req , authcode);
				}
			}catch(Exception e)
			{
				if (++i >= 10)
					throw e;
				Log.warn("Զ������ʧ��[" + i + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
			}
		}
	}
	
	private void checkWaitBuyerPay(Connection conn) throws Exception
	{
		
		long pageno=1L;
				
		for (int i=0;i<100;)
		{
			try
			{
				TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret);
				TradesSoldGetRequest req=new TradesSoldGetRequest();
				req.setFields(TradeFields);
				req.setStatus("WAIT_BUYER_PAY");	
				req.setPageNo(pageno);
				req.setPageSize(100L);
				TradesSoldGetResponse rsp = client.execute(req , authcode);
				
				while(true)
				{
					if (rsp.getTrades()==null || rsp.getTrades().size()<=0)
					{	
						i=100;
						break;
					}
					
					for(Iterator it=rsp.getTrades().iterator();it.hasNext();)
					{
						Trade td=(Trade) it.next();
						td=OrderUtils.getFullTrade(String.valueOf(td.getTid()),url,appkey,appsecret,authcode);
						
						if (!td.getStatus().equals("WAIT_BUYER_PAY")) continue;
						
					     						
						Log.info(td.getTid()+" "+td.getStatus()+" "+Formatter.format(td.getCreated(),Formatter.DATE_TIME_FORMAT));
						
						
						if (waitbuyerpayisin)
						{
							if (!OrderManager.TidLastModifyIntfExists("����Ա�����", conn, String.valueOf(td.getTid()),td.getModified()))
							{
								OrderUtils.createInterOrder("����Ա�����",conn,td,tradecontactid,username,false);
								
							}
						}
						
						for(Iterator ito=td.getOrders().iterator();ito.hasNext();)
						{
							Order o=(Order) ito.next();
							String sku=o.getOuterSkuId();
							
							if (!StockManager.WaitPayStockExists("���δ��δ�����",conn,tradecontactid,String.valueOf(td.getTid()),sku))
							{
								StockManager.addWaitPayStock("���δ��δ�����", conn,tradecontactid, String.valueOf(td.getTid()), sku, o.getNum());
								StockManager.addSynReduceStore("���δ��δ�����", conn, tradecontactid, td.getStatus(),String.valueOf(td.getTid()), sku, -o.getNum(),false);
							}
						}
							
					}
					
					pageno=pageno+1;
					req.setPageNo(pageno);
					rsp=client.execute(req , authcode);
				}
				i=100;
			}catch(Exception e)
			{
				if (++i >= 100)
					throw e;
				Log.warn("Զ������ʧ��[" + i + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
			}
		}
	}
	
	
	private void hurryWaitBuyerPay(Connection conn) throws Exception
	{
		
		long pageno=1L;
		
		String msg="�ף�����δ����Ķ�����������ޣ��뼰ʱ�������ʿ��ʱ���콢�꡿";
		for (int i=0;i<100;)
		{
			try
			{
				TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret);
				TradesSoldGetRequest req=new TradesSoldGetRequest();
				req.setFields(TradeFields);
				req.setStatus("WAIT_BUYER_PAY");	
				req.setStartCreated(Formatter.parseDate("2012-08-17 18:05:21",Formatter.DATE_TIME_FORMAT));
				//req.setEndCreated(Formatter.parseDate("2012-05-23 10:20:00",Formatter.DATE_TIME_FORMAT));
				req.setPageNo(pageno);
				req.setPageSize(100L);
				TradesSoldGetResponse rsp = client.execute(req , authcode);
				
				while(true)
				{
					if (rsp.getTrades()==null || rsp.getTrades().size()<=0)
					{	
						i=100;
						break;
					}
					
					for(Iterator it=rsp.getTrades().iterator();it.hasNext();)
					{
						Trade td=(Trade) it.next();
						td=OrderUtils.getFullTrade(String.valueOf(td.getTid()),url,appkey,appsecret,authcode);
						
						if (!td.getStatus().equals("WAIT_BUYER_PAY")) continue;
						
					     String promotionDetails  = "";
					     
					     for (int j =0;j<td.getPromotionDetails().size();j++)
					     {
					    	 promotionDetails = promotionDetails+
					    	 	td.getPromotionDetails().get(j).getPromotionName()+
					    	 	td.getPromotionDetails().get(j).getGiftItemName()+
					    	 	td.getPromotionDetails().get(j).getDiscountFee()+";";
					     }
					     
					     //if (!(promotionDetails.indexOf("Ʒ������")>=0)) continue;
					     
					     //if (!td.getTradeFrom().equalsIgnoreCase("JHS")) continue;				
						
					     
						//Log.info(td.getTid()+" "+td.getStatus()+" "+Formatter.format(td.getCreated(),Formatter.DATE_TIME_FORMAT));
							
							if (td.getReceiverMobile()==null || td.getReceiverMobile().equalsIgnoreCase("") 
									|| td.getReceiverMobile().trim().length()!=11) continue;
							
							String sql="insert into SmsNotify0(msgtype,mobile,msg,content,state,noticetime) "
									+" values(101,'"+td.getReceiverMobile().trim()+"','"+msg+"','"+msg+"',0,getdate())";
							SQLHelper.executeSQL(conn, sql);
						
					    //closeTrade(td.getTid()); 
						Log.info("�ȴ���Ҹ���,������:"+String.valueOf(td.getTid())+" �ֻ�����:"+td.getReceiverMobile()+" ʱ��:"+Formatter.format(td.getCreated(),Formatter.DATE_TIME_FORMAT));
					}
					
					pageno=pageno+1;
					req.setPageNo(pageno);
					rsp=client.execute(req , authcode);
				}
				i=100;
			}catch(Exception e)
			{
				if (++i >= 100)
					throw e;
				Log.warn("Զ������ʧ��[" + i + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
			}
		}
	}
	
	private void closeTrade(long tid) throws Exception
	{
		TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret);
		TradeCloseRequest req=new TradeCloseRequest();
		req.setTid(tid);
		req.setCloseReason("����ԭ��");
		TradeCloseResponse rsp = client.execute(req , authcode);
		Log.info("�رս��׳ɹ�:"+rsp.getTrade().getTid());
	}
	private void checkTradeFinished(Connection conn) throws Exception
	{
		long pageno=1L;
		for (int i=0;i<10;)
		{
			try
			{
				TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret);
				TradesSoldGetRequest req=new TradesSoldGetRequest();
				req.setFields(TradeFields);
				req.setStatus("TRADE_FINISHED");
				req.setStartCreated(new Date(Formatter.parseDate(PublicUtils.getConfig(conn,lasttimeconfvalue,""),Formatter.DATE_TIME_FORMAT).getTime()-10*daymillis));
				req.setEndCreated(new Date(Formatter.parseDate(PublicUtils.getConfig(conn,lasttimeconfvalue,""),Formatter.DATE_TIME_FORMAT).getTime()));
				req.setPageNo(pageno);
				req.setPageSize(20L);
				TradesSoldGetResponse rsp = client.execute(req , authcode);
				
				while(true)
				{
					if (rsp.getTrades()==null || rsp.getTrades().size()<=0)
					{	
						i=10;
						break;
					}
					for(Iterator it=rsp.getTrades().iterator();it.hasNext();)
					{
						Trade td=(Trade) it.next();
						
						td=OrderUtils.getFullTrade(String.valueOf(td.getTid()),url,appkey,appsecret,authcode);
						
						Log.info(td.getTid()+" "+td.getStatus()+" "+Formatter.format(td.getCreated(),Formatter.DATE_TIME_FORMAT));
						
						for(Iterator ito=td.getOrders().iterator();ito.hasNext();)
						{
							Order o=(Order) ito.next();
							String sku=o.getOuterSkuId();
				
							StockManager.deleteWaitPayStock("����Ա�δ�붩��", conn,tradecontactid, String.valueOf(td.getTid()), sku);
							//StockManager.addSynReduceStore("����Ա�δ�붩��", conn, tradecontactid, td.getStatus(),String.valueOf(td.getTid()), sku, o.getNum(),false);
						}
					}
					//Log.info("ҳ��:"+String.valueOf(req.getPageNo()));
					pageno=pageno+1;
					req.setPageNo(pageno);
					rsp=client.execute(req , authcode);
				}
			}catch(Exception e)
			{
				if (++i >= 10)
					throw e;
				Log.warn("Զ������ʧ��[" + i + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
			}
		}
	}
		
}
