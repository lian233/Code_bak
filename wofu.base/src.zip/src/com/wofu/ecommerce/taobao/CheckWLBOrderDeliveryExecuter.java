package com.wofu.ecommerce.taobao;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Vector;

import com.taobao.api.ApiException;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.domain.Order;
import com.taobao.api.domain.Trade;
import com.taobao.api.domain.WlbItem;
import com.taobao.api.domain.WlbItemInventoryLog;
import com.taobao.api.domain.WlbOrder;
import com.taobao.api.domain.WlbOrderItem;
import com.taobao.api.request.TradesSoldGetRequest;
import com.taobao.api.request.WlbInventorylogQueryRequest;
import com.taobao.api.request.WlbItemQueryRequest;
import com.taobao.api.request.WlbOrderPageGetRequest;
import com.taobao.api.request.WlbOrderitemPageGetRequest;
import com.taobao.api.request.WlbTmsorderQueryRequest;
import com.taobao.api.request.WlbTradeorderGetRequest;
import com.taobao.api.response.TradesSoldGetResponse;
import com.taobao.api.response.WlbInventorylogQueryResponse;
import com.taobao.api.response.WlbItemQueryResponse;
import com.taobao.api.response.WlbOrderPageGetResponse;
import com.taobao.api.response.WlbOrderitemPageGetResponse;
import com.taobao.api.response.WlbTmsorderQueryResponse;
import com.taobao.api.response.WlbTradeorderGetResponse;
import com.wofu.business.stock.StockManager;
import com.wofu.common.tools.sql.PoolHelper;
import com.wofu.common.tools.sql.SQLHelper;
import com.wofu.common.tools.util.Formatter;
import com.wofu.common.tools.util.JException;
import com.wofu.common.tools.util.StringUtil;
import com.wofu.common.tools.util.log.Log;
import com.wofu.base.job.timer.TimerJob;
import com.wofu.base.job.Executer;
import com.wofu.business.intf.IntfUtils;


public class CheckWLBOrderDeliveryExecuter extends Executer {
	private String url="";

	private String appkey="";

	private String appsecret="";

	private String authcode="";

	private String tradecontactid="";

	private String dbname="";
	
	private String username="";

	private String wlbinterfacesystem="";

	@Override
	public void execute() throws Exception {
		// TODO Auto-generated method stub
		TimerJob job=(TimerJob) this.getExecuteobj();
		Properties prop=StringUtil.getStringProperties(job.getParams());
		
		url=prop.getProperty("url");
		appkey=prop.getProperty("appkey");
		appsecret=prop.getProperty("appsecret");
		authcode=prop.getProperty("authcode");
		tradecontactid=prop.getProperty("tradecontactid");
		dbname=prop.getProperty("dbname");
		username=prop.getProperty("username");
		wlbinterfacesystem=prop.getProperty("wlbinterfacesystem");

		
		Connection conn=null;
		try {			 
			conn= PoolHelper.getInstance().getConnection(dbname);
			checkOrderDelivery(conn);
			//Log.info("��������·�����");
			//check1(conn,10L);
			//Log.info("������·�����");
			//check1(conn,11L);
			//Log.info("����ѷ�������");
			//check1(conn,100L);
			//Log.info("�����ǩ�յ���");
			//check1(conn,200L);
			//check1(conn,200L);
			//check2(conn);
			//check3(conn);
		}catch (ApiException e) {
			//Log.error("����Ա�δ�붩��","����Զ�̷���ʧ��,������Ϣ:" + e.getMessage());
			throw new JException("����Զ�̷���ʧ��,������Ϣ:" + e.getMessage());
			
		} catch (Exception e) {
			try {
				if (conn != null && !conn.getAutoCommit())
					conn.rollback();
			} catch (Exception e1) {
				throw new JException("�ع�����ʧ��");
			}
			throw new JException("�����������������"+Log.getErrorMessage(e));
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				throw new JException("�ر����ݿ�����ʧ��");
			}
		}
	}
	
	
	private void checkOrderDelivery(Connection conn) throws Exception
	{
		String sql="select sheetid,refsheetid,outshopid,customersheetid,outbuzcode "
			+"from customerdelive0 with(nolock) where outbuzcode is not null ";
		Vector vt=SQLHelper.multiRowSelect(conn, sql);
		for (int j=0;j<vt.size();j++)
		{
			Hashtable ht=(Hashtable) vt.get(j);
			String tid=ht.get("customersheetid").toString();
			String sheetid=ht.get("sheetid").toString();
			String outshopid=ht.get("outshopid").toString();
			String pursheetid=ht.get("refsheetid").toString();
			String outbuzcode=ht.get("outbuzcode").toString();
			
			for (int i=0;i<10;)
			{
				try
				{
					TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
					WlbTradeorderGetRequest req=new WlbTradeorderGetRequest();
					req.setTradeType("TAOBAO");
					req.setTradeId(tid);
					WlbTradeorderGetResponse response = client.execute(req,authcode);
					

					
					if ((response.getWlbOrderList()==null) || (response.getWlbOrderList().size()==0))
					{
						i=10;
						break; //�����ڲ�����
					}
					for (int k=0;k<response.getWlbOrderList().size();k++)
					{
						WlbOrder wo=response.getWlbOrderList().get(k);
						
						String ordercode=wo.getOrderCode();
						
						if (wo.getOperateType().equalsIgnoreCase("OUT") 
								&& wo.getOrderType().equalsIgnoreCase("NORMAL") 
								&& (wo.getOrderStatus().equalsIgnoreCase("100") 
										|| wo.getOrderStatus().equalsIgnoreCase("200"))
								&& ordercode.equals(outbuzcode))
						{							
							
				
								
							sql="select vertifycode from IT_SystemInfo with(nolock) where interfacesystem='"+wlbinterfacesystem+"'";
							String owner=SQLHelper.strSelect(conn, sql);
							
							conn.setAutoCommit(false);
							sql="declare @Err int ; declare @NewSheetID char(16); "
								+"execute  @Err = TL_GetNewSheetID 1103, @NewSheetID output;select @NewSheetID;";			
							String commsheetid=SQLHelper.strSelect(conn, sql);
						
							String[] tmsinfo=getDeliveryCode(conn,ordercode);
						
							
							sql="insert into wms_outstock0(sheetid,refsheetid,pursheetid,"
								+"custompursheetid,owner,outid,inid,purday,transfertype,flag,"
								+"notifyOper,notifydate,operator,checker,checkdate,note,address,"
								+"linktele,linkman,delivery,deliverysheetid,zipcode,detailid)"
								+"select '"+commsheetid+"',sheetid,refsheetid,'"+ordercode+"','"+owner+"',"
								+"outshopid,inshopid,purday,22091,100,'WLB',getdate(),'�ӿ�','WLB',getdate(),"
								+"notes,'"+wo.getReceiverProvince()+" "+wo.getReceiverCity()+" "
								+wo.getReceiverArea()+" "+wo.getReceiverAddress().replaceAll("'", " ")+"','"+wo.getReceiverPhone()+"',"
								+"'"+wo.getReceiverName().replaceAll("'", " ")+"','"+tmsinfo[0]+"','"+tmsinfo[1]+"',"
								+"'"+wo.getReceiverZipCode()+"',detailid from customerdelive0 "
								+" where sheetid='"+sheetid+"'";
							SQLHelper.executeSQL(conn, sql);
						
				
							getDeliveryDetail(conn,commsheetid,ordercode);
							
					
		
							IntfUtils.upNote(conn, owner, commsheetid, 22091, wlbinterfacesystem, outshopid);
							
							updateStockFlag(conn,sheetid,"100");
							
				
							
							conn.commit();
							conn.setAutoCommit(true);
							
							Log.info("�����������������","������������:"+ordercode+" �Ա�����:"+tid+" ���ⵥ��:"+sheetid);
						}
						else if (wo.getOperateType().equalsIgnoreCase("OUT") 
								&& wo.getOrderType().equalsIgnoreCase("NORMAL") 
								&& wo.getOrderStatus().equalsIgnoreCase("-1")
								&& ordercode.equals(outbuzcode))  //ȡ��
						{
							
							sql="select vertifycode from IT_SystemInfo with(nolock) where interfacesystem='"+wlbinterfacesystem+"'";
							String owner=SQLHelper.strSelect(conn, sql);
						
							conn.setAutoCommit(false);
							sql="declare @Err int ; declare @NewSheetID char(16); "
								+"execute  @Err = TL_GetNewSheetID 1103, @NewSheetID output;select @NewSheetID;";			
							String commsheetid=SQLHelper.strSelect(conn, sql);
						
							//String[] tmsinfo=getDeliveryCode(conn,ordercode);
							
							sql="insert into wms_outstock0(sheetid,refsheetid,pursheetid,"
								+"custompursheetid,owner,outid,inid,purday,transfertype,flag,"
								+"notifyOper,notifydate,operator,checker,checkdate,note,address,"
								+"linktele,linkman,delivery,deliverysheetid,zipcode,detailid)"
								+"select '"+commsheetid+"',sheetid,refsheetid,'"+ordercode+"','"+owner+"',"
								+"outshopid,inshopid,purday,22091,97,'WLB',getdate(),'�ӿ�','WLB',getdate(),"
								+"notes,'"+wo.getReceiverProvince()+" "+wo.getReceiverCity()+" "
								+wo.getReceiverArea()+" "+wo.getReceiverAddress()+"','"+wo.getReceiverPhone()+"',"
								+"'"+wo.getReceiverName()+"','','',"
								+"'"+wo.getReceiverZipCode()+"',detailid from customerdelive0 "
								+" where sheetid='"+sheetid+"'";
							SQLHelper.executeSQL(conn, sql);
						
							getDeliveryDetail(conn,commsheetid,ordercode);
							
							
							IntfUtils.upNote(conn, owner, commsheetid, 22091, wlbinterfacesystem, outshopid);
							
							updateStockFlag(conn,sheetid,"97");
							
							conn.commit();
							conn.setAutoCommit(true);
							
							Log.info("�������������ȡ��","������������:"+ordercode+" �Ա�����:"+tid+" ���ⵥ��:"+sheetid);
						}
							
					}
					i=10;
				}catch(Exception e)
				{
					if (++i >= 10)
						throw e;
					Log.warn("Զ������ʧ��[" + i + "], 10����Զ�����. "+ Log.getErrorMessage(e));
					Thread.sleep(10000L);
				}
			}
		}
	}
	
//	���������������Ż�ȡ�˵���
	private String[] getDeliveryCode(Connection conn,String ordercode) throws Exception
	{
		TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
		WlbTmsorderQueryRequest req=new WlbTmsorderQueryRequest();
		req.setOrderCode(ordercode);
		WlbTmsorderQueryResponse response = client.execute(req , authcode);
		
	
		
		if (response.getTotalCount()==0L)
		{
			Log.info("����������:["+ordercode+"]������������Ϣ!");
			return new String[]{"",""};
		}
		else
		{
			String companycode="";
			String tmscode="";
			
		
			companycode=response.getTmsOrderList().get(response.getTotalCount().intValue()-1).getCompanyCode();
			tmscode=response.getTmsOrderList().get(response.getTotalCount().intValue()-1).getCode();
		
			
			companycode=companycode.substring(0, companycode.indexOf("-"));
			
			return new String[]{companycode,tmscode};
		}
	}
	
	//������������ϸ
	
	private void getDeliveryDetail(Connection conn,String commsheetid,String ordercode) throws Exception
	{
		TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
		WlbOrderitemPageGetRequest req=new WlbOrderitemPageGetRequest();
		req.setOrderCode(ordercode);
		WlbOrderitemPageGetResponse response = client.execute(req , authcode);
		
		//Log.info(response.getBody());
		
		for (int i=0;i<response.getOrderItemList().size();i++)
		{
			WlbOrderItem item=response.getOrderItemList().get(i);
			long itemprice=0L;
			if 	(item.getItemPrice()!=null)
				itemprice=item.getItemPrice();
			
			String sql="select count(*) from combinebarcode with(nolock) where newcustombc='"+item.getItemCode()+"'";
			if (SQLHelper.intSelect(conn, sql)>0)
			{
				sql="insert into wms_outstockitem0(sheetid,customermid,"
					+"barcodeid,badflag,price,notifyqty,outqty,pknum,pkname,pkspec) "
					+" select '"+commsheetid+"',goodsid,barcodeid,1,'"+String.valueOf(Float.valueOf(itemprice)/100)
					+"',"+item.getPlanQuantity()+","+item.getRealQuantity()+",pknum,pkname,pkspec "
					+"from barcode a,combinebarcode b where a.custombc=b.custombc and b.newcustombc='"+item.getItemCode()+"'";
			}
			else
			{
				sql="insert into wms_outstockitem0(sheetid,customermid,"
					+"barcodeid,badflag,price,notifyqty,outqty,pknum,pkname,pkspec) "
					+" select '"+commsheetid+"',goodsid,barcodeid,1,'"+String.valueOf(Float.valueOf(itemprice)/100)
					+"',"+item.getPlanQuantity()+","+item.getRealQuantity()+",pknum,pkname,pkspec "
					+"from barcode where custombc='"+item.getItemCode()+"'";
			}
			SQLHelper.executeSQL(conn, sql);
		}
	}
	
	private void updateStockFlag(Connection conn,String sheetid,String flag) throws Exception
	{
		String sql="TL_SetSheetStockFlag (19,'"+sheetid+"',"+flag+",'','')";			
		SQLHelper.executeProc(conn, sql);
	}
	
	private void check1(Connection conn,long status) throws Exception
	{
		long pageno=1L;	
		for (int k=0;k<100;)
		{
			try
			{
				TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
				WlbOrderPageGetRequest req=new WlbOrderPageGetRequest();
				req.setOrderType("NORMAL_OUT");
				req.setOrderSubType("TAOBAO_TRADE");
				req.setPageNo(pageno);
				req.setPageSize(40L);
				req.setStartTime(Formatter.parseDate("2012-05-31 00:00:00", Formatter.DATE_TIME_FORMAT));				
				req.setOrderStatus(status);	
				while(true)
				{
					WlbOrderPageGetResponse response = client.execute(req,authcode);
					if (response.getOrderList()==null || response.getOrderList().size()==0)
					{
						break;
					}
					for (int i=0;i<response.getOrderList().size();i++)
					{
						WlbOrder o=(WlbOrder) response.getOrderList().get(i);
						String ordercode=o.getOrderCode();
						String tid=getWLBSubCode(ordercode);
						Log.info("�������������:"+ordercode+" �Ա�������:"+tid);
						
						String sql="select count(*) from customerdelive0 with(nolock) where customersheetid='"+tid+"'";
						if (SQLHelper.intSelect(conn, sql)>0)
						{
							sql="update customerdelive0 set outbuzcode='"+ordercode+"' where customersheetid='"+tid+"'";
							SQLHelper.executeSQL(conn, sql);
						}
						else
						{
							sql="select count(*) from customerdelive with(nolock) where customersheetid='"+tid+"'";
							if (SQLHelper.intSelect(conn, sql)==0)
							{
								sql="insert into tmp_sheetid(tid) values('"+tid+"')";
								SQLHelper.executeSQL(conn, sql);
								Log.info("����������������:"+ordercode+" �Ա�������:"+tid);
							}
						}
					}
					pageno++;
					req.setPageNo(pageno);
					response=client.execute(req , authcode);
				}
				k=100;
			} catch (Exception e) {
				if (++k >= 100)
					throw e;
				Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
			}
		}
	}
	private String getWLBSubCode(String ordercode) throws Exception
	{
		
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbOrderitemPageGetRequest req=new WlbOrderitemPageGetRequest();	
			req.setOrderCode(ordercode);
			WlbOrderitemPageGetResponse response = client.execute(req,authcode);
			WlbOrderItem orderitem=response.getOrderItemList().get(0);
			return orderitem.getOrderSubCode();
	}
	
	private void check2(Connection conn) throws Exception
	{	
		long pageno=1L;	
		TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
		WlbItemQueryRequest req=new WlbItemQueryRequest();
		req.setPageNo(pageno);
		req.setPageSize(10L);
		req.setItemCode("AV003402AS");
		WlbItemQueryResponse response = client.execute(req , authcode);
		//Log.info(response.getBody());
		while(true)
		{			
			if (response.getItemList()==null || response.getItemList().size()==0)
				break;
			for (int i=0;i<response.getItemList().size();i++)
			{
				WlbItem item=response.getItemList().get(i);
				String sku=item.getItemCode();
				long itemid=item.getId();
				getInventoryLog(conn,sku,itemid);
			}
			pageno++;
			req.setPageNo(pageno);
			response=client.execute(req , authcode);
		}
	}
	private void getInventoryLog(Connection conn,String sku,long itemid) throws Exception
	{
		long pageno=1L;	
		TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
		WlbInventorylogQueryRequest  reqitem=new WlbInventorylogQueryRequest();
		reqitem.setItemId(itemid);
		reqitem.setPageNo(pageno);
		reqitem.setPageSize(100L);
		WlbInventorylogQueryResponse rspitem = client.execute(reqitem , authcode);
		Log.info(rspitem.getBody());
		while(true)
		{			
			if (rspitem.getInventoryLogList()==null || rspitem.getInventoryLogList().size()==0)
				break;
			for (int i=0;i<rspitem.getInventoryLogList().size();i++)
			{
				WlbItemInventoryLog log=rspitem.getInventoryLogList().get(i);
				String sql="insert into inventorylog(sku,createtime,invent_type,"
						+"op_type,order_code,quantity,result_quantity) "
						+"values('"+sku+"','"+Formatter.format(log.getGmtCreate(),Formatter.DATE_TIME_FORMAT)+"','"+log.getInventType()+"',"
						+"'"+log.getOpType()+"','"+log.getOrderCode()+"','"+log.getQuantity()+"',"
						+"'"+log.getResultQuantity()+"')";
				
				SQLHelper.executeSQL(conn, sql);
		
				Log.info("SKU:"+sku+"����������:"+log.getOrderCode());				
			}
			pageno++;
			reqitem.setPageNo(pageno);
			rspitem=client.execute(reqitem , authcode);
		}
	}
	
	private void check3(Connection conn) throws Exception
	{
		long pageno=1L;	
		for (int k=0;k<100;)
		{
			try
			{
				
				TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
				WlbOrderPageGetRequest req=new WlbOrderPageGetRequest();
				req.setOrderType("NORMAL_OUT");
				req.setOrderSubType("TAOBAO_TRADE");
				req.setPageNo(pageno);
				req.setOrderCode("LBX001230102054844");
				req.setPageSize(40L);
				req.setOrderStatus(100L);	
				WlbOrderPageGetResponse response = client.execute(req,authcode);
				
				
				while(true)
				{
					
					if (response.getOrderList()==null || response.getOrderList().size()==0)
					{
						break;
					}
					for (int i=0;i<response.getOrderList().size();i++)
					{
						WlbOrder wo=(WlbOrder) response.getOrderList().get(i);
						String ordercode=wo.getOrderCode();
						
						Log.info("������������:"+ordercode+" �ͻ��ǳ�:"+wo.getBuyerNick());
						
						String sql="select count(*) from wms_outstock where custompursheetid='"+ordercode+"'";
						
						if (SQLHelper.intSelect(conn, sql)!=0) continue; //����ѳ��� ��������
						
						sql="select count(*) from wms_outstock0 where custompursheetid='"+ordercode+"'";
						
						if (SQLHelper.intSelect(conn, sql)!=0) continue; //����ѳ��� ��������
					
						sql="select vertifycode from IT_SystemInfo where interfacesystem='"+wlbinterfacesystem+"'";
						String owner=SQLHelper.strSelect(conn, sql);
						
						conn.setAutoCommit(false);
						
						sql="declare @Err int ; declare @NewSheetID char(16); "
							+"execute  @Err = TL_GetNewSheetID 1103, @NewSheetID output;select @NewSheetID;";			
						String commsheetid=SQLHelper.strSelect(conn, sql);
						
						sql="declare @Err int ; declare @NewSheetID char(16); "
							+"execute  @Err = TL_GetNewSheetID 2210, @NewSheetID output;select @NewSheetID;";			
						String outsheetid=SQLHelper.strSelect(conn, sql);
					
						String note="";
						if (wo.getRemark()!=null)
							note.concat(wo.getRemark());
						
						String tid=getWLBSubCode(ordercode);
						
						String[] tmsinfo=getDeliveryCode(conn,ordercode);
						
						sql="insert into wms_outstock0(sheetid,refsheetid,pursheetid,"
							+"custompursheetid,owner,outid,inid,purday,transfertype,flag,"
							+"notifyOper,notifydate,operator,checker,checkdate,note,address,"
							+"linktele,linkman,delivery,deliverysheetid,zipcode,detailid) "
							+"values('"+commsheetid+"','"+outsheetid+"','"+tid+"','"+ordercode+"','"+owner+"',"
							+"'020V10','020V01',30,22091,100,'WLB',getdate(),'�ӿ�','WLB',getdate(),"
							+"'"+note+"','"+wo.getReceiverProvince()+" "+wo.getReceiverCity()+" "
							+wo.getReceiverArea()+" "+wo.getReceiverAddress()+"','"+wo.getReceiverPhone()+"',"
							+"'"+wo.getReceiverName()+"','"+tmsinfo[0]+"','"+tmsinfo[1]+"',"
							+"'"+wo.getReceiverZipCode()+"','"+wo.getBuyerNick()+"')";
						SQLHelper.executeSQL(conn, sql);
					
						getDeliveryDetail(conn,commsheetid,ordercode);
						
						
						IntfUtils.upNote(conn, owner, commsheetid, 22091, wlbinterfacesystem, "020V10");
						
						//updateStockFlag(conn,outsheetid,"100");
						
						conn.commit();
						conn.setAutoCommit(true);
						
						Log.info("�����������������","������������:"+ordercode+" �Ա�����:"+tid+" ���ⵥ��:"+outsheetid);
					}
					pageno++;
					req.setPageNo(pageno);
					response=client.execute(req , authcode);
				}
				k=100;
			} catch (Exception e) {
				if (++k >= 100)
					throw e;
				Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
			}
		}
	}
}
