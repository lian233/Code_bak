package com.wofu.ecommerce.taobao;


import java.sql.Connection;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;


import com.taobao.api.ApiException;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;

import com.taobao.api.domain.WlbOrder;
import com.taobao.api.domain.WlbOrderItem;


import com.taobao.api.request.WlbOrderPageGetRequest;
import com.taobao.api.request.WlbOrderitemPageGetRequest;

import com.taobao.api.response.WlbOrderPageGetResponse;
import com.taobao.api.response.WlbOrderitemPageGetResponse;
import com.wofu.common.tools.sql.PoolHelper;
import com.wofu.common.tools.sql.SQLHelper;


import com.wofu.common.tools.util.Formatter;
import com.wofu.common.tools.util.JException;
import com.wofu.common.tools.util.StringUtil;

import com.wofu.common.tools.util.log.Log;
import com.wofu.base.job.timer.TimerJob;
import com.wofu.base.job.Executer;

import com.wofu.business.intf.IntfUtils;

public class WlbCheckExecuter extends Executer {

	
	private String url="";

	private String appkey="";

	private String appsecret="";

	private String authcode="";

	private String tradecontactid="";

	private String dbname="";
	
	private String wlbinterfacesystem="";

	private Date nextactive=null;

	public void execute() throws Exception {
		TimerJob job=(TimerJob) this.getExecuteobj();
		Properties prop=StringUtil.getStringProperties(job.getParams());
		
		url=prop.getProperty("url");
		appkey=prop.getProperty("appkey");
		appsecret=prop.getProperty("appsecret");
		authcode=prop.getProperty("authcode");
		tradecontactid=prop.getProperty("tradecontactid");
		dbname=prop.getProperty("dbname");
		nextactive=job.getNextactive();
		wlbinterfacesystem=prop.getProperty("wlbinterfacesystem");
		
		Connection conn=null;
		try {			 
			conn= PoolHelper.getInstance().getConnection(dbname);
			getCHeckOutOrderList(conn,10L);
			getCHeckOutOrderList(conn,11L);
			getCHeckOutOrderList(conn,100L);
			ProcessOutOrder(conn);
			
			getCHeckInOrderList(conn,10L);
			getCHeckInOrderList(conn,11L);
			getCHeckInOrderList(conn,100L);
			
			ProcessInOrder(conn);
			
		}catch (ApiException e) {
			throw new JException("����Զ�̷���ʧ��,������Ϣ:" + e.getMessage());
			
		} catch (Exception e) {
			try {
				if (conn != null && !conn.getAutoCommit())
					conn.rollback();
			} catch (Exception e1) {
				throw new JException("�ع�����ʧ��");
			}
			throw new JException("ȡ�ͷ���Ϣ"+Log.getErrorMessage(e));
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				throw new JException("�ر����ݿ�����ʧ��");
			}
		}

	}	
	/*
	 * ��ȡǰһ��������̵���ⵥ
	 */
	private void getCHeckOutOrderList(Connection conn,long status) throws Exception
	{		
		long pageno=1L;	
		for(int k=0;k<10;)
		{
			try
			{
				TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
				WlbOrderPageGetRequest req=new WlbOrderPageGetRequest();
				req.setOrderType("NORMAL_OUT");
				req.setOrderSubType("CHECK");				
				req.setPageNo(pageno);
				req.setPageSize(40L);
				req.setOrderStatus(status);
				
				Date startdate=Formatter.parseDate(Formatter.format(this.nextactive, Formatter.DATE_FORMAT)+" 00:00:00",Formatter.DATE_TIME_FORMAT);
				Calendar cdstart = Calendar.getInstance();
				cdstart.setTime(startdate);
				cdstart.add(Calendar.DATE, -1);
				
				req.setStartTime(Formatter.parseDate(Formatter.format(cdstart.getTime(),Formatter.DATE_TIME_FORMAT),Formatter.DATE_TIME_FORMAT));
			
				Date enddate=Formatter.parseDate(Formatter.format(this.nextactive, Formatter.DATE_FORMAT)+" 23:59:59",Formatter.DATE_TIME_FORMAT);
				Calendar cdend = Calendar.getInstance();
				cdend.setTime(enddate);
				cdend.add(Calendar.DATE, -1);
				
				req.setEndTime(Formatter.parseDate(Formatter.format(cdend.getTime(),Formatter.DATE_TIME_FORMAT),Formatter.DATE_TIME_FORMAT));
			
				WlbOrderPageGetResponse response = client.execute(req , authcode);
				
				while(true)
				{							
					if (response.getOrderList()==null || response.getOrderList().size()<=0)
					{
						k=10;
						break;
					}

					for(Iterator it=response.getOrderList().iterator();it.hasNext();)
					{
						
						WlbOrder o=(WlbOrder) it.next();
						
						String ordercode=o.getOrderCode();
						
						String sql="select count(*) from WaitProcessOrderBak where ordercode='"+ordercode+"' and sheettype=24491";
						if (SQLHelper.intSelect(conn, sql)>0) continue;		
						
						WLBUtils.waitProcessOrder(conn, 24491, ordercode);
						
						Log.info("�������������̵�ӯ�����ɹ�����������ⵥ��:"+ordercode);
					
					}
					pageno++;
					req.setPageNo(pageno);
					response=client.execute(req , authcode);
					
				}
				//ִ�гɹ�����ѭ��
				k=10;
				break;
			} catch (Exception e) {
				if (++k >= 10)
					throw e;
				Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
				
			}
		}
	}
	/*
	 * �����̵���ⵥ��
	 */
	private void ProcessOutOrder(Connection conn) throws Exception
	{		
		String sql="select ordercode from WaitProcessOrder where sheettype=24491 and flag=0";
		List list=SQLHelper.multiRowListSelect(conn, sql);
		for (Iterator itordercode=list.iterator();itordercode.hasNext();)
		{
			String ordercode=(String) itordercode.next();
			
			for(int k=0;k<10;)
			{
				try
				{
					TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
					WlbOrderPageGetRequest req=new WlbOrderPageGetRequest();
					req.setOrderType("NORMAL_OUT");
					req.setOrderSubType("CHECK");				
					req.setOrderStatus(100L);
				
					WlbOrderPageGetResponse response = client.execute(req , authcode);
					
					if (response.getOrderList()==null || response.getOrderList().size()<=0)
					{
						k=10;					
						break;
					}

					for(Iterator it=response.getOrderList().iterator();it.hasNext();)
					{
						
						WlbOrder o=(WlbOrder) it.next();
						
						//String tid=o.getPrevOrderCode();
						String prevordercode=o.getPrevOrderCode();							
						
						//ȡԭ�̵㵥
						sql="select count(*) from WMS_CheckProfitLoss where refsheetid='"+ordercode+"'";
						
						if (SQLHelper.intSelect(conn, sql)!=0) continue; //����Ѿ���� ��������
						
						sql="select count(*) from WMS_CheckProfitLoss0 where refsheetid='"+ordercode+"'";
						
						if (SQLHelper.intSelect(conn, sql)!=0) continue; //����Ѿ���� ��������
						
						sql="select vertifycode from IT_SystemInfo where interfacesystem='"+wlbinterfacesystem+"'";
						String owner=SQLHelper.strSelect(conn, sql);
						
						conn.setAutoCommit(false);
						
						sql="declare @Err int ; declare @NewSheetID char(16); "
							+"execute  @Err = TL_GetNewSheetID 1103, @NewSheetID output;select @NewSheetID;";			
						String commsheetid=SQLHelper.strSelect(conn, sql);
						
						String note="";
						if (o.getRemark()!=null)
							note.concat(o.getRemark());
						if (o.getOrderStatusReason()!=null)
							note.concat(" ").concat(o.getOrderStatusReason());
						note.concat("����������:"+ordercode);
						
						sql="insert into WMS_CheckProfitLoss0(sheetid,refsheetid,"
							+"owner,ManageDeptID,transfertype,flag,"
							+"editor,editdate,operator,checker,checkdate,note)"
							+"values('"+commsheetid+"','"+ordercode+"','"+owner+"',0"
							+",2449,100,'WLB',getdate(),'�ӿ�','WLB',getdate(),"
							+"'"+note+"')";
						SQLHelper.executeSQL(conn, sql);
						
						getCheckDetail(conn,commsheetid,ordercode,"OUT");
						
						IntfUtils.upNote(conn, owner, commsheetid, 2449, wlbinterfacesystem, "020V10");
						
						conn.commit();
						conn.setAutoCommit(true);
						
						Log.info("�������̵�ӯ�����ɹ�����������ⵥ��:"+ordercode);
					
					}
						
					//ִ�гɹ�����ѭ��
					k=10;
					break;
				} catch (Exception e) {
					if (++k >= 10)
						throw e;
					Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
					Thread.sleep(10000L);
					
				}
			}
			WLBUtils.bakWaitProcessOrder(conn, 24491, ordercode);
		}
	}
	/*
	 * ��ȡǰһ���������ӯ��
	 */
	private void getCHeckInOrderList(Connection conn,long status) throws Exception
	{		
		long pageno=1L;	
		for(int k=0;k<10;)
		{
			try
			{
				TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
				WlbOrderPageGetRequest req=new WlbOrderPageGetRequest();
				req.setOrderType("NORMAL_IN");
				req.setOrderSubType("CHECK");				
				req.setPageNo(pageno);
				req.setPageSize(40L);
				req.setOrderStatus(status);
				
				Date startdate=Formatter.parseDate(Formatter.format(this.nextactive, Formatter.DATE_FORMAT)+" 00:00:00",Formatter.DATE_TIME_FORMAT);
				Calendar cdstart = Calendar.getInstance();
				cdstart.setTime(startdate);
				cdstart.add(Calendar.DATE, -1);
				
				req.setStartTime(Formatter.parseDate(Formatter.format(cdstart.getTime(),Formatter.DATE_TIME_FORMAT),Formatter.DATE_TIME_FORMAT));
			
				Date enddate=Formatter.parseDate(Formatter.format(this.nextactive, Formatter.DATE_FORMAT)+" 23:59:59",Formatter.DATE_TIME_FORMAT);
				Calendar cdend = Calendar.getInstance();
				cdend.setTime(enddate);
				cdend.add(Calendar.DATE, -1);
				
				req.setEndTime(Formatter.parseDate(Formatter.format(cdend.getTime(),Formatter.DATE_TIME_FORMAT),Formatter.DATE_TIME_FORMAT));
			
				WlbOrderPageGetResponse response = client.execute(req , authcode);
				
				while(true)
				{					
					if (response.getOrderList()==null || response.getOrderList().size()<=0)
					{
						k=10;						
						break;
					}

					for(Iterator it=response.getOrderList().iterator();it.hasNext();)
					{
						
						WlbOrder o=(WlbOrder) it.next();
						
						String ordercode=o.getOrderCode();
						
						String sql="select count(*) from WaitProcessOrderBak where ordercode='"+ordercode+"' and sheettype=24492";
						if (SQLHelper.intSelect(conn, sql)>0) continue;						
						
						WLBUtils.waitProcessOrder(conn, 24492, ordercode);
						
						Log.info("������������̵�ӯ�����ɹ�����������ⵥ��:"+ordercode);
					
					}
					pageno++;
					req.setPageNo(pageno);
					response=client.execute(req , authcode);
					
				}
				//ִ�гɹ�����ѭ��
				k=10;
				break;
			} catch (Exception e) {
				if (++k >= 10)
					throw e;
				Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);				
			}
		}
	}
	/*
	 * ������ӯ��
	 */
	private void ProcessInOrder(Connection conn) throws Exception
	{		
		String sql="select ordercode from WaitProcessOrder where sheettype=24492 and flag=0";
		List list=SQLHelper.multiRowListSelect(conn, sql);
		for (Iterator itordercode=list.iterator();itordercode.hasNext();)
		{
			String ordercode=(String) itordercode.next();
			for(int k=0;k<10;)
			{
				try
				{
					TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
					WlbOrderPageGetRequest req=new WlbOrderPageGetRequest();
					req.setOrderType("NORMAL_IN");
					req.setOrderCode(ordercode);
					req.setOrderSubType("CHECK");								
					req.setOrderStatus(100L);
					
					WlbOrderPageGetResponse response = client.execute(req , authcode);
					
					if (response.getOrderList()==null || response.getOrderList().size()<=0)
					{
						k=10;
						break;
					}

					for(Iterator it=response.getOrderList().iterator();it.hasNext();)
					{
						
						WlbOrder o=(WlbOrder) it.next();
						
						//String tid=o.getPrevOrderCode();
						String prevordercode=o.getPrevOrderCode();
						
						//ȡԭ�̵㵥
						sql="select count(*) from WMS_CheckProfitLoss where refsheetid='"+ordercode+"'";
						
						if (SQLHelper.intSelect(conn, sql)!=0) continue; //����Ѿ���� ��������
						
						sql="select count(*) from WMS_CheckProfitLoss0 where refsheetid='"+ordercode+"'";
						
						if (SQLHelper.intSelect(conn, sql)!=0) continue; //����Ѿ���� ��������
						
						sql="select vertifycode from IT_SystemInfo where interfacesystem='"+wlbinterfacesystem+"'";
						String owner=SQLHelper.strSelect(conn, sql);
						
						conn.setAutoCommit(false);
						
						sql="declare @Err int ; declare @NewSheetID char(16); "
							+"execute  @Err = TL_GetNewSheetID 1103, @NewSheetID output;select @NewSheetID;";			
						String commsheetid=SQLHelper.strSelect(conn, sql);
						
						String note="";
						if (o.getRemark()!=null)
							note.concat(o.getRemark());
						if (o.getOrderStatusReason()!=null)
							note.concat(" ").concat(o.getOrderStatusReason());
						note.concat("����������:"+ordercode);
						
						sql="insert into WMS_CheckProfitLoss0(sheetid,refsheetid,"
							+"owner,ManageDeptID,transfertype,flag,"
							+"editor,editdate,operator,checker,checkdate,note)"
							+"values('"+commsheetid+"','"+ordercode+"','"+owner+"',0"
							+",2449,100,'WLB',getdate(),'�ӿ�','WLB',getdate(),"
							+"'"+note+"')";
						SQLHelper.executeSQL(conn, sql);
						
						getCheckDetail(conn,commsheetid,ordercode,"IN");
						
						IntfUtils.upNote(conn, owner, commsheetid, 2449, wlbinterfacesystem, "020V10");
						
						WLBUtils.bakWaitProcessOrder(conn, 24492, ordercode);
						
						conn.commit();
						conn.setAutoCommit(true);
						
						Log.info("�������̵�ӯ�����ɹ�����������ⵥ��:"+ordercode);
						
					}
					
					//ִ�гɹ�����ѭ��
					k=10;
					break;
				} catch (Exception e) {
					if (++k >= 10)
						throw e;
					Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
					Thread.sleep(10000L);
					
				}
			}
			
		}
	}
	
	//�����̵㵥��ϸ
	
	private void getCheckDetail(Connection conn,String commsheetid,String ordercode,String pdtype) throws Exception
	{
		TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
		WlbOrderitemPageGetRequest req=new WlbOrderitemPageGetRequest();
		req.setOrderCode(ordercode);
		WlbOrderitemPageGetResponse response = client.execute(req , authcode);
		for (int i=0;i<response.getOrderItemList().size();i++)
		{
			WlbOrderItem item=response.getOrderItemList().get(i);
			
			long qty=0L;
			if (pdtype.equalsIgnoreCase("out"))
				qty=-item.getRealQuantity();
			else
				qty=item.getRealQuantity();
					
			String sql="select count(*) from WMS_CheckProfitLossItem0 "
				+"where sheetid='"+commsheetid+"' and barcodeid in"
				+"(select barcodeid from barcode where custombc='"+item.getItemCode()+"' or barcodeid='"+item.getItemCode()+"')";
			if (SQLHelper.intSelect(conn, sql)==0)
			{
				sql="insert into WMS_CheckProfitLossItem0(sheetid,customermid,barcodeid,Qty) "
					+" select '"+commsheetid+"',goodsid,barcodeid,"+qty
					+" from barcode where custombc='"+item.getItemCode()+"' or barcodeid='"+item.getItemCode()+"'";
				SQLHelper.executeSQL(conn, sql);
			}
			else
			{
				sql="update WMS_CheckProfitLossItem0 set qty=qty+"+qty
				+" where sheetid='"+commsheetid+"' and barcodeid in"
				+"(select barcodeid from barcode where custombc='"+item.getItemCode()+"' or barcodeid='"+item.getItemCode()+"')";
				SQLHelper.executeSQL(conn, sql);
			}
		}		
	}
	
}
