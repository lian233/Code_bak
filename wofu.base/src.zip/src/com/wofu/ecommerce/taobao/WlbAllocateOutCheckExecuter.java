package com.wofu.ecommerce.taobao;


import java.sql.Connection;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;


import com.taobao.api.ApiException;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;

import com.taobao.api.domain.WlbOrder;
import com.taobao.api.domain.WlbOrderItem;


import com.taobao.api.request.WlbOrderPageGetRequest;
import com.taobao.api.request.WlbOrderitemPageGetRequest;
import com.taobao.api.request.WlbTmsorderQueryRequest;

import com.taobao.api.response.WlbOrderPageGetResponse;
import com.taobao.api.response.WlbOrderitemPageGetResponse;
import com.taobao.api.response.WlbTmsorderQueryResponse;
import com.wofu.common.tools.sql.PoolHelper;
import com.wofu.common.tools.sql.SQLHelper;

import com.wofu.common.tools.util.Formatter;
import com.wofu.common.tools.util.JException;
import com.wofu.common.tools.util.StringUtil;

import com.wofu.common.tools.util.log.Log;
import com.wofu.base.job.timer.TimerJob;
import com.wofu.base.job.Executer;
import com.wofu.business.intf.IntfUtils;

public class WlbAllocateOutCheckExecuter extends Executer {

	
	private String url="";

	private String appkey="";

	private String appsecret="";

	private String authcode="";

	private String tradecontactid="";

	private String dbname="";
	
	private String wlbinterfacesystem="";

	private Date nextactive=null;

	public void execute() throws Exception {
		TimerJob job=(TimerJob) this.getExecuteobj();
		Properties prop=StringUtil.getStringProperties(job.getParams());
		
		url=prop.getProperty("url");
		appkey=prop.getProperty("appkey");
		appsecret=prop.getProperty("appsecret");
		authcode=prop.getProperty("authcode");
		tradecontactid=prop.getProperty("tradecontactid");
		dbname=prop.getProperty("dbname");
		nextactive=job.getNextactive();
		wlbinterfacesystem=prop.getProperty("wlbinterfacesystem");
		
		Connection conn=null;
		try {			 
			conn= PoolHelper.getInstance().getConnection(dbname);
			
			getAllocateOutOrder(conn,10L);
			
			getAllocateOutOrder(conn,11L);
			
			getAllocateOutOrder(conn,100L);
		
			ProcessOrder(conn);
		
		}catch (ApiException e) {
			throw new JException("����Զ�̷���ʧ��,������Ϣ:" + e.getMessage());
			
		} catch (Exception e) {
			try {
				if (conn != null && !conn.getAutoCommit())
					conn.rollback();
			} catch (Exception e1) {
				throw new JException("�ع�����ʧ��");
			}
			throw new JException("ȡ�ͷ���Ϣ"+Log.getErrorMessage(e));
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				throw new JException("�ر����ݿ�����ʧ��");
			}
		}

	}	
	private void getAllocateOutOrder(Connection conn,long status) throws Exception
	{		
		long pageno=1L;	
		for(int k=0;k<10;)
		{
			try
			{
				TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
				WlbOrderPageGetRequest req=new WlbOrderPageGetRequest();
				req.setOrderType("NORMAL_OUT");
				req.setOrderSubType("OTHER");				
				req.setPageNo(pageno);
				req.setPageSize(40L);
				req.setOrderStatus(status);
				
				Date startdate=Formatter.parseDate(Formatter.format(this.nextactive, Formatter.DATE_FORMAT)+" 00:00:00",Formatter.DATE_TIME_FORMAT);
				Calendar cdstart = Calendar.getInstance();
				cdstart.setTime(startdate);
				cdstart.add(Calendar.DATE, -1);
				
				req.setStartTime(Formatter.parseDate(Formatter.format(cdstart.getTime(),Formatter.DATE_TIME_FORMAT),Formatter.DATE_TIME_FORMAT));
			
				Date enddate=Formatter.parseDate(Formatter.format(this.nextactive, Formatter.DATE_FORMAT)+" 23:59:59",Formatter.DATE_TIME_FORMAT);
				Calendar cdend = Calendar.getInstance();
				cdend.setTime(enddate);
				cdend.add(Calendar.DATE, -1);
				
				req.setEndTime(Formatter.parseDate(Formatter.format(cdend.getTime(),Formatter.DATE_TIME_FORMAT),Formatter.DATE_TIME_FORMAT));
			
				WlbOrderPageGetResponse response = client.execute(req , authcode);
				
				while(true)
				{			
					if (response.getOrderList()==null || response.getOrderList().size()<=0)
					{
						k=10;
						break;
					}

					for(Iterator it=response.getOrderList().iterator();it.hasNext();)
					{
						
						WlbOrder o=(WlbOrder) it.next();
						
						String ordercode=o.getOrderCode();
						
						String sql="select count(*) from WaitProcessOrderBak where ordercode='"+ordercode+"' and sheettype=2342";
						if (SQLHelper.intSelect(conn, sql)>0) continue;						
						
						WLBUtils.waitProcessOrder(conn, 2342, ordercode);
						
						Log.info("����������������ɹ������������ⵥ��:"+ordercode);
					
					}
					pageno++;
					req.setPageNo(pageno);
					response=client.execute(req , authcode);
					
				}
				//ִ�гɹ�����ѭ��
				k=10;
				break;
			} catch (Exception e) {
				if (++k >= 10)
					throw e;
				Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
				
			}
		}
	}
	/*
	 * ��������
	 */
	private void ProcessOrder(Connection conn) throws Exception
	{		
		String sql="select ordercode from WaitProcessOrder where sheettype=2342 and flag=0";
		List list=SQLHelper.multiRowListSelect(conn, sql);
		for (Iterator itordercode=list.iterator();itordercode.hasNext();)
		{
			String ordercode=(String) itordercode.next();
			
			for(int k=0;k<10;)
			{
				try
				{
					TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
					WlbOrderPageGetRequest req=new WlbOrderPageGetRequest();
					req.setOrderType("NORMAL_OUT");
					req.setOrderCode(ordercode);
					req.setOrderSubType("OTHER");				
					req.setOrderStatus(100L);
										
					WlbOrderPageGetResponse response = client.execute(req , authcode);
					

						
					if (response.getOrderList()==null || response.getOrderList().size()<=0)
					{
						k=10;
						break;
					}

					for(Iterator it=response.getOrderList().iterator();it.hasNext();)
					{
						
						WlbOrder o=(WlbOrder) it.next();
						
						//String tid=o.getPrevOrderCode();
						String prevordercode=o.getPrevOrderCode();
						
						//ȡ�������ⵥ
						sql="select count(*) from wms_outstock where custompursheetid='"+ordercode+"'";
						
						if (SQLHelper.intSelect(conn, sql)!=0) continue; //����Ѿ����� ��������
						
						sql="select vertifycode from IT_SystemInfo where interfacesystem='"+wlbinterfacesystem+"'";
						String owner=SQLHelper.strSelect(conn, sql);
						
						conn.setAutoCommit(false);
						
						sql="declare @Err int ; declare @NewSheetID char(16); "
							+"execute  @Err = TL_GetNewSheetID 1103, @NewSheetID output;select @NewSheetID;";			
						String commsheetid=SQLHelper.strSelect(conn, sql);
						
						sql="declare @Err int ; declare @NewSheetID char(16); "
							+"execute  @Err = TL_GetNewSheetID 2342, @NewSheetID output;select @NewSheetID;";			
						String retsheetid=SQLHelper.strSelect(conn, sql);
						
					
						
						String note="";
						if (o.getRemark()!=null)
							note.concat(o.getRemark());
						if (o.getOrderStatusReason()!=null)
							note.concat(" ").concat(o.getOrderStatusReason());
						
						String tmscode="";
						String deliverycode="";
						if (o.getTmsTpCode()!=null)
						{
							tmscode=o.getTmsTpCode();
							deliverycode=getDeliveryCode(ordercode);
						}
					
						
						sql="insert into wms_outstock0(sheetid,refsheetid,pursheetid,"
							+"custompursheetid,owner,outid,inid,purday,transfertype,flag,"
							+"notifyOper,notifydate,operator,checker,checkdate,note,address,"
							+"linktele,linkman,delivery,deliverysheetid,zipcode)"
							+"values('"+commsheetid+"','"+retsheetid+"','"+retsheetid+"','"+ordercode+"','"+owner+"',"
							+"'020V10','020V04',30,23411,100,'WLB',getdate(),'�ӿ�','WLB',getdate(),"
							+"'"+note+"','"+o.getReceiverProvince()+" "+o.getReceiverCity()+" "
							+o.getReceiverArea()+" "+o.getReceiverAddress()+"','"+o.getReceiverPhone()+"',"
							+"'"+o.getReceiverName()+"','"+tmscode+"','"+deliverycode+"',"
							+"'"+o.getReceiverZipCode()+"')";
						SQLHelper.executeSQL(conn, sql);
						
		
						
						getOutStockDetail(conn,commsheetid,ordercode);
						
				
						
						IntfUtils.upNote(conn, owner, commsheetid, 23411, wlbinterfacesystem, "020V10");
						
						WLBUtils.bakWaitProcessOrder(conn, 2342, ordercode);
						
						conn.commit();
						conn.setAutoCommit(true);
						
						Log.info("��������������ɹ������������ⵥ��:"+ordercode+" ��������:"+retsheetid);
					
					}
					
					//ִ�гɹ�����ѭ��
					k=10;
					break;
				} catch (Exception e) {
					if (++k >= 10)
						throw e;
					Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
					Thread.sleep(10000L);
					
				}
			}
			
		}
	}
	//���������������Ż�ȡ�˵���
	private String getDeliveryCode(String ordercode) throws Exception
	{
		String logisticscode="";
		TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
		WlbTmsorderQueryRequest req=new WlbTmsorderQueryRequest();
		req.setOrderCode(ordercode);
		WlbTmsorderQueryResponse response = client.execute(req , authcode);
		if (response.getTotalCount()!=0)	
			logisticscode=response.getTmsOrderList().get(0).getCode();
		return logisticscode;
	}
	//������ⵥ��ϸ
	
	private void getOutStockDetail(Connection conn,String commsheetid,String ordercode) throws Exception
	{
		TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
		WlbOrderitemPageGetRequest req=new WlbOrderitemPageGetRequest();
		req.setOrderCode(ordercode);
		WlbOrderitemPageGetResponse response = client.execute(req , authcode);
		
		//Log.info(response.getBody());
		
		for (int i=0;i<response.getOrderItemList().size();i++)
		{
			WlbOrderItem item=response.getOrderItemList().get(i);
			long itemprice=0L;
			if 	(item.getItemPrice()!=null)
				itemprice=item.getItemPrice();
			
			String sql="select count(*) from combinebarcode where newcustombc='"+item.getItemCode()+"'";
			if (SQLHelper.intSelect(conn, sql)>0)
			{
				sql="insert into wms_outstockitem0(sheetid,customermid,"
					+"barcodeid,badflag,price,notifyqty,outqty,pknum,pkname,pkspec) "
					+" select '"+commsheetid+"',goodsid,barcodeid,1,'"+String.valueOf(Float.valueOf(itemprice)/100)
					+"',"+item.getPlanQuantity()+","+item.getRealQuantity()+",pknum,pkname,pkspec "
					+"from barcode a,combinebarcode b where (a.custombc=b.custombc and b.newcustombc='"+item.getItemCode()+"') "
					+"or (a.barcodeid=b.custombc and b.newcustombc='"+item.getItemCode()+"')";
			}
			else
			{
				sql="insert into wms_outstockitem0(sheetid,customermid,"
					+"barcodeid,badflag,price,notifyqty,outqty,pknum,pkname,pkspec) "
					+" select '"+commsheetid+"',goodsid,barcodeid,1,'"+String.valueOf(Float.valueOf(itemprice)/100)
					+"',"+item.getPlanQuantity()+","+item.getRealQuantity()+",pknum,pkname,pkspec "
					+"from barcode where custombc='"+item.getItemCode()+"' or barcodeid='"+item.getItemCode()+"'";
			}
			SQLHelper.executeSQL(conn, sql);
		}
		
	}
	
}
