package com.wofu.ecommerce.taobao;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;
import com.taobao.api.ApiException;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.domain.Order;
import com.taobao.api.domain.PurchaseOrder;
import com.taobao.api.domain.SubPurchaseOrder;
import com.taobao.api.domain.Trade;
import com.taobao.api.request.FenxiaoOrdersGetRequest;
import com.taobao.api.request.TradeCloseRequest;
import com.taobao.api.request.TradesSoldGetRequest;
import com.taobao.api.response.FenxiaoOrdersGetResponse;
import com.taobao.api.response.TradeCloseResponse;
import com.taobao.api.response.TradesSoldGetResponse;
import com.wofu.business.stock.StockManager;
import com.wofu.common.tools.sql.PoolHelper;
import com.wofu.common.tools.sql.SQLHelper;
import com.wofu.common.tools.util.Formatter;
import com.wofu.common.tools.util.JException;
import com.wofu.common.tools.util.StringUtil;
import com.wofu.common.tools.util.log.Log;
import com.wofu.base.job.timer.TimerJob;
import com.wofu.base.job.Executer;
import com.wofu.business.order.OrderManager;
import com.wofu.business.util.PublicUtils;

public class CheckDistributionOrderExecuter extends Executer {
	private String url="";

	private String appkey="";

	private String appsecret="";

	private String authcode="";

	private String tradecontactid="";

	private String dbname="";
	
	private String username="";
		
	private Date nextactive=null;
	
	private static long daymillis=24*60*60*1000L;

	@Override
	public void execute() throws Exception {
		TimerJob job=(TimerJob) this.getExecuteobj();
		Properties prop=StringUtil.getStringProperties(job.getParams());
		
		url=prop.getProperty("url");
		appkey=prop.getProperty("appkey");
		appsecret=prop.getProperty("appsecret");
		authcode=prop.getProperty("authcode");
		tradecontactid=prop.getProperty("tradecontactid");
		dbname=prop.getProperty("dbname");
		username=prop.getProperty("username");
		nextactive=job.getNextactive();
		
		Connection conn=null;
		try {			 
			conn= PoolHelper.getInstance().getConnection(dbname);
			//if (job.getNotes().indexOf("����")>=0)		
			//	authcode=TaoBaoUtils.getToken(conn, tradecontactid, appkey, appsecret);
			
			checkWaitSendGoods(conn); 
			checkClosedByTaobao(conn);		
		}catch (ApiException e) {
			//Log.error("����Ա�δ�붩��","����Զ�̷���ʧ��,������Ϣ:" + e.getMessage());
			throw new JException("����Զ�̷���ʧ��,������Ϣ:" + e.getMessage());
			
		} catch (Exception e) {
			try {
				if (conn != null && !conn.getAutoCommit())
					conn.rollback();
			} catch (Exception e1) {
				throw new JException("�ع�����ʧ��");
			}
			throw new JException("����Ա�δ�붩��"+Log.getErrorMessage(e));
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				throw new JException("�ر����ݿ�����ʧ��");
			}
		}
	}
	
	
	private void checkWaitSendGoods(Connection conn) throws Exception
	{
		
		long pageno=1L;
		
		for (int i=0;i<100;)
		{
			try
			{
				
				TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret);
				FenxiaoOrdersGetRequest req=new FenxiaoOrdersGetRequest();
				req.setStatus("WAIT_SELLER_SEND_GOODS");
				Date startdate=new Date(nextactive.getTime()-daymillis);
				Date enddate=nextactive;
				req.setStartCreated(startdate);
				req.setEndCreated(enddate);
				req.setPageNo(pageno);
				req.setPageSize(40L);
				FenxiaoOrdersGetResponse rsp = client.execute(req , authcode);
							
				while(true)
				{
					if (rsp.getPurchaseOrders()==null || rsp.getPurchaseOrders().size()<=0)
					{	
						i=100;
						break;
					}
					for(Iterator it=rsp.getPurchaseOrders().iterator();it.hasNext();)
					{
						PurchaseOrder po=(PurchaseOrder) it.next();
						
				
						Log.info(po.getId()+" "+po.getStatus()+" "+Formatter.format(po.getModified(),Formatter.DATE_TIME_FORMAT));
						
						for(Iterator ito=po.getSubPurchaseOrders().iterator();ito.hasNext();)
						{
							SubPurchaseOrder o=(SubPurchaseOrder) ito.next();
							
							StockManager.deleteWaitPayStock("����������", conn,tradecontactid, String.valueOf(po.getId()), o.getSkuOuterId());
														
						}
						
						if (!OrderManager.isCheck("����������", conn, String.valueOf(po.getId())))
						{
							if (!OrderManager.TidLastModifyIntfExists("����������", conn, String.valueOf(po.getId()),po.getModified()))
							{
								try
								{
															
									OrderUtils.createDistributionOrder("����������",conn,po,tradecontactid);
																		
									
								} catch(SQLException sqle)
								{
									throw new JException("���ɽӿڶ�������!" + sqle.getMessage());
								}
							}
						}			
					}
					pageno++;
					req.setPageNo(pageno);
					rsp=client.execute(req , authcode);
				}
				i=100;
			}catch(Exception e)
			{
				if (++i >= 100)
					throw e;
				Log.warn("Զ������ʧ��[" + i + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
			}
		}
	}
	
	private void checkClosedByTaobao(Connection conn) throws Exception
	{
		
		long pageno=1L;
		
		for (int i=0;i<10;)
		{
			try
			{
				TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret);
				FenxiaoOrdersGetRequest req=new FenxiaoOrdersGetRequest();
				req.setStatus("TRADE_CLOSED");
				Date startdate=new Date(nextactive.getTime()-daymillis);
				Date enddate=nextactive;
				req.setStartCreated(startdate);
				req.setEndCreated(enddate);
				req.setPageNo(pageno);
				req.setPageSize(40L);
				FenxiaoOrdersGetResponse rsp = client.execute(req , authcode);
				
				while(true)
				{
					if (rsp.getPurchaseOrders()==null || rsp.getPurchaseOrders().size()<=0)
					{	
						i=100;
						break;
					}
					
					for(Iterator it=rsp.getPurchaseOrders().iterator();it.hasNext();)
					{
						PurchaseOrder po=(PurchaseOrder) it.next();
						
						
						Log.info(po.getId()+" "+po.getStatus()+" "+Formatter.format(po.getModified(),Formatter.DATE_TIME_FORMAT));
						
						for(Iterator ito=po.getSubPurchaseOrders().iterator();ito.hasNext();)
						{
							SubPurchaseOrder o=(SubPurchaseOrder) ito.next();
							
							StockManager.deleteWaitPayStock("����������", conn,tradecontactid, String.valueOf(po.getId()), o.getSkuOuterId());
														
						}
					}
					pageno=pageno+1;
					req.setPageNo(pageno);
					rsp=client.execute(req , authcode);
				}
			}catch(Exception e)
			{
				if (++i >= 10)
					throw e;
				Log.warn("Զ������ʧ��[" + i + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
			}
		}
	}
	
		
}
