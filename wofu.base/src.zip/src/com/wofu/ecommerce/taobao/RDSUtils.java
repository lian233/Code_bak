package com.wofu.ecommerce.taobao;

import java.sql.Connection;
import java.util.Date;
import java.util.Iterator;


import com.wofu.base.dbmanager.DataCentre;
import com.wofu.business.order.OrderManager;
import com.wofu.business.stock.StockManager;
import com.wofu.common.json.JSONObject;
import com.wofu.common.tools.sql.JSQLException;
import com.wofu.common.tools.sql.SQLHelper;
import com.wofu.common.tools.util.Formatter;
import com.wofu.common.tools.util.JException;
import com.wofu.common.tools.util.Types;
import com.wofu.common.tools.util.log.Log;

public class RDSUtils {

	/*
	 * ת��һ���������ӿڱ�
	 */
	private static String createOrder(Connection conn,
			Trade t, String tradecontactid,String sellernick,boolean isFormal) throws Exception {
		try {

			String sheetid = "";

	
			
			conn.setAutoCommit(false);

			String sql = "declare @Err int ; declare @NewSheetID char(16); execute  @Err = TL_GetNewSheetID 1105, @NewSheetID output;select @NewSheetID;";
			sheetid = SQLHelper.strSelect(conn, sql);
			if (sheetid.trim().equals(""))
				throw new JSQLException(sql, "ȡ�ӿڵ��ų���!");

			
			// ���뵽֪ͨ��
			sql = "insert into it_downnote(Owner , sheetid , sheettype , sender , receiver , notetime , handletime) values('yongjun','"
					+ sheetid
					+ "',1 , '"
					+ tradecontactid
					+ "' , 'yongjun' , getdate() , null) ";
			SQLHelper.executeSQL(conn, sql);
			

			int haspostFee = 0;
			if (isFormal && t.getHas_post_fee()) {
				haspostFee = 1;
			}

			String promotionDetails = "";

			for (int i = 0; i <t.getPromotion_details().getRelationData().size(); i++) {
				PromotionDetail promotiondetail=(PromotionDetail) t.getPromotion_details().getRelationData().get(i);
				promotionDetails = promotionDetails
						+ promotiondetail.getPromotion_desc()
						+ ";";
			}
	
			
			int brandsaleflag = 0;

			if (t.getIs_brand_sale())
				brandsaleflag = 1;
			
			int buyerflag=0;
			int sellerflag=0;
			boolean buyerrate=false;
			boolean sellerrate=false;
			
			String sellermemo="";
			String buyermemo="";
			String tradememo="";
			String buyermessage="";
			double payment=0.00;
			double adjustfee=0.00;
			double receivedpayment=0.00;
			String promotion="";
			
			Date paytime=t.getCreated();
			
			String alipayurl="";
			
			buyermemo=t.getBuyer_memo();
			buyermessage=t.getBuyer_message();
			
			if (isFormal)
			{
				paytime=t.getPay_time();
				sellermemo=t.getSeller_memo();
				
				tradememo=t.getTrade_memo();
				
				
				payment=Double.valueOf(t.getPayment()).doubleValue();
				adjustfee=Double.valueOf(t.getAdjust_fee()).doubleValue();
				receivedpayment=Double.valueOf(t.getReceived_payment()).doubleValue();
				buyerflag=t.getBuyer_flag();
				sellerflag=t.getSeller_flag();
				buyerrate=t.getBuyer_rate();
				sellerrate=t.getSeller_rate();
				promotion=t.getPromotion();
				alipayurl=t.getAlipay_url();
			}
			
			
			sql="select isnull(value,0) from config where name='�Ա����ұ�ע�����Ƿ�ȥ����һ���ַ�'";
			int isremovefirst=Integer.valueOf(SQLHelper.strSelect(conn, sql)).intValue();
			
			
			if (isremovefirst==1 && t.getSeller_flag()==1 && !sellermemo.equals(""))
			{
				if (sellermemo.substring(0, 1).matches("[A-Za-z]"))
					sellermemo=sellermemo.substring(1);
			}
			
			

			sql = "insert into ns_customerorder"
					+ "(CustomerOrderId , SheetID , Owner , tid  , sellernick , "
					+ " type , created , buyermessage , shippingtype , payment , "
					+ " discountfee , adjustfee , status , buyermemo , sellermemo , "
					+ " tradememo , paytime , endtime , modified ,buyerobtainpointfee , "
					+ " pointfee , realpointfee , totalfee , postfee , buyeralipayno , "
					+ " buyernick , receivername , receiverstate , receivercity , receiverdistrict , "
					+ " receiveraddress , receiverzip , receivermobile , receiverphone , consigntime , "
					+ " buyeremail , haspostFee , receivedpayment , "
					+ " alipayNo , buyerflag , sellerflag,brandsaleflag,"
					+ " sellerrate , buyerrate , promotion , tradefrom , alipayurl , "
					+ " PromotionDetails,tradeContactid) "
				
					+ " values("
			
					+ "'"
					+ sheetid
					+ "','"
					+ sheetid
					+ "','"+sellernick+"','"
					+ t.getTid()
					+ "','"
					+ t.getSeller_nick()
					+ "', "
					+ "'"
					+ t.getType()
					+ "' ,'"
					+ Formatter.format(t.getCreated(),
							Formatter.DATE_TIME_FORMAT)
					+ "','"
					+ buyermessage
					+ "','"
					+ t.getShipping_type()
					+ "','"
					+ payment
					+ "', "
					+ "0.00"
					+ ", '"
					+ adjustfee
					+ "' , '"
					+ t.getStatus()
					+ "' , '"
					+ buyermemo
					+ "' ,'"
					+ sellermemo
					+ "' , "
					+ "'"
					+ tradememo
					+ "' , '"
					+ Formatter.format(paytime,
							Formatter.DATE_TIME_FORMAT)
					+ "' , '"
					+ Formatter.format(t.getModified(),
							Formatter.DATE_TIME_FORMAT)
					+ "', '"
					+ Formatter.format(t.getModified(),
							Formatter.DATE_TIME_FORMAT)
					+ "' , "
					+ t.getBuyer_obtain_point_fee()
					+ " , "
					+ t.getPoint_fee()
					+ " , "
					+ t.getReal_point_fee()
					+ " , '"
					+ t.getTotal_fee()
					+ "' , '"
					+ t.getPost_fee()
					+ "','"
					+ t.getBuyer_alipay_no()
					+ "',"
					+ "'"
					+ t.getBuyer_nick().replaceAll("'", "")
					+ "' ,'"
					+ t.getReceiver_name().replaceAll("'", "")
					+ "' , '"
					+ t.getReceiver_state()
					+ "', '"
					+ t.getReceiver_city()
					+ "' , '"
					+ t.getReceiver_district()
					+ "', "
					+ "'"
					+ t.getReceiver_address().replaceAll("'", " ")
					+ "','"
					+ t.getReceiver_zip()
					+ "' , '"
					+ t.getReceiver_mobile()
					+ "' , '"
					+ t.getReceiver_phone()
					+ "' , '"
					+ Formatter.format(t.getModified(),
							Formatter.DATE_TIME_FORMAT) + "' , " + "'"
					+ t.getBuyer_email() + "' , " + String.valueOf(haspostFee)
					+ ",'" + receivedpayment + "', " + "'"
					+ t.getAlipay_no() + "' , " + buyerflag + ","
					+ sellerflag + " , " + brandsaleflag + ", " + "'"
					+ Types.convertBooleanToShort(sellerrate) + "' , '"
					+ Types.convertBooleanToShort(buyerrate) + "' , "
					+ "'" +promotion + "', '" + t.getTrade_from()
					+ "', '" + alipayurl + "','" + promotionDetails
					+ "'," + tradecontactid + ")";


			SQLHelper.executeSQL(conn, sql);
			
	
			for (Iterator itorder = t.getOrders().getRelationData().iterator(); itorder.hasNext();) {
				Order o = (Order) itorder.next();

				if (o.getTitle().indexOf("��ɱ") >= 0
						&& o.getTitle().indexOf("���") >= 0) {
					sql = "select max(itemid) from ecs_seckill a,ecs_seckillitem b "
							+ "where a.killid=b.killid and a.sellcode='"
							+ o.getOuter_iid() + "'";
					int maxitemid = SQLHelper.intSelect(conn, sql);
					double a = Math.random() * maxitemid;
					a = Math.ceil(a);
					int randomitemid = new Double(a).intValue();

					sql = "select b.sku from ecs_seckill a,ecs_seckillitem b "
							+ "where a.killid=b.killid and a.sellcode='"
							+ o.getOuter_iid() + "' and b.itemid="
							+ randomitemid;

					String randomsku = SQLHelper.strSelect(conn, sql);

					o.setOuter_sku_id(randomsku);
				}
				
				boolean isoversold=false;
				int cid=0;
				String skuid="";
				String skuprop="";
				String outerskuid="";
				String snapshot="";
				long refundid=0L;
				outerskuid=o.getOuter_sku_id();
				if (isFormal)
				{
					isoversold=o.getIs_oversold();
					cid=o.getCid();
					skuid=o.getSku_id();
					skuprop=o.getSku_properties_name();
					snapshot=o.getSnapshot();
					refundid=o.getRefund_id();
				}

		

				sql = "insert into ns_orderitem(CustomerOrderId , orderItemId  , SheetID , skuid , itemmealname , "
						+ " title , sellernick , buyernick , type , created , "
						+ " refundstatus , outeriid , outerskuid , totalfee , payment , "
						+ " discountfee , adjustfee , status  ,"
						+ " skuPropertiesName , num , price , picPath , "
						+ " oid , snapShotUrl , snapShot , buyerRate ,sellerRate ,refundId,"
						+ "  numiid , cid , isoversold) values( "
						+ "'"
						+ sheetid
						+ "','"
						+ sheetid
						+ "_"
						+ o.getOid()
						+ "','"
						+ sheetid
						+ "','"
						+ skuid
						+ "' , '"
						+ o.getItem_meal_name()
						+ "', "
						+ "'"
						+ o.getTitle()
						+ "' , '"
						+ o.getSeller_nick()
						+ "', '"
						+ o.getBuyer_nick()
						+ "' , '"
						+ o.getSeller_type()
						+ "','"
						+ Formatter.format(t.getCreated(),
								Formatter.DATE_TIME_FORMAT)
						+ "', "
						+ "'"
						+ o.getRefund_status()
						+ "' , '"
						+ o.getOuter_iid()
						+ "' , '"
						+ outerskuid
						+ "' , '"
						+ o.getTotal_fee()
						+ "' , '"
						+ o.getPayment()
						+ "' , "
						+ "'"
						+ o.getDiscount_fee()
						+ "', '"
						+ o.getAdjust_fee()
						+ "' , '"
						+ o.getStatus()
						+ "' , "
						+ " '"
						+ skuprop
						+ "' ,"
						+ o.getNum()
						+ " , '"
						+ o.getPrice()
						+ "' , '"
						+ o.getPic_path()
						+ "' , "
						+ "'"
						+ o.getOid()
						+ "' , '"
						+ o.getSnapshot_url()
						+ "' , '"
						+ snapshot
						+ "' , '"
						+ Types.convertBooleanToShort(buyerrate)
						+ "' , '"
						+ Types.convertBooleanToShort(sellerrate)
						+ "', "
						+ refundid
						+ ","
						+ o.getNum_iid()
						+ ","
						+ cid
						+ ","
						+ Types.convertBooleanToShort(isoversold) + ")";
				SQLHelper.executeSQL(conn, sql);

			
			}
			
			conn.commit();
			conn.setAutoCommit(true);

			Log.info("���ɶ�����" + t.getTid() + "���ӿ����ݳɹ����ӿڵ��š�"
					+ sheetid + "��");

			return sheetid;

		} catch (JSQLException e1) {
			if (!conn.getAutoCommit())
				try {
					conn.rollback();
				} catch (Exception e2) {
				}
			try {
				conn.setAutoCommit(true);
			} catch (Exception e3) {
			}
			throw new JException("���ɶ�����" + t.getTid() + "���ӿ�����ʧ��!"
					+ e1.getMessage());
		}
	}


	public static void processOrder(String jobname,Connection conn, Trade td,
			String tradecontactid,String sellernick,boolean waitbuyerpayisin) throws Exception {
	

		Log.info(td.getTid()+" "+td.getStatus()+" "+Formatter.format(td.getModified(),Formatter.DATE_TIME_FORMAT));
		/*
		 *1�����״̬Ϊ�ȴ����ҷ��������ɽӿڶ���
		 *2��ɾ���ȴ���Ҹ���ʱ��������� 
		 */		
		String sku;
		String sql="";
		if (td.getStatus().equals("WAIT_SELLER_SEND_GOODS"))
		{	
			
			if (!OrderManager.isCheck("����Ա�����", conn, String.valueOf(td.getTid())))
			{
				if (!OrderManager.TidLastModifyIntfExists("����Ա�����", conn, String.valueOf(td.getTid()),td.getModified()))
				{
					createOrder(conn,td,tradecontactid,sellernick,true);
					
					for(Iterator ito=td.getOrders().getRelationData().iterator();ito.hasNext();)
					{
						Order o=(Order) ito.next();
						sku=o.getOuter_sku_id();
					
						StockManager.deleteWaitPayStock(jobname, conn,tradecontactid, String.valueOf(td.getTid()),sku);
						StockManager.addSynReduceStore(jobname, conn, tradecontactid, td.getStatus(),String.valueOf(td.getTid()), sku, -o.getNum(),false);
					}
				}
			}

			//�ȴ���Ҹ���ʱ��¼�������
		}
		
		
		else if (td.getStatus().equals("WAIT_BUYER_PAY") || td.getStatus().equals("TRADE_NO_CREATE_PAY"))
		{						
				
			if (waitbuyerpayisin)
			{
				if (!OrderManager.TidLastModifyIntfExists("����Ա�����", conn, String.valueOf(td.getTid()),td.getModified()))
				{
					createOrder(conn,td,tradecontactid,sellernick,false);
					
				}
			}
			
			for(Iterator ito=td.getOrders().getRelationData().iterator();ito.hasNext();)
			{
				Order o=(Order) ito.next();
				sku=o.getOuter_sku_id();
			
				StockManager.addWaitPayStock(jobname, conn,tradecontactid, String.valueOf(td.getTid()), sku, o.getNum());
				StockManager.addSynReduceStore(jobname, conn, tradecontactid, td.getStatus(),String.valueOf(td.getTid()), sku, -o.getNum(),false);
			}
			
		
  
			//�����Ժ��û��˿�ɹ��������Զ��ر�
			//�ͷſ��,����Ϊ����
		} else if (td.getStatus().equals("TRADE_CLOSED"))
		{					
			OrderManager.CancelOrderByCID(jobname, conn, String.valueOf(td.getTid()));
			for(Iterator ito=td.getOrders().getRelationData().iterator();ito.hasNext();)
			{
				Order o=(Order) ito.next();		
				sku=o.getOuter_sku_id();
				StockManager.deleteWaitPayStock(jobname, conn,tradecontactid, String.valueOf(td.getTid()), sku);
				
			}

			//������ǰ�����һ���������رս���
			//�ͷŵȴ���Ҹ���ʱ�����Ŀ��
		}else if (td.getStatus().equals("TRADE_CLOSED_BY_TAOBAO"))
		{
			if (waitbuyerpayisin)
			{
				
				if (!OrderManager.TidLastModifyIntfExists("����Ա�����", conn, String.valueOf(td.getTid()),td.getModified()))
				{
					createOrder(conn,td,tradecontactid,sellernick,false);
					
				}
			}


			for(Iterator ito=td.getOrders().getRelationData().iterator();ito.hasNext();)
			{
				Order o=(Order) ito.next();
				sku=o.getOuter_sku_id();
			
				 
				StockManager.deleteWaitPayStock(jobname, conn,tradecontactid, String.valueOf(td.getTid()), sku);
				
				
				if (StockManager.WaitPayStockExists(jobname,conn,tradecontactid, String.valueOf(td.getTid()), sku))//�л�ȡ���ȴ���Ҹ���״̬ʱ�żӿ��
				{
				
				
					StockManager.addSynReduceStore(jobname, conn, tradecontactid, td.getStatus(),String.valueOf(td.getTid()), sku, o.getNum(),false);
				}
			}
	
			
		
		}
		else if (td.getStatus().equals("TRADE_FINISHED"))
		{
			for(Iterator ito=td.getOrders().getRelationData().iterator();ito.hasNext();)
			{
				Order o=(Order) ito.next();
				sku=o.getOuter_sku_id();
	
				StockManager.deleteWaitPayStock(jobname, conn,tradecontactid, String.valueOf(td.getTid()), sku);								
			}

		}	
		

		
		//�����˻�
		for(Iterator oit=td.getOrders().getRelationData().iterator();oit.hasNext();)
		{						
			Order o=(Order) oit.next();	
			
		
			
			if (o.getRefund_id()>0)
			{
				sql="select count(*) from eco_rds_refund with(nolock) "
					+"where seller_nick='"+sellernick+"' and refund_id="+o.getRefund_id();
				
				if (SQLHelper.intSelect(conn, sql)==0) continue;
				
				
				Refund r=getRefund(conn,sellernick,o.getRefund_id());
				
				createRefund(conn,tradecontactid,td,o,r);
				
			}

		}

	}
	
	public static void processRefund(String jobname,Connection conn, Refund r,
			String tradecontactid,String sellernick) throws Exception {
		
		Order o=null;
		
		Trade td=getTrade(conn,sellernick,r.getTid());
		
		for(Iterator it=td.getOrders().getRelationData().iterator();it.hasNext();)
		{
			Order or=(Order) it.next();
			
			if (r.getOid()==or.getOid())
			{
				o=or;
				break;
			}
		}
		
		createRefund(conn,tradecontactid,td,o,r);
		
	}
	
	private static Trade getTrade(Connection conn,String sellernick,long tid) throws Exception
	{
		Trade td=new Trade();
		
		String sql="select top 1 jdp_response from eco_rds_trade with(nolock) "
			+"where seller_nick='"+sellernick+"' and tid="+tid+" order by modified desc";
		
		String jdpresponse=SQLHelper.strSelect(conn, sql);
		
		JSONObject jsonobj=new JSONObject(jdpresponse);
		
		JSONObject tradejsobobj=jsonobj.getJSONObject("trade_fullinfo_get_response").getJSONObject("trade");
		
		td.setObjValue(td, tradejsobobj);
		
		
		return td;
	}
	
	private static Refund getRefund(Connection conn,String sellernick,long refundid) throws Exception
	{
		Refund r=new Refund();
		
		String sql="select top 1 jdp_response from eco_rds_refund with(nolock) "
			+"where seller_nick='"+sellernick+"' and refund_id="+refundid+" order by modified desc";
		
		String jdpresponse=SQLHelper.strSelect(conn, sql);
	
		
		JSONObject jsonobj=new JSONObject(jdpresponse);
		
		JSONObject refundjsobobj=jsonobj.getJSONObject("refund_get_response").getJSONObject("refund");
		
		r.setObjValue(r, refundjsobobj);
		
		return r;
	}
	
	private static void createRefund(Connection conn, String tradecontactid,Trade td,Order o,Refund r) 
		throws Exception
	{
		
		String sql = "select shopid from ContactShopContrast with(nolock) where tradecontactid="
				+ tradecontactid;
		String inshopid = SQLHelper.strSelect(conn,sql);
		

			
		String outerskuid=o.getOuter_sku_id();
		

		sql = "declare @Err int ; declare @NewSheetID char(16); "
				+ "execute  @Err = TL_GetNewSheetID 1105, @NewSheetID output;select @NewSheetID;";
		String sheetid = SQLHelper.strSelect(conn, sql);
	
		// ���뵽֪ͨ��
		sql = "insert into it_downnote(Owner,sheetid,sheettype,sender,receiver,notetime,handletime) "
				+ "values('yongjun','"
				+ sheetid
				+ "',2 , '"
				+ tradecontactid + "','yongjun', getdate(),null) ";
		SQLHelper.executeSQL(conn,sql);
	
		sql = "insert into ns_Refund(SheetID , RefundID , Oid , AlipayNo , "
				+ "BuyerNick , Created , Modified , OrderStatus , Status , GoodStatus , "
				+ " HasGoodReturn ,RefundFee , Payment , Reason,Description , Title ,"
				+ "Price , Num , GoodReturnTime , Sid , "
				+ " TotalFee ,  OuterIid , OuterSkuId , CompanyName , "
				+ "Address , ReturnAddress , InShopID , Tid , LinkMan , LinkTele,BuyerAlipayNo)"
				+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		String address="";
		String sid="";
		String companyname="";
		if (r.getAddress()!=null) address=r.getAddress();
		if (r.getSid()!=null) sid=r.getSid();
		if (r.getCompany_name()!=null) companyname=r.getCompany_name();
		
		Object[] sqlv = {
				sheetid,
				r.getRefund_id(),
				r.getOid(),
				r.getAlipay_no(),
				r.getBuyer_nick(),
				r.getCreated(),
				r.getModified(),
				r.getOrder_status(),
				r.getStatus(),
				r.getGoods_status(),
				Types.convertBooleanToShort(r.getHas_goods_return()),
				r.getRefund_fee(),
				r.getPayment(),
				r.getReason(),
				r.getDesc(),
				r.getTitle(),
				r.getPrice(),
				r.getNum(),
				r.getGoods_return_time(),
				sid,
				r.getTotal_fee(),
				o.getOuter_iid(),
				outerskuid,
				companyname,
				address,
				td.getReceiver_state() + " " + td.getReceiver_city() + " "
						+ td.getReceiver_district() + " "
						+ td.getReceiver_address(), inshopid, r.getTid(),
						td.getReceiver_name(),
						td.getReceiver_phone() + " " + td.getReceiver_mobile(),
						td.getBuyer_alipay_no() };
	
		SQLHelper.executePreparedSQL(conn, sql, sqlv);
		
		
		Log.info("�ӿڵ���:"+ sheetid+ " ������:"+ r.getTid()+ " ����״̬��"
				+ r.getStatus()+ " �˿�״̬:"+ r.getStatus()+ " ��������ʱ��:"
				+ Formatter.format(td.getCreated(),
						Formatter.DATE_TIME_FORMAT));
		
	}
		
		

}
