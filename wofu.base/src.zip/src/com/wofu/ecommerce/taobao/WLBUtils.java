package com.wofu.ecommerce.taobao;

import java.sql.Connection;

import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.request.WlbItemQueryRequest;
import com.taobao.api.response.WlbItemQueryResponse;
import com.wofu.common.tools.sql.SQLHelper;
import com.wofu.common.tools.util.log.Log;

public class WLBUtils {

	public static int getItemIDBySku(String sku) throws Exception
	{
		
		TaobaoClient client=new DefaultTaobaoClient(Params.url,Params.appkey,Params.appsecret,"xml");
		WlbItemQueryRequest req=new WlbItemQueryRequest();
		req.setItemCode(sku);
		req.setIsSku("true");
		WlbItemQueryResponse response = client.execute(req , Params.authcode);

		return response.getItemList().get(0).getId().intValue();
	}
	
	public static void waitProcessOrder(Connection conn,int sheettype,String ordercode) throws Exception
	{	
		boolean isexists=false;
		String sql="select count(*) from WaitProcessOrder with(nolock) "
			+"where sheettype="+sheettype+" and ordercode='"+ordercode+"'";
		if (SQLHelper.intSelect(conn, sql)>0)
			isexists=true;
		if (!isexists)
		{
			sql="select count(*) from WaitProcessOrderBak with(nolock) "
				+"where sheettype="+sheettype+" and ordercode='"+ordercode+"'";
			if (SQLHelper.intSelect(conn, sql)>0)
				isexists=true;
		}
			
		if (!isexists)
		{
			sql="insert into WaitProcessOrder(sheettype,ordercode,flag) "
				+"values("+sheettype+",'"+ordercode+"',0)";
			SQLHelper.executeSQL(conn, sql);
		}
	}
	
	public static void bakWaitProcessOrder(Connection conn,int sheettype,String ordercode) throws Exception
	{
		conn.setAutoCommit(false); //��ʼ����
		String sql="update WaitProcessOrder set flag=1 "
			+"where sheettype="+sheettype+" and ordercode='"+ordercode+"'";
		SQLHelper.executeSQL(conn,sql);
		
		sql="insert into WaitProcessOrderBak select * from WaitProcessOrder "
			+"where sheettype="+sheettype+" and ordercode='"+ordercode+"'";
		SQLHelper.executeSQL(conn,sql);
		
		sql="delete from WaitProcessOrder "
			+"where sheettype="+sheettype+" and ordercode='"+ordercode+"'";
		SQLHelper.executeSQL(conn,sql);
		
		conn.commit(); //�ύ����
		conn.setAutoCommit(true); //�ָ������Զ�ִ��
		
	}
}
