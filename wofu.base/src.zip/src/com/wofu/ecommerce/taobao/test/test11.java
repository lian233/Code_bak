
package com.wofu.ecommerce.taobao.test;

import java.io.File;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.taobao.api.ApiException;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.domain.Chatpeer;
import com.taobao.api.domain.Item;
import com.taobao.api.domain.Order;
import com.taobao.api.domain.PromotionDetail;
import com.taobao.api.domain.Sku;
import com.taobao.api.domain.Trade;
import com.taobao.api.domain.WlbOrder;
import com.taobao.api.domain.WlbTmsOrder;
import com.taobao.api.request.FenxiaoCooperationGetRequest;
import com.taobao.api.request.FenxiaoDistributorsGetRequest;
import com.taobao.api.request.FenxiaoOrdersGetRequest;
import com.taobao.api.request.FenxiaoProductUpdateRequest;
import com.taobao.api.request.FenxiaoProductsGetRequest;
import com.taobao.api.request.IncrementCustomerPermitRequest;
import com.taobao.api.request.ItemAddRequest;
import com.taobao.api.request.ItemGetRequest;
import com.taobao.api.request.ItemQuantityUpdateRequest;
import com.taobao.api.request.ItemSkuAddRequest;
import com.taobao.api.request.ItemSkuGetRequest;
import com.taobao.api.request.ItemcatsAuthorizeGetRequest;
import com.taobao.api.request.ItemcatsGetRequest;
import com.taobao.api.request.ItemsCustomGetRequest;
import com.taobao.api.request.ItemsInventoryGetRequest;
import com.taobao.api.request.ItemsOnsaleGetRequest;
import com.taobao.api.request.LogisticsCompaniesGetRequest;
import com.taobao.api.request.LogisticsConsignResendRequest;
import com.taobao.api.request.LogisticsOfflineSendRequest;
import com.taobao.api.request.LogisticsOnlineCancelRequest;
import com.taobao.api.request.LogisticsOnlineSendRequest;
import com.taobao.api.request.MarketingPromotionsGetRequest;
import com.taobao.api.request.ProductsGetRequest;
import com.taobao.api.request.ProductsSearchRequest;
import com.taobao.api.request.PromotionActivityGetRequest;
import com.taobao.api.request.PromotionCoupondetailGetRequest;
import com.taobao.api.request.PromotionCouponsGetRequest;
import com.taobao.api.request.RdsDbCreateRequest;
import com.taobao.api.request.RdsDbGetRequest;
import com.taobao.api.request.RefundsReceiveGetRequest;
import com.taobao.api.request.SellercenterSubusersGetRequest;
import com.taobao.api.request.SkusCustomGetRequest;
import com.taobao.api.request.TradeFullinfoGetRequest;
import com.taobao.api.request.TradeGetRequest;
import com.taobao.api.request.TradeMemoAddRequest;
import com.taobao.api.request.TradeMemoUpdateRequest;
import com.taobao.api.request.TradesSoldGetRequest;
import com.taobao.api.request.TradesSoldIncrementGetRequest;
import com.taobao.api.request.UserGetRequest;
import com.taobao.api.request.WangwangEserviceAvgwaittimeGetRequest;
import com.taobao.api.request.WangwangEserviceChatpeersGetRequest;
import com.taobao.api.request.WangwangEserviceEvaluationGetRequest;
import com.taobao.api.request.WangwangEserviceLoginlogsGetRequest;
import com.taobao.api.request.WangwangEserviceReceivenumGetRequest;
import com.taobao.api.request.WlbInventoryDetailGetRequest;
import com.taobao.api.request.WlbInventorySyncRequest;
import com.taobao.api.request.WlbInventorylogQueryRequest;
import com.taobao.api.request.WlbItemAddRequest;
import com.taobao.api.request.WlbItemDeleteRequest;
import com.taobao.api.request.WlbItemGetRequest;
import com.taobao.api.request.WlbItemMapGetByExtentityRequest;
import com.taobao.api.request.WlbItemMapGetRequest;
import com.taobao.api.request.WlbItemQueryRequest;
import com.taobao.api.request.WlbItemSynchronizeDeleteRequest;
import com.taobao.api.request.WlbItemSynchronizeRequest;
import com.taobao.api.request.WlbItemUpdateRequest;
import com.taobao.api.request.WlbNotifyMessageConfirmRequest;
import com.taobao.api.request.WlbNotifyMessagePageGetRequest;
import com.taobao.api.request.WlbOrderCancelRequest;
import com.taobao.api.request.WlbOrderConsignRequest;
import com.taobao.api.request.WlbOrderCreateRequest;
import com.taobao.api.request.WlbOrderPageGetRequest;
import com.taobao.api.request.WlbOrderitemPageGetRequest;
import com.taobao.api.request.WlbOrderstatusGetRequest;
//import com.taobao.api.request.WlbOutInventoryChangeNotifyRequest;
import com.taobao.api.request.WlbSubscriptionQueryRequest;
import com.taobao.api.request.WlbTmsorderQueryRequest;
import com.taobao.api.request.WlbTradeorderGetRequest;
import com.taobao.api.request.WlbWlborderGetRequest;
import com.taobao.api.response.FenxiaoCooperationGetResponse;
import com.taobao.api.response.FenxiaoDistributorsGetResponse;
import com.taobao.api.response.FenxiaoOrdersGetResponse;
import com.taobao.api.response.FenxiaoProductUpdateResponse;
import com.taobao.api.response.FenxiaoProductsGetResponse;
import com.taobao.api.response.IncrementCustomerPermitResponse;
import com.taobao.api.response.ItemAddResponse;
import com.taobao.api.response.ItemGetResponse;
import com.taobao.api.response.ItemQuantityUpdateResponse;
import com.taobao.api.response.ItemSkuAddResponse;
import com.taobao.api.response.ItemSkuGetResponse;
import com.taobao.api.response.ItemcatsAuthorizeGetResponse;
import com.taobao.api.response.ItemcatsGetResponse;
import com.taobao.api.response.ItemsCustomGetResponse;
import com.taobao.api.response.ItemsInventoryGetResponse;
import com.taobao.api.response.ItemsOnsaleGetResponse;
import com.taobao.api.response.LogisticsCompaniesGetResponse;
import com.taobao.api.response.LogisticsConsignResendResponse;
import com.taobao.api.response.LogisticsOfflineSendResponse;
import com.taobao.api.response.LogisticsOnlineCancelResponse;
import com.taobao.api.response.LogisticsOnlineSendResponse;
import com.taobao.api.response.MarketingPromotionsGetResponse;
import com.taobao.api.response.ProductsGetResponse;
import com.taobao.api.response.ProductsSearchResponse;
import com.taobao.api.response.PromotionActivityGetResponse;
import com.taobao.api.response.PromotionCoupondetailGetResponse;
import com.taobao.api.response.PromotionCouponsGetResponse;
import com.taobao.api.response.RdsDbCreateResponse;
import com.taobao.api.response.RdsDbGetResponse;
import com.taobao.api.response.RefundsReceiveGetResponse;
import com.taobao.api.response.SellercenterSubusersGetResponse;
import com.taobao.api.response.SkusCustomGetResponse;
import com.taobao.api.response.TradeFullinfoGetResponse;
import com.taobao.api.response.TradeGetResponse;
import com.taobao.api.response.TradeMemoAddResponse;
import com.taobao.api.response.TradeMemoUpdateResponse;
import com.taobao.api.response.TradesSoldGetResponse;
import com.taobao.api.response.TradesSoldIncrementGetResponse;
import com.taobao.api.response.UserGetResponse;
import com.taobao.api.response.WangwangEserviceAvgwaittimeGetResponse;
//import com.taobao.api.response.WangwangEserviceChatlogGetResponse;
import com.taobao.api.response.WangwangEserviceChatpeersGetResponse;
import com.taobao.api.response.WangwangEserviceEvaluationGetResponse;
import com.taobao.api.response.WangwangEserviceLoginlogsGetResponse;
import com.taobao.api.response.WlbInventoryDetailGetResponse;
import com.taobao.api.response.WlbInventorySyncResponse;
import com.taobao.api.response.WlbInventorylogQueryResponse;
import com.taobao.api.response.WlbItemAddResponse;
import com.taobao.api.response.WlbItemDeleteResponse;
import com.taobao.api.response.WlbItemGetResponse;
import com.taobao.api.response.WlbItemMapGetByExtentityResponse;
import com.taobao.api.response.WlbItemMapGetResponse;
import com.taobao.api.response.WlbItemQueryResponse;
import com.taobao.api.response.WlbItemSynchronizeDeleteResponse;
import com.taobao.api.response.WlbItemSynchronizeResponse;
import com.taobao.api.response.WlbItemUpdateResponse;
import com.taobao.api.response.WlbNotifyMessageConfirmResponse;
import com.taobao.api.response.WlbNotifyMessagePageGetResponse;
import com.taobao.api.response.WlbOrderCancelResponse;
import com.taobao.api.response.WlbOrderConsignResponse;
import com.taobao.api.response.WlbOrderCreateResponse;
import com.taobao.api.response.WlbOrderPageGetResponse;
import com.taobao.api.response.WlbOrderitemPageGetResponse;
import com.taobao.api.response.WlbOrderstatusGetResponse;
//import com.taobao.api.response.WlbOutInventoryChangeNotifyResponse;
import com.taobao.api.response.WlbSubscriptionQueryResponse;
import com.taobao.api.response.WlbTmsorderQueryResponse;
import com.taobao.api.response.WlbTradeorderGetResponse;
import com.taobao.api.response.WlbWlborderGetResponse;
import com.wofu.ecommerce.taobao.OrderUtils;
import com.wofu.ecommerce.taobao.Params;
import com.wofu.ecommerce.taobao.WLBUtils;
import com.wofu.business.stock.StockManager;
import com.wofu.common.tools.sql.SQLHelper;
import com.wofu.common.tools.util.DOMHelper;
import com.wofu.common.tools.util.FileUtil;
import com.wofu.common.tools.util.Formatter;
import com.wofu.common.tools.util.JException;
import com.wofu.common.tools.util.log.Log;

public class test11{
	
	/**
	 * @param args
	 */
	//private static String appkey="12084299";
	//private static String appsecret="719357e3e705802099675d679a52b0ec";	
	//private static String authcode="6100d2629fe5982e35411c979127c9fcfe158d013d8e255422229230";
	
	//׿��B��
	//private static String appkey="21500560";
	//private static String appsecret="5ffa149facb5a07c769c494ca037d4b3";	
	//private static String authcode="6100a12d1011350150351dbcf4fb552c923f117fd77b5dd1629289588";
	
	//����B��
	///private static String appkey="12392353";
	//private static String appsecret="870df3e9a5b9b89c10c25fb07e2839ca";	
	//private static String authcode="6101f103b72dca951e165df0fcaa5cdc08c92f657bd27e9411367952";
	
	//����c1��
	//private static String appkey="12502231";
	//private static String appsecret="9e7fd2f0097be4b6d18de4301010697f";	
	//private static String authcode="61029274ad385406742f3f4a958c019f29b1c62a4145f1888064727";
	
	
	//����c2��
	//private static String appkey="21037852";
	//private static String appsecret="4d15fd9cfac2bdc4f0344d6735694bcc";	
	//private static String authcode="610131593ae3157f533bef512e2b6a68321bb5f012d17bc911668221";
	
	 
	//B��
	
	//private static String appkey="21158455";
	//private static String appsecret="f3f157ed454c6d8b450c6fad563d4403";
	//private static String authcode="62015063461e22ZZ3b2cddfbbd76fee7e68e8589ebf6c3d673637734";
	//����C��

	//private static String appkey="21004635";
	//private static String appsecret="d2337241d667bbc6ab3fc159c6a719a6";
	//private static String authcode="6102a291aafcf66fb546e249bdbe12bc954e0178a49ec1a714300664";
	//��װ��
	
	//private static String appkey="21004635";
	//private static String appsecret="d2337241d667bbc6ab3fc159c6a719a6";
	//private static String authcode="6101a137adb9104bea09d1cef7102f59fc2ae40d59fbca8714300664";
	//Ůװ��
	
	//private static String appkey="12348167";
	//private static String appsecret="8bcb2cf3cdf1e7d07d6213b108b9d0b0";
	//private static String authcode="6100515b77b501a1bf6b68118f7211a1a9790280b795299707994264";
	//�콢��
		
	
	///private static String appkey="12205522";
	//private static String appsecret="0d56c9fb65cf8eb136437b02f52846fa";
	//private static String authcode="6100405c8c07719f5c11302dfad9e209182365e1ca66bbc673973064";
	//C��
	
	//private static String appkey="12392353";
	//private static String appsecret="870df3e9a5b9b89c10c25fb07e2839ca";
	//private static String authcode="62007052d9d48ZZ550ac13a4d71535363136f614e8331f150759571";
	//����C��
		
	
	private static String appkey="21520535";
	private static String appsecret="766bce17fd8ac852ea02a740277f1289";
	private static String authcode="62007052d9d48ZZ550ac13a4d71535363136f614e8331f150759571";
	//���������Ȩ
	
	private static String url="http://gw.api.taobao.com/router/rest";
	
	//private static String appsecret="sandbox3e705802099675d679a52b0ec";	
	//private static String url="http://gw.api.tbsandbox.com/router/rest";
	//ɳ��
	private static String TradeFields="seller_nick,buyer_nick,title,type,created,tid,"
		+"seller_rate,buyer_flag,buyer_rate,status,payment,"
		+"adjust_fee,post_fee,total_fee,pay_time,end_time,modified,"
		+"consign_time,buyer_obtain_point_fee,point_fee,real_point_fee,"
		+"received_payment,commission_fee,buyer_memo,seller_memo,"
		+"alipay_no,buyer_message,pic_path,num_iid,num,price,buyer_alipay_no,"
		+"receiver_name,receiver_state,receiver_city,receiver_district,"
		+"receiver_address,receiver_zip,receiver_mobile,receiver_phone,is_brand_sale,"
		+"buyer_email,seller_flag,seller_alipay_no,seller_mobile,trade_from,"
		+"seller_phone,seller_name,seller_email,available_confirm_fee,alipay_url,"
		+"has_post_fee,timeout_action_time,Snapshot,snapshot_url,cod_fee,cod_status,"
		+"shipping_type,trade_memo,is_3D,buyer_email,buyer_memo,buyer_flag,promotion,promotion_details,orders";	
	
	public String bb="5345";
	
	public static void main(String[] args) throws Exception {
			
		//Connection conn=getConnection();
		
	
				
		//getWangwanglogin();
		//resend();
		//getSellerTrade();
		//getTradeList();
		//getTradeGet();
		
		//getItemByCustom("039535B");
		
		/*
		Connection conn=getConnection();
		String sql="select customno from tmpsku";
		List culist=SQLHelper.multiRowListSelect(conn, sql);
		for (int i=0;i<culist.size();i++)
		{
			String customno=(String) culist.get(i);
			
			getItemByCustom(conn,customno);
			
			
			/*
			for(int j=0;j<skulist.size();j++)
			{
				String sku=(String) skulist.get(j);
				
				int qty=StockManager.getTradeContactUseableStock(conn, 1, sku);
				
				qty=qty-5;
				
				//if (qty<0) qty=0;
				
				//updateStock(conn,sku,qty);
				
				//Log.info("���¿��ɹ�,SKU:"+sku+" ����:"+qty);
			}
			*/
			/*
			sql="delete from tmpsku where customno='"+customno+"'";
			SQLHelper.executeSQL(conn, sql);
			
			Log.info("���»��ſ��ɹ�:"+customno);
		}
		*/
		//getCategory();
		//itemAdd();
		//skuAdd();
		//getAllItems();
		//getAllSku();
		getFullTrade();
		//getItemDetail();
		//getItemByCustom("J43510L");
		//addMemo();
		//getItemsGet();
		//getItemsSearchGet();
		//getItemsOnSaleGet();
		//getItemsInventoryGet();
		//permitIncrement();
		//createRDSDB();
		//getRDSDB();
		//getProducts();
		//searchProducts();
		//getSKUDetail();
		//getTradeFullInfo();
		//getSubUsers();
		//getChatpeers();
		//getchatrecord();
		//getchatlog();
		//getAvgWaitTime();
		//getevaluation();
		//WlbItemAdd();
		//WlbItemDelete();
		//WlbItemQuery();
		//WlbItemGet();
		//WlbSynStock();
		//WlbSynInventory();
		//WlbGetItemDetail();
		//WlbOrderConsign();
		//WlbItemSynchronize();
		//WlbItemGetByExtEntity();
		//WlbItemMapGet();
		//WlbItemSynchronizeDelete();
		//WlbCreatePurchaseOrder();
		//WlbCreateCheckOrder();
		//WlbGetReceivePurcharOrder();
		//WlbCreateTradeOrder();
		//WlbGetOrderByTradeCode();
		//WlbCreateExchangeOrder();
		//WlbCreateAllcoateOrder();
		//WlbGetDeliveryOrder();
		//WlbGetOrderDetail();
		//OrderDelivery();
		//CancelOrderDelivery();
		//WlbGetTMSInfo();
		//getWLBOrderTMSInfo();
		//getLogisticsCompanies();
		//WlbGetWlborder();
		//WlbOrderGet();
		//WlbOrderItemGet();
		//WlbTradeOrderGet();
		//WlbOrderstatusGet();
		//WlbGetHistoryInventory();
		//getOrderDetail();
		//WlbCreateOutSheet();
		//WblCancelOrder();
		//WlbCreateReturnOrder();
		//WlbGetReturnOrder();
		//getSubscription();
		//updateItem();
		//getMessage();
		//confirmMessage();
		//getFenXiaoOrders();
		//getDistributor();
		//getDistributorDetail();
		//getRefund();
		//getDistributionProducts();
		//updateDistributionStock();
		//getUserInfo();
		//getCouponDetail();
		//getCouponActive();
		//getCoupon();
		/*
		try
		{
			System.out.println(Formatter.format(new Date(), Formatter.DATE_FORMAT));
			Date sdate=Formatter.parseDate(Formatter.format(new Date(), Formatter.DATE_FORMAT)+" 00:00:00",Formatter.DATE_TIME_FORMAT);
			Calendar cd = Calendar.getInstance();
			cd.setTime(sdate);
			cd.add(Calendar.DATE, -1);
			System.out.println(Formatter.parseDate(Formatter.format(cd.getTime(),Formatter.DATE_TIME_FORMAT),Formatter.DATE_TIME_FORMAT));
		}catch(Exception e)
		{
			e.printStackTrace();
		}*/
	}
	
	private static Connection getConnection() throws Exception
	{

		String driver="com.microsoft.jdbc.sqlserver.SQLServerDriver";
		String url="jdbc:microsoft:sqlserver://172.20.11.20:1433;DatabaseName=erpmcbmstock";
		String user="admin";
		String password="yongjun2006WMS";
		 
		if (driver != null && !driver.equals("")) {
			DriverManager.registerDriver(
				(Driver) Class.forName(driver).newInstance());
		}
		if (user != null) {
			return DriverManager.getConnection(url, user, password);
		} else {
			return DriverManager.getConnection(url);
		}
			
	}
	//��ͨ�������ͷ���
	private static void permitIncrement() throws Exception
	{
	
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
			IncrementCustomerPermitRequest  req=new IncrementCustomerPermitRequest();	
			req.setType("get,syn,notify");
			IncrementCustomerPermitResponse rsp = client.execute(req, authcode);
			//System.out.println(rsp.getSubMsg());			
			System.out.println(rsp.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
		
	}
	//����RDS���ݿ�
	private static void createRDSDB() throws Exception
	{
	
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
			RdsDbCreateRequest  req=new RdsDbCreateRequest();	
			req.setInstanceName("ins_000069h8k7");
			req.setDbName("erpnsbmconnect");
			RdsDbCreateResponse rsp = client.execute(req, authcode);
			//System.out.println(rsp.getSubMsg());			
			System.out.println(rsp.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
		
	}
	
	//ȡ��RDS���ݿ�
	private static void getRDSDB() throws Exception
	{
	
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
			RdsDbGetRequest  req=new RdsDbGetRequest();	
			req.setInstanceName("ins_000069h8k7");			
			RdsDbGetResponse rsp = client.execute(req, authcode);
			//System.out.println(rsp.getSubMsg());			
			System.out.println(rsp.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
		
	}
	
	private static void getFullTrade() throws Exception
	{
		Trade td=OrderUtils.getFullTrade("427770886197186", url, appkey, appsecret, authcode);

		//System.out.println(TranTid("143049524294834c"));
		//122735342942212
	}
	//��ѯ�Żݾ�
	private static void getCouponDetail() throws Exception
	{
	
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
			PromotionCoupondetailGetRequest  req=new PromotionCoupondetailGetRequest();	
			req.setBuyerNick("pennyw2011");
			req.setCouponId(5565117L);
			PromotionCoupondetailGetResponse rsp = client.execute(req, authcode);
			//System.out.println(rsp.getSubMsg());			
			System.out.println(rsp.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
		
	}
	private static void getCoupon() throws Exception
	{
	
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
			PromotionCouponsGetRequest  req=new PromotionCouponsGetRequest();	

			PromotionCouponsGetResponse rsp = client.execute(req, authcode);
			System.out.println(rsp.getBody());			
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
		
	}
	private static void getCouponActive() throws Exception
	{
	
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
			PromotionActivityGetRequest  req=new PromotionActivityGetRequest();	
			req.setActivityId(22332328L);
			PromotionActivityGetResponse rsp = client.execute(req, authcode);
			System.out.println(rsp.getBody());			
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
		
	}
	
	 
	
	//��ѯ�����ɹ���
	private static void getUserInfo() throws Exception
	{
	
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
			UserGetRequest  req=new UserGetRequest();	
			req.setFields("user_id,uid,nick,sex,buyer_credit,seller_credit,location,created,last_visit,birthday,type,has_more_pic,item_img_num,item_img_size,prop_img_num,prop_img_size,auto_repost,promoted_type,status,alipay_bind,consumer_protection,alipay_account,alipay_no,avatar,liangpin,sign_food_seller_promise,has_shop,is_lightning_consignment,has_sub_stock,is_golden_seller,vip_info,email,magazine_subscribe,vertical_market,online_gaming");
			req.setNick("zhangjiecsu");
			UserGetResponse rsp = client.execute(req, authcode);
			System.out.println(rsp.getBody());
			if (rsp.getUser()==null)
				System.out.println("���˺Ų���������");
			else
				System.out.println(rsp.getUser());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
		
	}
	
	//��ѯ�����ɹ���
	private static void getFenXiaoOrders() throws Exception
	{
	
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
			FenxiaoOrdersGetRequest  req=new FenxiaoOrdersGetRequest();	
			//req.setStatus("WAIT_SELLER_SEND_GOODS");
			Date startdate=new Date(Formatter.parseDate("2013-07-01 00:00:00",Formatter.DATE_TIME_FORMAT).getTime()+1000L);
			Date enddate=new Date(Formatter.parseDate("2013-07-05 00:00:00",Formatter.DATE_TIME_FORMAT).getTime());
			//req.setStartCreated(startdate);
			//req.setEndCreated(enddate);
			req.setPurchaseOrderId(1718890218768L);
			//req.setPageSize(50L);
			//req.setTcOrderId(421200438697676L);
			FenxiaoOrdersGetResponse rsp = client.execute(req, authcode);
	        System.out.println(rsp.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
		
	}
	//��ȡ�������б�
	private static void getDistributor() throws Exception
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
			FenxiaoCooperationGetRequest  req=new FenxiaoCooperationGetRequest();	
			FenxiaoCooperationGetResponse rsp = client.execute(req, authcode);
	        System.out.println(rsp.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	//��ȡ��������ϸ��Ϣ
	private static void getDistributorDetail() throws Exception
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
			FenxiaoDistributorsGetRequest  req=new FenxiaoDistributorsGetRequest();	
			req.setNicks("������");
			FenxiaoDistributorsGetResponse rsp = client.execute(req, authcode);
	        System.out.println(rsp.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	//��ȡ�˿�
	private static void getRefund() throws Exception
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
			RefundsReceiveGetRequest  req=new RefundsReceiveGetRequest();	
			req.setFields("refund_id, alipay_no, tid, oid, buyer_nick, seller_nick,"
									+"total_fee,order_status,iid, status, created,modified, refund_fee,"
									+"good_status, has_good_return, payment, reason, desc, num_iid, "
									+"title, price, num, good_return_time, company_name, sid, address,"
									+"shipping_type, refund_remind_timeout");
			RefundsReceiveGetResponse rsp = client.execute(req, authcode);
	        System.out.println(rsp.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	//��ȡ������Ʒ
	private static void getDistributionProducts() throws Exception
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
			FenxiaoProductsGetRequest  req=new FenxiaoProductsGetRequest();
			req.setFields("skus");
			//Date startdate=new Date(Formatter.parseDate("2012-04-13 09:00:00",Formatter.DATE_TIME_FORMAT).getTime()+1000L);
			//Date enddate=new Date(Formatter.parseDate("2012-04-13 12:00:00",Formatter.DATE_TIME_FORMAT).getTime());
			//req.setStartModified(startdate);
			//req.setEndModified(enddate);
			//req.setSkuNumber("UB22211010PAC");
			req.setOuterId("GF197201");
			req.setPageSize(2L);
			FenxiaoProductsGetResponse rsp = client.execute(req, authcode);
	        System.out.println(rsp.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	private static void updateDistributionStock() throws Exception
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
			FenxiaoProductUpdateRequest updatereq=new FenxiaoProductUpdateRequest();
			updatereq.setPid(250853543671L);
			updatereq.setSkuIds("1071708223671");
			updatereq.setSkuOuterIds("LV001101AA");
			updatereq.setSkuQuantitys("0");
		
			FenxiaoProductUpdateResponse response = client.execute(updatereq,authcode);
			
	        System.out.println(response.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	
	//��ѯ����������Ϣ
	private static void getSubscription()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
			WlbSubscriptionQueryRequest req=new WlbSubscriptionQueryRequest();	
			req.setStatus("CHECKED");
	        WlbSubscriptionQueryResponse rsp = client.execute(req, authcode);
	        System.out.println(rsp.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	//������Ʒ��Ϣ
	
	private static void updateItem()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
			WlbItemUpdateRequest req=new WlbItemUpdateRequest();	
			req.setId(124000000015453L);
			req.setTitle("��ʿ��Disney�������ר����ƷPU�����ᵥ���ִ�Ů��UF52653-AN");
			req.setName("����2");
			//req.setStatus("CHECKED");
	        WlbItemUpdateResponse rsp = client.execute(req, authcode);
	        System.out.println(rsp.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	//��������Ϣ��ѯ	
	private static void getMessage()
	{
		long pageno=1L;	
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
			WlbNotifyMessagePageGetRequest req=new WlbNotifyMessagePageGetRequest();	
			req.setPageNo(pageno);
			req.setPageSize(40L);
			req.setStartDate(Formatter.parseDate("2011-11-04 13:00:00", Formatter.DATE_TIME_FORMAT));
			while(true)
			{
				WlbNotifyMessagePageGetResponse rsp = client.execute(req, authcode);
				if (rsp.getWlbMessages()==null || rsp.getWlbMessages().size()==0)
					break;
		        System.out.println(rsp.getBody());
		        pageno++;
				req.setPageNo(pageno);
				rsp=client.execute(req , authcode);
			}
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	//��������Ϣȷ��
	private static void confirmMessage()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
			WlbNotifyMessageConfirmRequest req=new WlbNotifyMessageConfirmRequest();	
			req.setMessageId(9034564L);
			WlbNotifyMessageConfirmResponse rsp = client.execute(req, authcode);
	        System.out.println(rsp.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	private static void getOrderDetail()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
			TradeFullinfoGetRequest req=new TradeFullinfoGetRequest();	
			req.setFields(TradeFields);
	        req.setTid(179719633106020L);
	        TradeFullinfoGetResponse rsp = client.execute(req, authcode);
	        System.out.println(rsp.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	
	private static void getCategory()
	{
		try
		{
			
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			ItemcatsGetRequest reqitems=new ItemcatsGetRequest();
			reqitems.setFields("cid,name,is_parent");
			reqitems.setParentCid(50006842L);
			ItemcatsGetResponse rspitems = client.execute(reqitems , authcode);			
			System.out.println(rspitems.getBody());			

		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	private static void itemAdd()
	{
		try
		{
			
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			ItemAddRequest reqitems=new ItemAddRequest();
			reqitems.setNum(100L);
			reqitems.setType("fixed");
			reqitems.setPrice("112.00");
			reqitems.setStuffStatus("new");
			reqitems.setTitle("��Ʒ����2");
			reqitems.setDesc("��ʿ��Disney����Ǯ��ר����ƷPU�������ݳ���Ůʿ����UP2585-02");
			reqitems.setLocationState("�㶫");
			reqitems.setLocationCity("����");
			reqitems.setApproveStatus("onsale");
			reqitems.setCid(50012010L);
			ItemAddResponse rspitems = client.execute(reqitems , authcode);			
			System.out.println(rspitems.getBody());
			

		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	private static void skuAdd()
	{
		try
		{
			
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			ItemSkuAddRequest reqitems=new ItemSkuAddRequest();
			reqitems.setNumIid(164779L);
			reqitems.setProperties("1627207:28326;1630696:3266779");
			reqitems.setQuantity(10L);
			reqitems.setPrice("102.1");
			reqitems.setOuterId("UF52342AN");
			ItemSkuAddResponse rspitems = client.execute(reqitems , authcode);			
			System.out.println(rspitems.getBody());
			

		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	private static void getPromotion(String numiid)
	{
		try
		{
			
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			MarketingPromotionsGetRequest reqitems=new MarketingPromotionsGetRequest();
			reqitems.setFields("promotion_id,promotion_title,promotion_desc,decrease_num,num_iid,discount_value,discount_type,start_date,end_date,tag_id,status");
			reqitems.setNumIid(numiid);
			MarketingPromotionsGetResponse rspitems = client.execute(reqitems , authcode);			
			System.out.println(rspitems.getBody());
			

		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	private static void getAllItems() throws JException
	{
		long pageno=1L;
		try
		{
			
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			ItemsOnsaleGetRequest reqitems=new ItemsOnsaleGetRequest();
			reqitems.setFields("num_iid,outer_id,num,title");
			reqitems.setPageNo(pageno);
			reqitems.setPageSize(40L);
			ItemsOnsaleGetResponse rspitems = client.execute(reqitems , authcode);

			while(true)
			{
					
				for (Iterator it=rspitems.getItems().iterator();it.hasNext();)
				{
					
					Item item=(Item) it.next();
					
	
						System.out.println(item.getOuterId()+" "+item.getTitle());
				}
				
				if (pageno==(Double.valueOf(Math.ceil(rspitems.getTotalResults()/40.0))).intValue()) break;
				

				pageno=pageno+1;
				reqitems.setPageNo(pageno);			
				rspitems=client.execute(reqitems , authcode);	
			}
		
		
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	private static void getAllSku() throws Exception
	{
		int i=0;
		int j=0;
		long pageno=1L;
		
		Connection conn=getConnection();
		
		for (int k=0;k<10;)
		{
			try
			{
				TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
				ItemsOnsaleGetRequest reqitems=new ItemsOnsaleGetRequest();
				reqitems.setFields("num_iid,modified,outer_id,title,approve_status");	
				reqitems.setPageNo(pageno);
				reqitems.setPageSize(40L);
				ItemsOnsaleGetResponse rspitems = client.execute(reqitems , authcode);				
				
				Document doc = DOMHelper.newDocument(rspitems.getBody(), "GBK");
		           
				Element urlset = doc.getDocumentElement();
				
				while(true)
				{				
					
					
					if (!DOMHelper.ElementIsExists(urlset, "items") || (rspitems.getItems().size()<=0)|| rspitems.getItems()==null)
					{
						k=10;
						break;
					}
					for(Iterator ititems=rspitems.getItems().iterator();ititems.hasNext();)
					{
						i=i+1;
						Item item=(Item) ititems.next();
						long num_iid=item.getNumIid();
						
						Log.info("��ƷID:"+item.getNumIid()+" ����:"+item.getOuterId()+" ״̬:"+item.getApproveStatus());
						

						ItemGetRequest reqitem=new ItemGetRequest();
						reqitem.setFields("num_iid,outer_id,num,sku.num_iid,sku.sku_id,sku.quantity,sku.outer_id,sku.status");
						reqitem.setNumIid(num_iid);
						ItemGetResponse rspitem = client.execute(reqitem , authcode);
						
					
						
						Document itemdoc = DOMHelper.newDocument(rspitem.getBody(), "GBK");
				           
						Element itemele = (Element) itemdoc.getDocumentElement().getElementsByTagName("item").item(0);
						
						if (!DOMHelper.ElementIsExists(itemele, "skus")) 
						{
							String sql="insert into taobao_b_skus values('"+item.getOuterId()+"','')";
							SQLHelper.executeSQL(conn, sql);
						}
						else
						{
							for(Iterator it=rspitem.getItem().getSkus().iterator();it.hasNext();)
							{
								j=j+1;
								com.taobao.api.domain.Sku skuinfo=(com.taobao.api.domain.Sku) it.next();
											
								String sql="insert into taobao_b_skus values('"+item.getOuterId()+"','"+skuinfo.getOuterId()+"')";
								SQLHelper.executeSQL(conn, sql);
							
							}
						}
					}
					if (pageno==(Double.valueOf(Math.ceil(rspitems.getTotalResults()/40.0))).intValue()) break;
					
					Log.info("ҳ��:"+reqitems.getPageNo());
					pageno=pageno+1;
					reqitems.setPageNo(pageno);			
					rspitems=client.execute(reqitems , authcode);			
				}
				Log.info("�������Ʒ��:"+String.valueOf(i)+" ��SKU��:"+String.valueOf(j));
				break;
			
			} catch (Exception e) {
				if (++k >= 10)
					throw e;
				Log.warn("Զ������ʧ��[" + k + "], 10����Զ�����. "+ Log.getErrorMessage(e));
			
				Thread.sleep(10000L);
			}
		}
	}
	
	private static void getSkuByItemID(long numid) throws JException
	{
		try
		{			
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			ItemSkuGetRequest reqitems=new ItemSkuGetRequest();
			reqitems.setFields("num_iid,num,outer_id,title,upshelf_time,modified,created,approve_status,sku.sku_id,sku.outer_id,sku.quantity");	
			reqitems.setNumIid(numid);
			ItemSkuGetResponse rspitems = client.execute(reqitems , authcode);			
			Document doc = DOMHelper.newDocument(rspitems.getBody(), "GBK");
			Element urlset = doc.getDocumentElement();
			
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	private static void getItemDetail() throws JException
	{
		try
		{
			
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			ItemGetRequest reqitems=new ItemGetRequest();
			reqitems.setFields("num_iid,outer_id,num,sku.num_iid,sku.sku_id,sku.quantity,sku.outer_id,sku.status");
			reqitems.setNumIid(18756576690L);			
			ItemGetResponse rspitems = client.execute(reqitems , authcode);	
			System.out.println(rspitems.getBody());
			System.out.println(rspitems.getSubMsg());
			/*
			Document doc = DOMHelper.newDocument(rspitems.getBody(), "GBK");
			Element urlset = doc.getDocumentElement();
			
			Element itemelement=DOMHelper.getSubElementsByName(urlset,"item")[0];
			
			Element skuselement=DOMHelper.getSubElementsByName(itemelement,"skus")[0];
			
			Element[] skusnodes=DOMHelper.getSubElementsByName(skuselement,"sku");
			
			for (int i=0;i<skusnodes.length;i++)
			{
				if (!DOMHelper.ElementIsExists(skusnodes[i], "outer_id"))
				{
					System.out.println("���:"+DOMHelper.getSubElementVauleByName(itemelement, "outer_id")
							+"״̬:"+DOMHelper.getSubElementVauleByName(itemelement, "approve_status"));
					break;
				}
			}
			*/
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	private static void getTradeGet() throws JException
	{
		try
		{
			
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			TradeGetRequest reqitems=new TradeGetRequest();
			reqitems.setFields("seller_nick, buyer_nick, title, type, created, tid, seller_rate, buyer_rate, status, payment, discount_fee, adjust_fee, post_fee, total_fee, pay_time, end_time, modified, consign_time, buyer_obtain_point_fee, point_fee, real_point_fee, received_payment, commission_fee, buyer_memo, seller_memo, alipay_no, buyer_message, pic_path, num_iid, num, price, cod_fee, cod_status, shipping_type");
			reqitems.setTid(59749196840430L);
			TradeGetResponse rspitems = client.execute(reqitems , authcode);	
			System.out.println(rspitems.getBody());
		
		
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	private static void getItemByCustom(String customno) throws Exception
	{
		try
		{			
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			ItemsCustomGetRequest reqitems=new ItemsCustomGetRequest();
			reqitems.setFields("num_iid,num,outer_id,approve_status,sku");	
			reqitems.setOuterId(customno);
			ItemsCustomGetResponse rspitems = client.execute(reqitems , authcode);			
			
			System.out.println(rspitems.getBody());
			
			
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	/*
	private static void getItemByCustom(Connection conn,String customno) throws Exception
	{
		try
		{			
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			ItemsCustomGetRequest reqitems=new ItemsCustomGetRequest();
			reqitems.setFields("num_iid,num,outer_id,approve_status,sku");	
			reqitems.setOuterId(customno);
			ItemsCustomGetResponse rspitems = client.execute(reqitems , authcode);			
			for (int i=0;i<rspitems.getItems().size();i++)
			{
				Item item=rspitems.getItems().get(i);
				
				//if (item.getApproveStatus().equals("instock")) continue;
				
				for (int j=0;j<item.getSkus().size();j++)
				{
					Sku skuinfo=item.getSkus().get(j);
					
					String sku=skuinfo.getOuterId();
					
					String sql="select count(*) from barcode where custombc='"+sku+"'";
					if(SQLHelper.intSelect(conn, sql)==0)
					{
						throw new JException("SKU������,����:"+customno+" SKU:"+sku);
					}
					
					int qty=StockManager.getTradeContactUseableStock(conn, 1, sku);
					
					//sql="insert into inventorycomp values('"+sku+"',"+qty+","+skuinfo.getQuantity()+")";
					//SQLHelper.executeSQL(conn,sql);
					
					if (qty<5) qty=0;
					
					ItemQuantityUpdateRequest updatereq=new ItemQuantityUpdateRequest();
					updatereq.setNumIid(item.getNumIid());
					updatereq.setOuterId(sku);
					updatereq.setSkuId(skuinfo.getSkuId());
					updatereq.setQuantity(Long.valueOf(qty));
					updatereq.setType(1L);
					ItemQuantityUpdateResponse response = client.execute(updatereq,authcode);
					if (!response.isSuccess())
					{
						System.out.println("�����Ա����ʧ��,SKU��"+sku+"��,������Ϣ:"+response.getBody());
					}
					else
					{
						System.out.println("�����Ա����ɹ�,SKU��"+sku+"��,ԭ����:"+skuinfo.getQuantity()+" ��������"+qty);
					}
					
				}
			}
			
			
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}*/
	private static void addMemo()
	{
		try
		{			
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			TradeMemoUpdateRequest reqitems=new TradeMemoUpdateRequest();
			reqitems.setTid(216300635339786L);
			reqitems.setMemo("YTO cs31 2013-01-07 ");
			reqitems.setFlag(1L);
			TradeMemoUpdateResponse rspitems = client.execute(reqitems , authcode);			
			System.out.println(rspitems.getBody());
			
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}


	private static void getItemsOnSaleGet()
	{
		try
		{
			
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			ItemsOnsaleGetRequest reqitems=new ItemsOnsaleGetRequest();
			reqitems.setFields("num_iid,title,nick,pic_url,cid,price,type,delist_time,post_fee");		
			ItemsOnsaleGetResponse rspitems = client.execute(reqitems , authcode);			
			System.out.println(rspitems.getTotalResults());
			
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	private static void getItemsInventoryGet()
	{
		try
		{
			
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			ItemsInventoryGetRequest reqitems=new ItemsInventoryGetRequest();
			reqitems.setFields("num_iid,modified,outer_id,title");		
			reqitems.setBanner("sold_out");
			reqitems.setPageNo(5L);
			reqitems.setPageSize(40L);
			ItemsInventoryGetResponse rspitems = client.execute(reqitems , authcode);			
			System.out.println(rspitems.getBody());
			
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	private static void getProducts()
	{
		try
		{
			
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			ProductsGetRequest reqitems=new ProductsGetRequest();
			reqitems.setFields("product_id,tsc,cat_name,name");
			reqitems.setNick("��ʿ��ʱ�������");
			ProductsGetResponse rspitems = client.execute(reqitems , authcode);			
			System.out.println(rspitems.getBody());
			
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	private static void searchProducts()
	{
		try
		{
			
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			ProductsSearchRequest reqitems=new ProductsSearchRequest();
			reqitems.setFields("product_id,tsc,cid,props,name,price,pic_url,status");
			reqitems.setQ("��ʿ��Disney����Ƥ��Mickeyר����Ʒ��ƤŮ");
			ProductsSearchResponse rspitems = client.execute(reqitems , authcode);			
			System.out.println(rspitems.getBody());
			
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	private static void getSKUDetail()
	{
		try
		{			
			TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
			SkusCustomGetRequest getreq=new SkusCustomGetRequest();	
			getreq.setOuterId("039535BA2");
			getreq.setFields("sku_id,iid,properties,quantity,price,outer_id,created,modified,status,num_iid");
			SkusCustomGetResponse rsp = client.execute(getreq,authcode);	
			System.out.println(rsp.getBody());
			
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	

	private static void getWangwanglogin() throws Exception
	{

		TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret);
		WangwangEserviceAvgwaittimeGetRequest req=new WangwangEserviceAvgwaittimeGetRequest();
		req.setServiceStaffId("cntaobao��ʿ��ʱ���콢��:k2");
		Date starttime = Formatter.parseDate("2012-11-09 00:00:00",Formatter.DATE_TIME_FORMAT);
		req.setStartDate(starttime);
		Date endtime = Formatter.parseDate("2012-11-09 00:00:00",Formatter.DATE_TIME_FORMAT);
		req.setEndDate(endtime);
		WangwangEserviceAvgwaittimeGetResponse response = client.execute(req , authcode);
		
		///System.out.println(response.getWaitingTimeListOnDays().size());
		
		
	}
	
	private static void resend() throws Exception
	{

		TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret);
		LogisticsConsignResendRequest req=new LogisticsConsignResendRequest();	
		req.setOutSid("GA01416766344");		
		req.setTid(269046522256159L);
		req.setCompanyCode("POSTB");
		
		LogisticsConsignResendResponse rsp = client.execute(req, authcode);
		
		System.out.println(rsp.getBody());
		
		
	}
	
	private static void getSellerTrade() throws Exception
	{

		Connection conn=getConnection();
		TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
		TradesSoldGetRequest req=new TradesSoldGetRequest();
		req.setFields("tid,type,status,buyer_nick,receiver_address,modified,orders.title,orders.oid,orders.outer_sku_id");
		//Date starttime = Formatter.parseDate("2012-11-11 00:00:00",Formatter.DATE_TIME_FORMAT);
		//req.setStartCreated(starttime);
		//Date endtime = Formatter.parseDate("2012-11-11 04:00:00",Formatter.DATE_TIME_FORMAT);
		//req.setEndCreated(endtime);
		//req.setType("step");
		req.setStatus("WAIT_SELLER_SEND_GOODS");	
	
		req.setPageNo(1L);
		req.setPageSize(40L);
		req.setUseHasNext(true);
		TradesSoldGetResponse response = client.execute(req , authcode);
		
		//System.out.println(response.getBody());
		
		while(true)
		{
	
			if (response.getTrades()==null || response.getTrades().size()<=0)
			{
				break;
			}

			for(Iterator it=response.getTrades().iterator();it.hasNext();)
			{
				Trade td=(Trade) it.next();
				
				Log.info(td.getTid()+" "+td.getBuyerNick()+" "+td.getReceiverAddress()+" "+Formatter.format(td.getModified(),Formatter.DATE_TIME_FORMAT));
				
				//System.out.println(td.getTid());
				
				String sql="select count(*) from ns_delivery where tid='"+td.getTid()+"' and sheettype=3";
				
				if (SQLHelper.intSelect(conn, sql)>0)
				{
					sql="update it_upnotebak set flag=0 where sheetid in(select sheetid from ns_delivery where tid='"+td.getTid()+"' and sheettype=3)";
					
					SQLHelper.executeSQL(conn, sql);
					
					sql="insert into it_upnote select * from it_upnotebak where sheetid in(select sheetid from ns_delivery where tid='"+td.getTid()+"' and sheettype=3)";
										
					SQLHelper.executeSQL(conn, sql);
					
					sql="delete it_upnotebak where sheetid in(select sheetid from ns_delivery where tid='"+td.getTid()+"' and sheettype=3)";
					
					SQLHelper.executeSQL(conn, sql);
					
					Log.info("�ָ�����:"+td.getTid());
				
				}
				
			}
			
			req.setPageNo(req.getPageNo()+1L);
			response=client.execute(req , authcode);
		}
	}
	private static void getTradeList() throws Exception
	{
		
		
		Connection conn;
		long pageno=1L;
		for(int i=0;i<100;i++)
		{
			try
			{
				conn=getConnection();
				TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret);
				TradesSoldGetRequest req=new TradesSoldGetRequest();
				req.setFields("tid,type,status,buyer_nick,receiver_address,created,modified,orders.title,orders.oid,"
						+"orders.outer_sku_id,orders.refund_status,orders.outer_iid,orders.sku_properties_name,"
						+"orders.num,orders.total_fee,orders.payment,orders.discount_fee,orders.adjust_fee");
				Date starttime = Formatter.parseDate("2013-07-01 00:00:00",Formatter.DATE_TIME_FORMAT);
				req.setStartCreated(starttime);
				Date endtime = Formatter.parseDate("2013-07-31 24:00:00",Formatter.DATE_TIME_FORMAT);
				req.setEndCreated(endtime);
				//req.setType("step");
				//req.setStatus("TRADE_FINISHED");				
				req.setPageNo(pageno);
				req.setPageSize(40L);
				//req.setUseHasNext(true);
				TradesSoldGetResponse response = client.execute(req , authcode);
				//System.out.println(response.getBody());
				while(true)
				{
						
					
					if (response.getTrades()==null || response.getTrades().size()<=0)
					{
						break;
					}
					
					
					for(Iterator it=response.getTrades().iterator();it.hasNext();)
					{
						Trade td=(Trade) it.next();
					
						
						for (Iterator ititem=td.getOrders().iterator();ititem.hasNext();)
						{
							Order o=(Order) ititem.next();
							
							//String sql="select count(*) from mctradedata where tid='"+td.getTid()+"'";
							//if (SQLHelper.intSelect(conn, sql)==0)
							//{
								String sql="insert into mctradedata values('"+td.getTid()+"','"+Formatter.format(td.getCreated(),Formatter.DATE_TIME_FORMAT)+"','"+td.getStatus()+"','"
									+o.getRefundStatus()+"','"+o.getOuterIid()+"','"+o.getOuterSkuId()+"','"
									+o.getSkuPropertiesName()+"','"+o.getNum()+"','"+o.getPayment()+"','"
									+o.getTotalFee()+"','"+o.getDiscountFee()+"','"+o.getAdjustFee()+"')";
								SQLHelper.executeSQL(conn, sql);
								System.out.println(td.getTid()+" "+td.getCreated()+" "+o.getOuterIid()+" "+o.getOuterSkuId()+" "+o.getSkuPropertiesName()+" "+o.getNum()+" "+o.getTotalFee()+" "+o.getAdjustFee()+" "+o.getDiscountFee());
							//}
						}
						
					}
					pageno++;
					req.setPageNo(pageno);
					response=client.execute(req , authcode);
				}
			
			} catch (Exception e) {
				if (++i >= 100)
					System.out.println("ȡ����ʧ��!");
				System.out.println("Զ������ʧ��[" + i + "], 10����Զ�����. "+ Log.getErrorMessage(e));
				Thread.sleep(10000L);
			}
		}
		
		
	}
	private static void getTradeFullInfo()
	{
		try
		{
		
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			TradeFullinfoGetRequest req=new TradeFullinfoGetRequest();
			req.setTid(104796522848562L);		
			req.setFields("seller_nick,buyer_nick,title,type,refund_status,created,iid,price,pic_path,num,tid,buyer_message,sid,shipping_type,alipay_no,payment,discount_fee,adjust_fee,snapshot,num_iid,snapshot_url,status,seller_rate,buyer_rate,trade_memo,buyer_memo,seller_memo,pay_time,end_time,modified,buyer_obtain_point_fee,point_fee,real_point_fee,total_fee,post_fee,has_post_fee,cod_status,buyer_flag,seller_flag,buyer_alipay_no,receiver_name,receiver_state,receiver_city,receiver_district,receiver_address,receiver_zip,receiver_mobile,receiver_phone,consign_time,buyer_email,commission_fee,seller_alipay_no,seller_mobile,seller_phone,seller_name,seller_email,available_confirm_fee,has_postFee,received_payment,cod_fee,timeout_action_time,orders,sku_id,sku_properties_name,item_meal_name,outer_iid,outer_sku_id,promotion,promotion_details,trade_from,alipay_url");
            TradeFullinfoGetResponse rsp = client.execute(req, authcode);
            System.out.println(rsp.getBody());
            
            Trade t = rsp.getTrade();     
           
            System.out.println(t.getOrders().size());
            
            Document doc = DOMHelper.newDocument(rsp.getBody(), "GBK");
           
			Element urlset = doc.getDocumentElement();
			NodeList tradenodes = urlset.getElementsByTagName("trade");
			Element trade=(Element) tradenodes.item(0);
			String phone=DOMHelper.getSubElementVauleByName(trade,"receiver_phone");
			String mobile=DOMHelper.getSubElementVauleByName(trade,"receiver_mobile");
			String sellermemo=DOMHelper.getSubElementVauleByName(trade,"seller_memo");
			String buyermessage=DOMHelper.getSubElementVauleByName(trade,"buyer_message");
			String buyermemo=DOMHelper.getSubElementVauleByName(trade,"buyer_memo");
			String receiverdistrict=DOMHelper.getSubElementVauleByName(trade,"receiver_district");
			String promotion=DOMHelper.getSubElementVauleByName(trade,"promotion");
			String alipayurl=DOMHelper.getSubElementVauleByName(trade,"alipay_url");
			String timeoutactiontime=DOMHelper.getSubElementVauleByName(trade,"timeout_action_time");
			//String commissionfee=DOMHelper.getSubElementVauleByName(trade,"commissionfee");
			String buyerflag=DOMHelper.getSubElementVauleByName(trade,"buyer_flag");
			String snapshot=DOMHelper.getSubElementVauleByName(trade,"snapshot");
			String tradememo=DOMHelper.getSubElementVauleByName(trade,"trade_memo");
			String consigntime=DOMHelper.getSubElementVauleByName(trade,"consign_time");
			String endtime=DOMHelper.getSubElementVauleByName(trade,"end_time");
			
		
			if (!DOMHelper.ElementIsExists(trade, "promotion_details"))
			{
				ArrayList<PromotionDetail> pdlist=new ArrayList<PromotionDetail> ();
				PromotionDetail pd=new PromotionDetail();
				pd.setPromotionName("");
				pd.setDiscountFee("");
				pd.setGiftItemName("");
				pdlist.add(pd);
				t.setPromotionDetails(pdlist);
			}
			else
			{
				Element promotiondetails = (Element) trade.getElementsByTagName("promotion_details").item(0);
				NodeList pdnodes=promotiondetails.getElementsByTagName("promotion_detail");
				for (int i=0;i<pdnodes.getLength();i++)
				{
					Element promotiondetail=(Element) pdnodes.item(i);
					String giftitemname=DOMHelper.getSubElementVauleByName(promotiondetail,"gift_item_name");
					String id=DOMHelper.getSubElementVauleByName(promotiondetail,"id");
					for(int j=0;j<t.getPromotionDetails().size();j++)
					{
						if (t.getPromotionDetails().get(j).getId()==Long.valueOf(id))
							t.getPromotionDetails().get(j).setGiftItemName(giftitemname);
					}
				}
			}
			
			Element orders = (Element) trade.getElementsByTagName("orders").item(0);
			NodeList ordernodes=orders.getElementsByTagName("order");
			for (int n=0;n<ordernodes.getLength();n++)
			{
				Element order=(Element) ordernodes.item(n);
				String outerskuid=DOMHelper.getSubElementVauleByName(order,"outer_sku_id");
				String outeriid=DOMHelper.getSubElementVauleByName(order,"outer_iid");
				String oid=DOMHelper.getSubElementVauleByName(order,"oid");
				String skuid=DOMHelper.getSubElementVauleByName(order,"sku_id");
				String itemmealname=DOMHelper.getSubElementVauleByName(order,"item_meal_name");
				String sellernick=DOMHelper.getSubElementVauleByName(order,"seller_nick");
				String buyernick=DOMHelper.getSubElementVauleByName(order,"buyer_nick");
				String sellertype=DOMHelper.getSubElementVauleByName(order,"seller_type");
				String otimeoutactiontime=DOMHelper.getSubElementVauleByName(order,"timeout_action_time");
				String skupropertiesname=DOMHelper.getSubElementVauleByName(order,"sku_properties_name");
				String refundid=DOMHelper.getSubElementVauleByName(order,"refund_id");
				if (refundid.equals(""))
					refundid="0";
				
	
				System.out.println(refundid);
				
				for(int m=0;m<t.getOrders().size();m++)
				{
				
					if (t.getOrders().get(m).getOid().compareTo(Long.valueOf(oid))==0)
					{
											
						if (outerskuid.equals(""))
							t.getOrders().get(m).setOuterSkuId(outeriid);
						t.getOrders().get(m).setSkuId(skuid);
						t.getOrders().get(m).setItemMealName(itemmealname);
						t.getOrders().get(m).setSellerNick(sellernick);
						t.getOrders().get(m).setBuyerNick(buyernick);
						t.getOrders().get(m).setSellerType(sellertype);
						t.getOrders().get(m).setRefundId(Long.valueOf(refundid));
						if (!otimeoutactiontime.equals(""))
							t.getOrders().get(m).setTimeoutActionTime(Formatter.parseDate(otimeoutactiontime,Formatter.DATE_TIME_FORMAT));
						else
							t.setTimeoutActionTime(Formatter.parseDate("1900-01-01 00:00:00",Formatter.DATE_TIME_FORMAT));
						t.getOrders().get(m).setSkuPropertiesName(skupropertiesname);	
						break;
					}
				}
				
			}
					
		
			t.setReceiverPhone(phone);
			t.setReceiverMobile(mobile);
			t.setSellerMemo(sellermemo);
			t.setBuyerMessage(buyermessage);
			t.setBuyerMemo(buyermemo);
			t.setReceiverDistrict(receiverdistrict);
			t.setPromotion(promotion);
			t.setAlipayUrl(alipayurl);
			if (!timeoutactiontime.equals(""))
				t.setTimeoutActionTime(Formatter.parseDate(timeoutactiontime,Formatter.DATE_TIME_FORMAT));
			else
				t.setTimeoutActionTime(Formatter.parseDate("1900-01-01 00:00:00",Formatter.DATE_TIME_FORMAT));
	
			//t.setCommissionFee(commissionfee);
			if (buyerflag.equals("")) buyerflag="0";
			t.setBuyerFlag(Long.valueOf(buyerflag));
			t.setSnapshot(snapshot);
			t.setTradeMemo(tradememo);
			if (!consigntime.equals(""))
				t.setConsignTime(Formatter.parseDate(consigntime,Formatter.DATE_TIME_FORMAT));
			else
				t.setConsignTime(Formatter.parseDate("1900-01-01 00:00:00",Formatter.DATE_TIME_FORMAT));
	
			if (!endtime.equals(""))
				t.setEndTime(Formatter.parseDate(endtime,Formatter.DATE_TIME_FORMAT));
			else
				t.setEndTime(Formatter.parseDate("1900-01-01 00:00:00",Formatter.DATE_TIME_FORMAT));
			
			for (int k=0;k<t.getOrders().size();k++)
			{
				System.out.println(t.getOrders().get(k).getRefundId());
			}
			
            
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	private static void getCustomInfo()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			SkusCustomGetRequest req=new SkusCustomGetRequest();
			req.setOuterId("DF215101AC");
			req.setFields("sku_id,iid,properties,quantity,price,outer_id,created,modified,status,num_iid");
			SkusCustomGetResponse rsp = client.execute(req, authcode);       
            System.out.println(rsp.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	private static void getChatpeers()
	{
		//System.out.println(System.getProperties().getProperty("file.encoding"));
		//System.getProperties().setProperty("file.encoding", "UTF-8");
		//System.out.println(System.getProperties().getProperty("file.encoding"));
		try {
			TaobaoClient client = new DefaultTaobaoClient(url,appkey, appsecret,"xml");
			WangwangEserviceChatpeersGetRequest req=new WangwangEserviceChatpeersGetRequest();
			req.setChatId("cntaobaorxl71");
			req.setStartDate("2013-03-28");
			req.setEndDate("2013-03-29");
			//req.setCharset("gb2312");			
			System.out.println(System.getProperties().getProperty("file.encoding"));
			WangwangEserviceChatpeersGetResponse response = client.execute(req,authcode);	
			System.out.println(response.getBody());
			//Document doc=DOMHelper.newDocument(response.getBody(),"GBK");			
			//System.out.println(DOMHelper.toString(doc.getElementsByTagName("chatpeers_get_response").item(0)));
			//System.out.println(response.getBody());
			/*
			for(Iterator it=response.getChatpeers().iterator();it.hasNext();)
			{
				Chatpeer cp=(Chatpeer) it.next();
				System.out.println(cp.getUid());
			}*/
			//System.out.println(response.toString());
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	


	private static void getAvgWaitTime()
	{
		try {
			TaobaoClient client = new DefaultTaobaoClient(url,appkey, appsecret,"xml");
			WangwangEserviceAvgwaittimeGetRequest  req = new WangwangEserviceAvgwaittimeGetRequest();
			req.setServiceStaffId("cntaobao�����������ֱ��:cs101");
			req.setStartDate(Formatter.parseDate("2012-11-13 00:00:00",Formatter.DATE_TIME_FORMAT));
			req.setEndDate(Formatter.parseDate("2012-11-13 00:00:00",Formatter.DATE_TIME_FORMAT));			
			WangwangEserviceAvgwaittimeGetResponse response = client.execute(req,authcode);
			System.out.println(response.getBody());
			
			//System.out.println(response.toString());
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	private static void getevaluation()
	{
		try {
			TaobaoClient client = new DefaultTaobaoClient(url,appkey, appsecret,"xml");
			WangwangEserviceEvaluationGetRequest req = new WangwangEserviceEvaluationGetRequest();
			req.setServiceStaffId("cntaobao��ʿ��ʱ���콢��:cs23");
			req.setStartDate(Formatter.parseDate("2011-09-01 00:00:00",Formatter.DATE_TIME_FORMAT));
			req.setEndDate(Formatter.parseDate("2011-09-07 00:00:00",Formatter.DATE_TIME_FORMAT));			
			WangwangEserviceEvaluationGetResponse response = client.execute(req,authcode);
			System.out.println(response.getBody());
			
			//System.out.println(response.toString());
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	private static void getSubUsers()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			SellercenterSubusersGetRequest req=new SellercenterSubusersGetRequest();
			req.setNick("��ʿ��ʱ���콢��");
			SellercenterSubusersGetResponse response = client.execute(req , authcode);
			System.out.println(response.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	private static void updateStock(Connection conn,String sku,int qty) throws Exception
	{
		try {			
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			SkusCustomGetRequest getreq=new SkusCustomGetRequest();	
			getreq.setOuterId(sku);
			getreq.setFields("sku_id,iid,properties,quantity,price,outer_id,created,modified,status,num_iid");
			SkusCustomGetResponse rsp = client.execute(getreq,authcode);
			System.out.println(sku);
			System.out.println(rsp.getBody());
			if (!rsp.isSuccess())
			{
				System.out.println("ȡ�Ա���Ʒ��Ϣ����,SKU��"+sku+"��,������Ϣ:"+rsp.getMsg());
				//return;
			}
			if (rsp.getSkus().size()<=0)
			{
				System.out.println("�Ҳ����Ա�����,SKU��"+sku+"��");
				//return;
			}
			
			for(Iterator it=rsp.getSkus().iterator();it.hasNext();)
			{
				com.taobao.api.domain.Sku skuinfo=(com.taobao.api.domain.Sku) it.next();
				if (skuinfo.getOuterId().equalsIgnoreCase(sku))
				{
					String sql="insert into inventorycomp values('"+sku+"',"+qty+","+skuinfo.getQuantity()+")";
					SQLHelper.executeSQL(conn,sql);
				}
				/*
				if (skuinfo.getOuterId().equalsIgnoreCase(sku))
				{
					ItemQuantityUpdateRequest updatereq=new ItemQuantityUpdateRequest();
					updatereq.setNumIid(skuinfo.getNumIid());
					updatereq.setOuterId(skuinfo.getOuterId());
					updatereq.setSkuId(skuinfo.getSkuId());
					updatereq.setQuantity(Long.valueOf(qty));
					updatereq.setType(1L);
					ItemQuantityUpdateResponse response = client.execute(updatereq,authcode);
					if (!response.isSuccess())
					{
						System.out.println("�����Ա����ʧ��,SKU��"+sku+"��,������Ϣ:"+response.getSubMsg());
					}
					else
					{
						System.out.println("�����Ա����ɹ�,SKU��"+sku+"��");
					}
				}
				*/
			}
		} catch (ApiException e) {
			System.out.println("ȡ�Ա����ʧ��,SKU��"+sku+"��,������Ϣ:" + e.getMessage());
		}
	}

	private static void WlbItemAdd()
	{			
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbItemAddRequest req=new WlbItemAddRequest();
			req.setName("����4");
			req.setTitle("��ʿ��Disney�������ר����ƷPU�����ᵥ���ִ�Ů��UF2115");			
			req.setItemCode("UF52652AN");
			req.setIsDangerous(false);
			req.setIsFriable(false);
			req.setIsSku("false");			
			WlbItemAddResponse response = client.execute(req , authcode);
			System.out.println(response.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	private static void WlbItemQuery()
	{			
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbItemQueryRequest req=new WlbItemQueryRequest();
			//req.setStatus("ITEM_STATUS_VALID");
			//req.setTitle("��Ʒ����������ʿ��Disney�����ֱ�Mickeyר��Ů��.TV2007-01");
			req.setItemCode("6902480081910");
			req.setIsSku("true");
			WlbItemQueryResponse response = client.execute(req , authcode);
			System.out.println(response.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	private static void WlbItemGet()
	{			
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbItemGetRequest req=new WlbItemGetRequest();
			req.setItemId(10623198034L);
			WlbItemGetResponse response = client.execute(req , authcode);
			System.out.println(response.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	//���ݿ�����͡��ֿ��ѯ��Ʒ���
	private static void WlbGetItemDetail()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbInventoryDetailGetRequest  reqitem=new WlbInventoryDetailGetRequest();
			reqitem.setItemId(100066938L);
			WlbInventoryDetailGetResponse rspitem = client.execute(reqitem , authcode);
			System.out.println(rspitem.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	//�����������ѷ����ӿ�
	private static void WlbOrderConsign()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbOrderConsignRequest  reqitem=new WlbOrderConsignRequest();
			reqitem.setWlbOrderCode("LBX0018391168033");
			WlbOrderConsignResponse rspitem = client.execute(reqitem , authcode);
			System.out.println(rspitem.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	//����ʱ������κ�����ѯ��Ʒ���
	private static void WlbGetHistoryInventory()
	{
		try
		{				
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbInventorylogQueryRequest  reqitem=new WlbInventorylogQueryRequest();
			reqitem.setItemId(100066891L);
			/*
			Calendar cd = Calendar.getInstance();
			cd.setTime(new Date());
			cd.add(Calendar.DATE, -2);
			reqitem.setGmtStart(cd.getTime());
			reqitem.setGmtEnd(new Date());
			*/
			//reqitem.setOrderCode("LP5439859435");
			reqitem.setPageSize(100L);
			WlbInventorylogQueryResponse rspitem = client.execute(reqitem , authcode);
			System.out.println(rspitem.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	/*
	private static void WlbSynStock()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbOutInventoryChangeNotifyRequest updatereq=new WlbOutInventoryChangeNotifyRequest();
			updatereq.setChangeCount(10L);
			updatereq.setItemId(124000000043852L);
			updatereq.setOpType("IN");
			updatereq.setOutBizCode("10000112");
			updatereq.setResultCount(10L);
			updatereq.setSource("PURCHASE");
			updatereq.setType("WLB_ITEM");
			
			WlbOutInventoryChangeNotifyResponse response = client.execute(updatereq,authcode);
			
			System.out.println(response.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}*/
	//ͬ�����
	private static void WlbSynInventory()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbInventorySyncRequest updatereq=new WlbInventorySyncRequest();
			updatereq.setItemType("WLB_ITEM");
			updatereq.setQuantity(14L);
			updatereq.setItemId(124000000015453L);
			
			WlbInventorySyncResponse response = client.execute(updatereq,authcode);
			
			System.out.println(response.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	//ɾ����Ʒ
	private static void WlbItemDelete()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbItemDeleteRequest updatereq=new WlbItemDeleteRequest();
			updatereq.setItemId(124000000043851L);
			updatereq.setUserNick("dishi001_09270337");
			WlbItemDeleteResponse response = client.execute(updatereq,authcode);
			
			System.out.println(response.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	//����ӳ���ϵ
	private static void WlbItemSynchronize()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbItemSynchronizeRequest updatereq=new WlbItemSynchronizeRequest();
			updatereq.setItemId(124000000015453L);
			updatereq.setUserNick("dishi001_09270337");
			updatereq.setExtEntityType("IC_ITEM");
			updatereq.setExtEntityId(164779L);
			WlbItemSynchronizeResponse response = client.execute(updatereq,authcode);
			
			System.out.println(response.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	//�����ⲿʵ��ID��ѯ��������ƷID
	private static void WlbItemGetByExtEntity()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbItemMapGetByExtentityRequest updatereq=new WlbItemMapGetByExtentityRequest();
			updatereq.setExtEntityType("IC_ITEM");
			updatereq.setExtEntityId(115788L);
			WlbItemMapGetByExtentityResponse response = client.execute(updatereq,authcode);
			
			System.out.println(response.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	//ȡ��ӳ���ϵ
	private static void WlbItemMapGet()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbItemMapGetRequest updatereq=new WlbItemMapGetRequest();
			updatereq.setItemId(100015112L);			
			WlbItemMapGetResponse response = client.execute(updatereq,authcode);		
			System.out.println(response.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	//ɾ��ӳ���ϵ
	private static void WlbItemSynchronizeDelete()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbItemSynchronizeDeleteRequest updatereq=new WlbItemSynchronizeDeleteRequest();
			updatereq.setItemId(124000000015453L);		
			updatereq.setExtEntityType("IC_ITEM");
			updatereq.setExtEntityId(115788L);
			WlbItemSynchronizeDeleteResponse response = client.execute(updatereq,authcode);
			
			System.out.println(response.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	//	�����˻���ⵥ
	private static void WlbCreateReturnOrder()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbOrderCreateRequest req=new WlbOrderCreateRequest();
			
			req.setOutBizCode("020V0A11093009");
			req.setPrevOrderCode("1005132408");
			req.setStoreCode("FBI-0001");
			req.setOrderType("RETURN_IN");
			req.setOrderSubType("OTHER");
			req.setOrderFlag("VISIT");
			//req.setOrderFlag("VISIT^CONSIGN^SELLER_AFFORD");
			//req.setOrderFlag("EXCHANGE^CONSIGN^SELLER_AFFORD");
			//req.setPrevOrderCode("LBX0018391168033");
			req.setIsFinished(true);
			
			String address="�㶫ʡ".concat("^^^").concat("������").concat("^^^").concat("�����").concat("^^^").concat("��ݸׯһ��·116�Ź㶫����������10¥");
			String sendinfo="510610".concat("^^^").concat(address).concat("^^^").concat("����ΰ").concat("^^^").concat("13922373425").concat("^^^").concat("020-38458026");
			
			//sendinfo="31000^^^�㽭ʡ^^^������^^^������^^^��ҵ����6¥^^^����^^^NA^^^057188155188";
			
			req.setSenderInfo(sendinfo);
			
			String tmsinfo="YTO".concat("^^^").concat("NA").concat("^^^").concat("8564324523").concat("^^^").concat("NA").concat("^^^").concat("NA");
			
			req.setTmsInfo(tmsinfo);
			
			String receiveinfo="312000^^^����ʡ^^^������^^^������^^^����������������·���·142�ų����п���ҽԺ������^^^�ﾲ^^^15869362102^^^NA";
			
			req.setReceiverInfo(receiveinfo);
			req.setRemark("�����˻���� ����ȡ��");
		
			//124000000013447
			StringBuffer strbuf=new StringBuffer();
			strbuf.append("{\"order_item_list\":[");
			String itemid="124000000015453";
			String sku="UF52653AN";
			String qty="1";
			String price="112";
			strbuf.append("{");				
			strbuf.append("\"item_id\":\""+itemid+"\",");
			strbuf.append("\"inventory_type\":\"1\",");
			//strbuf.append("\"trade_code\":\"113152288230\",");
			//strbuf.append("\"sub_trade_code\":\"113152288230\",");
			strbuf.append("\"owner_user_nick\":\"dishi001_09270337\",");
			strbuf.append("\"flag\":\"0\",");
			strbuf.append("\"item_code\":\""+sku+"\",");
			strbuf.append("\"item_quantity\":\""+qty+"\",");
			strbuf.append("\"item_price\":\""+price+"\"");
			
			strbuf.append("},");				
			
			strbuf.deleteCharAt(strbuf.length()-1);
			strbuf.append("]}");	

			req.setOrderItemList(strbuf.toString());
			
			WlbOrderCreateResponse response = client.execute(req , authcode);
			
			System.out.println(response.getBody());
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	//	����������
	private static void WlbCreateAllcoateOrder()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbOrderCreateRequest req=new WlbOrderCreateRequest();
			
			req.setOutBizCode("020V0A11094510");
			req.setPrevOrderCode("1005132340");
			req.setStoreCode("FBI-0001");
			req.setOrderType("NORMAL_OUT");
			req.setOrderSubType("ALLCOATE");
			req.setPackageCount(Long.valueOf(2));
			req.setIsFinished(true);
			
			String address="�㶫ʡ".concat("^^^").concat("������").concat("^^^").concat("�����").concat("^^^").concat("��ݸׯһ��·116�Ź㶫����������10¥");
			String sendinfo="510610".concat("^^^").concat(address).concat("^^^").concat("����ΰ").concat("^^^").concat("13922373425").concat("^^^").concat("020-38458026");
			
			//sendinfo="31000^^^�㽭ʡ^^^������^^^������^^^��ҵ����6¥^^^����^^^NA^^^057188155188";
			
			req.setSenderInfo(sendinfo);
			
			String tmsinfo="YTO".concat("^^^").concat("NA").concat("^^^").concat("8564324523").concat("^^^").concat("NA").concat("^^^").concat("NA");
			
			req.setTmsInfo(tmsinfo);
			
			String receiveinfo="312000^^^����ʡ^^^������^^^������^^^����������������·���·142�ų����п���ҽԺ������^^^�ﾲ^^^15869362102^^^NA";
			
			req.setReceiverInfo(receiveinfo);
			
			Calendar cd = Calendar.getInstance();
			cd.setTime(new Date());
			cd.add(Calendar.DATE, 3);
								
			req.setExpectStartTime(Formatter.parseDate(Formatter.format(cd.getTime(),Formatter.DATE_TIME_FORMAT),Formatter.DATE_TIME_FORMAT));
			
			cd.add(Calendar.DATE, 2);
			
			//�ջ����������
			req.setExpectEndTime(Formatter.parseDate(Formatter.format(cd.getTime(),Formatter.DATE_TIME_FORMAT),Formatter.DATE_TIME_FORMAT));
			
			//124000000013447
			StringBuffer strbuf=new StringBuffer();
			strbuf.append("{\"order_item_list\":[");
			String itemid="124000000015453";
			String sku="UF52653AN";
			String qty="50";
			String price="11.2";
			strbuf.append("{");				
			strbuf.append("\"item_id\":\""+itemid+"\",");
			strbuf.append("\"trade_code\":\"\",");
			strbuf.append("\"inventory_type\":\"1\",");
			strbuf.append("\"owner_user_nick\":\"dishi001_09270337\",");
			strbuf.append("\"flag\":\"0\",");
			strbuf.append("\"item_code\":\""+sku+"\",");
			strbuf.append("\"item_quantity\":\""+qty+"\",");
			strbuf.append("\"item_price\":\""+price+"\"");
			
			strbuf.append("},");				
			
			strbuf.deleteCharAt(strbuf.length()-1);
			strbuf.append("]}");	

			req.setOrderItemList(strbuf.toString());
			
			WlbOrderCreateResponse response = client.execute(req , authcode);
			
			System.out.println(response.getBody());
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	//�����ɹ�����
	private static void WlbCreatePurchaseOrder()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbOrderCreateRequest req=new WlbOrderCreateRequest();
			
			req.setOutBizCode("020V0A11092510");
			req.setPrevOrderCode("1005132331");
			req.setStoreCode("FBI-0001");
			req.setOrderType("NORMAL_IN");
			req.setOrderSubType("PURCHASE");
			req.setPackageCount(Long.valueOf(2));
			req.setIsFinished(true);
			
			String address="�㶫ʡ".concat("^^^").concat("������").concat("^^^").concat("�����").concat("^^^").concat("��ݸׯһ��·116�Ź㶫����������10¥");
			String sendinfo="510610".concat("^^^").concat(address).concat("^^^").concat("����ΰ").concat("^^^").concat("13922373425").concat("^^^").concat("020-38458026");
			
			//sendinfo="31000^^^�㽭ʡ^^^������^^^������^^^��ҵ����6¥^^^����^^^NA^^^057188155188";
			
			req.setSenderInfo(sendinfo);
			
			String tmsinfo="YTO".concat("^^^").concat("NA").concat("^^^").concat("8564324523").concat("^^^").concat("NA").concat("^^^").concat("NA");
			
			req.setTmsInfo(tmsinfo);
			
			String receiveinfo="312000^^^����ʡ^^^������^^^������^^^����������������·���·142�ų����п���ҽԺ������^^^�ﾲ^^^15869362102^^^NA";
			
			req.setReceiverInfo(receiveinfo);
			
			Calendar cd = Calendar.getInstance();
			cd.setTime(new Date());
			cd.add(Calendar.DATE, 3);
								
			req.setExpectStartTime(Formatter.parseDate(Formatter.format(cd.getTime(),Formatter.DATE_TIME_FORMAT),Formatter.DATE_TIME_FORMAT));
			
			cd.add(Calendar.DATE, 2);
			
			//�ջ����������
			req.setExpectEndTime(Formatter.parseDate(Formatter.format(cd.getTime(),Formatter.DATE_TIME_FORMAT),Formatter.DATE_TIME_FORMAT));
			
			//124000000013447
			StringBuffer strbuf=new StringBuffer();
			strbuf.append("{\"order_item_list\":[");
			String itemid="124000000013447";
			String sku="UF52342AN";
			String qty="5000";
			String price="112";
			strbuf.append("{");				
			strbuf.append("\"item_id\":\""+itemid+"\",");
			strbuf.append("\"trade_code\":\"\",");
			strbuf.append("\"inventory_type\":\"1\",");
			strbuf.append("\"owner_user_nick\":\"dishi001_09270337\",");
			strbuf.append("\"flag\":\"0\",");
			strbuf.append("\"item_code\":\""+sku+"\",");
			strbuf.append("\"item_quantity\":\""+qty+"\",");
			strbuf.append("\"item_price\":\""+price+"\"");
			
			strbuf.append("},");				
			
			strbuf.deleteCharAt(strbuf.length()-1);
			strbuf.append("]}");	

			req.setOrderItemList(strbuf.toString());
			
			WlbOrderCreateResponse response = client.execute(req , authcode);
			
			System.out.println(response.getBody());
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	//	�����̵㵥
	private static void WlbCreateCheckOrder()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbOrderCreateRequest req=new WlbOrderCreateRequest();
			
			req.setOutBizCode("020V0A11092001");
			req.setPrevOrderCode("1005134569");
			req.setStoreCode("FBI-0001");
			req.setOrderType("NORMAL_IN");
			req.setOrderSubType("OTHER");
			req.setRemark("�����̵���ⵥ");
			req.setIsFinished(true);
			
			String address="�㶫ʡ".concat("^^^").concat("������").concat("^^^").concat("�����").concat("^^^").concat("��ݸׯһ��·116�Ź㶫����������10¥");
			String sendinfo="510610".concat("^^^").concat(address).concat("^^^").concat("����ΰ").concat("^^^").concat("13922373425").concat("^^^").concat("020-38458026");
			
			//sendinfo="31000^^^�㽭ʡ^^^������^^^������^^^��ҵ����6¥^^^����^^^NA^^^057188155188";
			
			req.setSenderInfo(sendinfo);
			
			String tmsinfo="YTO".concat("^^^").concat("NA").concat("^^^").concat("8564324523").concat("^^^").concat("NA").concat("^^^").concat("NA");
			
			//req.setTmsInfo(tmsinfo);
			
			String receiveinfo="312000^^^����ʡ^^^������^^^������^^^����������������·���·142�ų����п���ҽԺ������^^^�ﾲ^^^15869362102^^^NA";
			
			req.setReceiverInfo(receiveinfo);
			
			Calendar cd = Calendar.getInstance();
			cd.setTime(new Date());
			cd.add(Calendar.DATE, 3);
								
			//req.setExpectStartTime(Formatter.parseDate(Formatter.format(cd.getTime(),Formatter.DATE_TIME_FORMAT),Formatter.DATE_TIME_FORMAT));
			
			cd.add(Calendar.DATE, 2);
			
			//�ջ����������
			//req.setExpectEndTime(Formatter.parseDate(Formatter.format(cd.getTime(),Formatter.DATE_TIME_FORMAT),Formatter.DATE_TIME_FORMAT));
			
			//124000000013447
			StringBuffer strbuf=new StringBuffer();
			strbuf.append("{\"order_item_list\":[");
			String itemid="124000000013447";
			String sku="UF52342AN";
			String qty="20";
			String price="112";
			strbuf.append("{");				
			strbuf.append("\"item_id\":\""+itemid+"\",");
			strbuf.append("\"trade_code\":\"\",");
			strbuf.append("\"inventory_type\":\"1\",");
			strbuf.append("\"owner_user_nick\":\"dishi001_09270337\",");
			strbuf.append("\"flag\":\"0\",");
			strbuf.append("\"item_code\":\""+sku+"\",");
			strbuf.append("\"item_quantity\":\""+qty+"\",");
			strbuf.append("\"item_price\":\""+price+"\"");
			
			strbuf.append("},");				
			
			strbuf.deleteCharAt(strbuf.length()-1);
			strbuf.append("]}");	

			req.setOrderItemList(strbuf.toString());
			
			WlbOrderCreateResponse response = client.execute(req , authcode);
			
			System.out.println(response.getBody());
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	//��ȡ���ջ�״̬�Ĳɹ���
	private static void WlbGetReceivePurcharOrder()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
			WlbOrderPageGetRequest req=new WlbOrderPageGetRequest();
			req.setOrderType("NORMAL_IN");
			req.setOrderSubType("PURCHASE");				
			req.setPageNo(1L);
			req.setPageSize(40L);
			req.setOrderStatus(200L);
			
			WlbOrderPageGetResponse response = client.execute(req , authcode);
			
			System.out.println(response.getBody());
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}			
	}
	//�������׶���
	private static void WlbCreateTradeOrder()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbOrderCreateRequest req=new WlbOrderCreateRequest();
			
			req.setOutBizCode("020V0A11092408");
			req.setPrevOrderCode("1005132318");
			req.setStoreCode("FBI-0001");
			req.setOrderType("NORMAL_OUT");
			req.setOrderSubType("TAOBAO_TRADE");
			req.setBuyerNick("pennytest");
			req.setIsFinished(true);

			String address="�㶫ʡ".concat("^^^").concat("������").concat("^^^").concat("�����").concat("^^^").concat("��ݸׯһ��·116�Ź㶫����������10¥");
			String sendinfo="510610".concat("^^^").concat(address).concat("^^^").concat("����ΰ").concat("^^^").concat("13922373425").concat("^^^").concat("020-38458026");
			
			
			req.setSenderInfo(sendinfo);
			
			String receiveinfo="312000^^^����ʡ^^^������^^^������^^^����������������·���·142�ų����п���ҽԺ������^^^�ﾲ^^^15869362102^^^NA";
			
			req.setReceiverInfo(receiveinfo);
					
			//124000000013447
			StringBuffer strbuf=new StringBuffer();
			strbuf.append("{\"order_item_list\":[");
			String itemid="124000000015453";
			String sku="UF52653AN";
			String qty="1.0";
			String price="112.25";
			strbuf.append("{");				
			strbuf.append("\"item_id\":\""+itemid+"\",");
			strbuf.append("\"inventory_type\":\"1\",");
			strbuf.append("\"trade_code\":\"113170528230\",");
			strbuf.append("\"sub_trade_code\":\"113170528230\",");			
			strbuf.append("\"owner_user_nick\":\"dishi001_09270337\",");
			strbuf.append("\"flag\":\"0\",");
			strbuf.append("\"item_code\":\""+sku+"\",");
			strbuf.append("\"item_quantity\":\""+qty+"\",");
			strbuf.append("\"item_price\":\""+price+"\"");
			
			strbuf.append("},");				
			
			strbuf.deleteCharAt(strbuf.length()-1);
			strbuf.append("]}");	

			req.setOrderItemList(strbuf.toString());
			
			WlbOrderCreateResponse response = client.execute(req , authcode);
			
			System.out.println(response.getBody());
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	//���ݽ��׺Ų�ѯ����������
	private static void WlbGetOrderByTradeCode()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
			WlbTradeorderGetRequest req=new WlbTradeorderGetRequest();
			req.setTradeType("TAOBAO");			
			req.setTradeId("113152288230");
			
			WlbTradeorderGetResponse response = client.execute(req , authcode);
			
			System.out.println(response.getBody());
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	//	�����������ⵥ
	private static void WlbCreateExchangeOrder()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbOrderCreateRequest req=new WlbOrderCreateRequest();
			
			req.setOutBizCode("020V0A11082404");
			req.setPrevOrderCode("1005182315");
			req.setStoreCode("FBI-0001");
			req.setOrderType("EXCHANGE_OUT");
			req.setOrderSubType("OTHER");
			req.setBuyerNick("pennytest");
			req.setRemark("���Ի�������");
			req.setIsFinished(true);

			String address="�㶫ʡ".concat("^^^").concat("������").concat("^^^").concat("�����").concat("^^^").concat("��ݸׯһ��·116�Ź㶫����������10¥");
			String sendinfo="510610".concat("^^^").concat(address).concat("^^^").concat("����ΰ").concat("^^^").concat("13922373425").concat("^^^").concat("020-38458026");
			
			req.setSenderInfo(sendinfo);
			
			String receiveinfo="312000^^^����ʡ^^^������^^^������^^^����������������·���·142�ų����п���ҽԺ������^^^�ﾲ^^^15869362102^^^NA";
			
			req.setReceiverInfo(receiveinfo);
					
			//124000000013447
			StringBuffer strbuf=new StringBuffer();
			strbuf.append("{\"order_item_list\":[");
			String itemid="124000000015453";
			String sku="UF52653AN";
			String qty="1";
			String price="112";
			strbuf.append("{");				
			strbuf.append("\"item_id\":\""+itemid+"\",");
			strbuf.append("\"inventory_type\":\"1\",");
			strbuf.append("\"trade_code\":\"113152288230\",");
			strbuf.append("\"sub_trade_code\":\"113152288230\",");			
			strbuf.append("\"owner_user_nick\":\"dishi001_09270337\",");
			strbuf.append("\"flag\":\"0\",");
			strbuf.append("\"item_code\":\""+sku+"\",");
			strbuf.append("\"item_quantity\":\""+qty+"\",");
			strbuf.append("\"item_price\":\""+price+"\"");
			
			strbuf.append("},");				
			
			strbuf.deleteCharAt(strbuf.length()-1);
			strbuf.append("]}");	

			req.setOrderItemList(strbuf.toString());
			
			WlbOrderCreateResponse response = client.execute(req , authcode);
			
			System.out.println(response.getBody());
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	//��ȡ�ѷ���״̬���Ա����׵�
	private static void WlbGetDeliveryOrder()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
			WlbOrderPageGetRequest req=new WlbOrderPageGetRequest();
			req.setOrderType("NORMAL_OUT");
			req.setOrderSubType("TAOBAO_TRADE");				
			req.setPageNo(1L);
			req.setPageSize(40L);
			req.setOrderStatus(100L);
			
			WlbOrderPageGetResponse response = client.execute(req , authcode);
			
			System.out.println(response.getBody());
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}			
	}
	
	private static void getWLBOrderTMSInfo()
	{
		try
		{			
			TaobaoClient client1=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
			WlbTmsorderQueryRequest req1=new WlbTmsorderQueryRequest();
			req1.setOrderCode("LBX001230117040569");
			WlbTmsorderQueryResponse response = client1.execute(req1 , authcode);
			System.out.println(response.getBody());		
	
		} catch (Exception e) {
			
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	//���ݶ���ȡ��������Ϣ
	private static void WlbGetTMSInfo()
	{
		try
		{
			Connection conn=getConnection();
			try
			{
				String sql="select outbuzcode from customerdelive "
					+"where flag=10 and checkdate>'2012-11-30' and deliverysheetid='null'";
				List slist=SQLHelper.multiRowListSelect(conn, sql);
				for(Iterator it=slist.iterator();it.hasNext();)
				{
					String outbuzcode=(String) it.next();
					
					
					TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
					WlbTmsorderQueryRequest req=new WlbTmsorderQueryRequest();
					req.setOrderCode(outbuzcode);
					WlbTmsorderQueryResponse response = client.execute(req , authcode);
				
					
					String delivery="";
					String deliverysheetid="";
					
					if (response.getTotalCount()==0L) continue;
					
				
					delivery=response.getTmsOrderList().get(response.getTotalCount().intValue()-1).getCompanyCode();
					deliverysheetid=response.getTmsOrderList().get(response.getTotalCount().intValue()-1).getCode();
				
					
					delivery=delivery.substring(0, delivery.indexOf("-"));
					
					sql="update customerdelive set delivery='"+delivery+"',"
								+"deliverysheetid='"+deliverysheetid+"' where outbuzcode='"+outbuzcode+"'";
					SQLHelper.executeSQL(conn, sql);
					
					System.out.println(outbuzcode);
				}
	
			//System.out.println(response1.getBody());
			}finally
			{
				conn.close();
			}
		} catch (Exception e) {
			
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
		/*
		long pageno=1L;	
		for(int k=0;k<10;)
		{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbOrderPageGetRequest req=new WlbOrderPageGetRequest();
			req.setOrderType("NORMAL_OUT");
			req.setOrderSubType("TAOBAO_TRADE");	
			req.setOrderCode("LBX001230102055356");
			req.setPageNo(pageno);
			req.setPageSize(40L);
			req.setOrderStatus(200L);	
			while(true)
			{
				WlbOrderPageGetResponse response = client.execute(req,authcode);
				if (response.getOrderList()==null || response.getOrderList().size()<=0)
				{
					break;
				}
				for (int i=0;i<response.getOrderList().size();i++)
				{
					WlbOrder o=response.getOrderList().get(i);
					TaobaoClient client1=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
					WlbTmsorderQueryRequest req1=new WlbTmsorderQueryRequest();
					req1.setOrderCode(o.getOrderCode());
					WlbTmsorderQueryResponse response1 = client1.execute(req1 , authcode);
					for (int j=0;j<response1.getTmsOrderList().size();j++)
					{
						WlbTmsOrder tms=response1.getTmsOrderList().get(j);
						System.out.println(o.getOrderCode()+"="+tms.getCompanyCode());
					}
				}
				pageno++;
				req.setPageNo(pageno);
				response=client.execute(req , authcode);
			}
			k=10;
		} catch (Exception e) {
			if (++k >= 10)
				break;
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
		}*/
	}
	//��ȡ������˾��Ϣ
	private static void getLogisticsCompanies()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
			LogisticsCompaniesGetRequest req=new LogisticsCompaniesGetRequest();
			req.setFields("id,code,name,reg_mail_no");
			LogisticsCompaniesGetResponse response = client.execute(req , authcode);
			System.out.println(response.getBody());
			Connection conn=getConnection();
			try
			{
				for (int i=0;i<response.getLogisticsCompanies().size();i++)
				{
					String sql="select count(*) from WlbLogisticsCompany "
						+"where companycode='"+response.getLogisticsCompanies().get(i).getCode()+"'";
					if (SQLHelper.intSelect(conn,sql)==0)
					{
						sql="insert into WlbLogisticsCompany "
							+"values('"+response.getLogisticsCompanies().get(i).getCode()+"',"
							+"'"+response.getLogisticsCompanies().get(i).getName()+"',"
							+"'"+response.getLogisticsCompanies().get(i).getRegMailNo()+"')";
						SQLHelper.executeSQL(conn,sql);
					}
					
				}
			}finally
			{
				conn.close();
			}
			
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}	
	}
	//���ݶ���ȡ��������Ҫ��Ϣ
	private static void WlbGetWlborder()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
			WlbWlborderGetRequest req=new WlbWlborderGetRequest();
			req.setWlbOrderCode("LBX0018391168049");
			WlbWlborderGetResponse response = client.execute(req , authcode);
			System.out.println(response.getBody());
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}	
	}
	//����
	private static void OrderDelivery()
	{
		try {
			
			TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
			LogisticsOfflineSendRequest req=new LogisticsOfflineSendRequest();	
			req.setOutSid("6170953033");
			req.setTid(121147836113045L);
			req.setCompanyCode("YTO");
			
			LogisticsOfflineSendResponse rsp = client.execute(req, authcode);
			System.out.println(rsp.getBody());
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}	
	}
	//ȡ������
	private static void CancelOrderDelivery()
	{
		try {
			
			TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
			LogisticsOnlineCancelRequest req=new LogisticsOnlineCancelRequest();	
	
			req.setTid(104142203582518L);
		
			
			LogisticsOnlineCancelResponse rsp = client.execute(req, authcode);
			System.out.println(rsp.getBody());
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}	
	}
	//ȡ�ö�����ϸ
	private static void WlbGetOrderDetail()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey,appsecret,"xml");
			WlbOrderitemPageGetRequest req=new WlbOrderitemPageGetRequest();
			req.setOrderCode("LBX001230114069933");
			WlbOrderitemPageGetResponse response = client.execute(req , authcode);
			System.out.println(response.getBody());
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}	
	}
	//�������ⵥ
	private static void WlbCreateOutSheet()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbOrderCreateRequest req=new WlbOrderCreateRequest();
			
			req.setOutBizCode("020V0A11092305");
			req.setPrevOrderCode("1005132336");
			req.setStoreCode("FBI-0001");
			req.setOrderType("NORMAL_OUT");
			req.setOrderSubType("OTHER");
			req.setPackageCount(Long.valueOf(2));
			req.setIsFinished(true);
			
			String address="�㶫ʡ".concat("^^^").concat("������").concat("^^^").concat("�����").concat("^^^").concat("��ݸׯһ��·116�Ź㶫����������10¥");
			String sendinfo="510610".concat("^^^").concat(address).concat("^^^").concat("����ΰ").concat("^^^").concat("13922373425").concat("^^^").concat("020-38458026");
			String receiveinfo="312000^^^����ʡ^^^������^^^������^^^����������������·���·142�ų����п���ҽԺ������^^^�ﾲ^^^15869362102^^^NA";
			
			//sendinfo="31000^^^�㽭ʡ^^^������^^^������^^^��ҵ����6¥^^^����^^^NA^^^057188155188";
			
			req.setSenderInfo(receiveinfo);
			
			String tmsinfo="YTO".concat("^^^").concat("NA").concat("^^^").concat("8564324523").concat("^^^").concat("NA").concat("^^^").concat("NA");
			
			req.setTmsInfo(tmsinfo);
			
			
			req.setReceiverInfo(sendinfo);
			
			Calendar cd = Calendar.getInstance();
			cd.setTime(new Date());
			cd.add(Calendar.DATE, 3);
								
			req.setExpectStartTime(Formatter.parseDate(Formatter.format(cd.getTime(),Formatter.DATE_TIME_FORMAT),Formatter.DATE_TIME_FORMAT));
			
			cd.add(Calendar.DATE, 2);
			
			//�ջ����������
			req.setExpectEndTime(Formatter.parseDate(Formatter.format(cd.getTime(),Formatter.DATE_TIME_FORMAT),Formatter.DATE_TIME_FORMAT));
			
			//124000000013447
			StringBuffer strbuf=new StringBuffer();
			strbuf.append("{\"order_item_list\":[");
			String itemid="124000000015453";
			String sku="UF52653AN";
			String qty="1";
			String price="112";
			strbuf.append("{");				
			strbuf.append("\"item_id\":\""+itemid+"\",");
			strbuf.append("\"trade_code\":\"\",");
			strbuf.append("\"inventory_type\":\"1\",");
			strbuf.append("\"owner_user_nick\":\"dishi001_09270337\",");
			strbuf.append("\"flag\":\"0\",");
			strbuf.append("\"item_code\":\""+sku+"\",");
			strbuf.append("\"item_quantity\":\""+qty+"\",");
			strbuf.append("\"item_price\":\""+price+"\"");
			
			strbuf.append("},");				
			
			strbuf.deleteCharAt(strbuf.length()-1);
			strbuf.append("]}");	

			req.setOrderItemList(strbuf.toString());
			
			WlbOrderCreateResponse response = client.execute(req , authcode);
			
			System.out.println(response.getBody());
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	//ȡ������������
	private static void WlbOrderGet()
	{
		long pageno=1L;
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbOrderPageGetRequest req=new WlbOrderPageGetRequest();
			//req.setOrderType("NORMAL_IN");
			//req.setOrderSubType("TAOBAO_TRADE");
			req.setOrderCode("LBX001230105423790");
			
			//req.setStartTime(Formatter.parseDate("2012-02-01 00:00:00",Formatter.DATE_TIME_FORMAT));
			//req.setEndTime(Formatter.parseDate("2012-03-28 00:00:00",Formatter.DATE_TIME_FORMAT));
			//req.setPageNo(pageno);
			//req.setPageSize(100L);
			//req.setOrderStatus(200L);	
			WlbOrderPageGetResponse response = client.execute(req,authcode);
			/*
			while(true)
			{
							
				
				if (response.getOrderList()==null || response.getOrderList().size()<=0)
				{				
					break;
				}
				for (int i=0;i<response.getOrderList().size();i++)
				{
					WlbOrder o=(WlbOrder) response.getOrderList().get(i);
					if (o.getOrderSourceCode().equals("LP00005500311812")
							||o.getOrderSourceCode().equals("LP00005609401543"))
						System.out.println(o.getOrderCode());
				}
				pageno++;
				req.setPageNo(pageno);
				response=client.execute(req , authcode);
			}
			*/
			System.out.println(response.getBody());
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	//���ݽ��׺�ȡ������������
	private static void WlbTradeOrderGet()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbTradeorderGetRequest req=new WlbTradeorderGetRequest();
			req.setTradeType("TAOBAO");
			req.setTradeId("113051883915842");
			WlbTradeorderGetResponse response = client.execute(req,authcode);
			
			System.out.println(response.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	//ȡ��������������Ʒ
	private static void WlbOrderItemGet()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbOrderitemPageGetRequest req=new WlbOrderitemPageGetRequest();	
			req.setOrderCode("LBX001230100662605");
			req.setPageNo(1L);
			req.setPageSize(40L);
			WlbOrderitemPageGetResponse response = client.execute(req,authcode);
			
			System.out.println(response.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	
	//ȡ��������������ת״̬
	private static void WlbOrderstatusGet()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbOrderstatusGetRequest req=new WlbOrderstatusGetRequest();	
			req.setOrderCode("LBX001230103114253");
			WlbOrderstatusGetResponse response = client.execute(req,authcode);
			
			System.out.println(response.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	//	ȡ������
	private static void WblCancelOrder()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url, appkey, appsecret,"xml");
			WlbOrderCancelRequest req=new WlbOrderCancelRequest();	
			req.setWlbOrderCode("LBX0018391171090");
			WlbOrderCancelResponse response = client.execute(req,authcode);
			
			System.out.println(response.getBody());
		} catch (ApiException e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}
	}
	//��ȡ�˻��ջ�״̬���Ա����׵�
	private static void WlbGetReturnOrder()
	{
		try
		{
			TaobaoClient client=new DefaultTaobaoClient(url,appkey, appsecret,"xml");
			WlbOrderPageGetRequest req=new WlbOrderPageGetRequest();
			req.setOrderType("RETURN_IN");
			req.setOrderSubType("TAOBAO_TRADE");				
			req.setPageNo(1L);
			req.setPageSize(40L);
			req.setOrderStatus(200L);
			
			WlbOrderPageGetResponse response = client.execute(req , authcode);
			
			System.out.println(response.getBody());
		} catch (Exception e) {
			System.out.println("����Զ�̷����쳣!" + e.getMessage());
		}			
	}
	
    private static long TranTid(String tid)
    {
        tid = tid.trim();
        tid = tid.toLowerCase();
        String t = "";
        for (int i=0; i<tid.length();i++)
        {
        	char c=tid.charAt(i);
            if ((c >= 48) && (c <= 57))
            {
                t = t + c;
            }
        }

        long id = 0;
        if (t != "")
        {
            id = Long.parseLong(t);
        }
        return id;
    }
}


