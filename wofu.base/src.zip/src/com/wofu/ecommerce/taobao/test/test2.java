package com.wofu.ecommerce.taobao.test;

import java.util.HashMap;
import java.util.Map;

import com.taobao.api.internal.util.WebUtils;

public class test2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		

		
	}

}
