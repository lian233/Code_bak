package com.wofu.ecommerce.taobao;

import java.util.Properties;

import com.wofu.common.tools.util.log.Log;

public class Params {
	public static String dbname = "taobao";
	
	public static String tradecontactid="";

	public static String url = "http://gw.api.taobao.com/router/rest";
	
	public static String encoding="GBK";

	public static String appkey = "12205522";

	public static String appsecret = "0d56c9fb65cf8eb136437b02f52846fa";
	
	public static String authcode="29230f8604eb0f9207db7e879820ed1fe09ce";
	
	public static int total=10;
	
	public static int waittime = 10;
	
	public static String username = "��ʿ��ʱ���콢��";
	
	public static String province="�㶫ʡ";
	
	public static String city="������";
	
	public static String district="�����";
	
	public static String address="����·��ʤ��ҵ��2��301";
	
	public static String zipcode="510610";
	
	public static String linkman="����ΰ";
	
	public static String phone="020-38458026";

	public static String mobile="15992409145";
	
	public static String wlbprovince="�Ϻ�";
	
	public static String wlbcity="�Ϻ���";
	
	public static String wlbdistrict="������";
	
	public static String wlbaddress="�������칫·589��E1��U2-U3��";
	
	public static String wlbzipcode="201702";
	
	public static String wlblinkman="����";
	
	public static String wlbphone="021-61256226";

	public static String wlbmobile="13601693743";
	
	public static String storecode="KJ-0011";   //�������ֿ����
	
	public static String wlbinterfacesystem=""; //�ӿ�ϵͳ
	
	public static String mainstorecode="020V04";	//���ֿ�
	
	public static int wlbdays=3;		//Ԥ�ƴﵽ��������
	
	public static boolean iswlb=false;    //�Ƿ�Ϊ�������ӿ�ϵͳ
	
	public static boolean isdistribution=false;    //�Ƿ�Ϊ������
	
	public static boolean isc=true;    //�Ƿ�Ϊc��
	
	public static boolean isrds=true;    //���������Ƿ����Ծ�ʯ��
	
	public Params() {
	}

	public static void init(Properties properties) {
		dbname = properties.getProperty("dbname", "taobao");
		tradecontactid=properties.getProperty("tradecontactid","");
		url = properties.getProperty("url", "http://gw.api.taobao.com/router/rest");
		encoding=properties.getProperty("encoding","GBK");
		appkey = properties.getProperty("appkey", "");
		appsecret = properties.getProperty("appsecret", "");
		authcode = properties.getProperty("authcode", "6201a05512211ZZ986db1a3d738339c4092a2d9167a5d80665715024");
		total = (new Integer(properties.getProperty("total", "10"))).intValue();
		waittime = (new Integer(properties.getProperty("waittime", "10"))).intValue();		
		username = properties.getProperty("username", "��ʿ��ʱ���콢��");
		province= properties.getProperty("province", "�㶫ʡ");
		city= properties.getProperty("city", "������");
		district= properties.getProperty("district", "�����");
		address = properties.getProperty("address", "����·��ʤ��ҵ��2��301");
		zipcode = properties.getProperty("zipcode", "510610");
		linkman = properties.getProperty("linkman", "����ΰ");
		phone = properties.getProperty("phone", "020-38458026");
		mobile = properties.getProperty("mobile", "15992409145");
		wlbprovince= properties.getProperty("wlbprovince", "�Ϻ�");
		wlbcity= properties.getProperty("wlbcity", "�Ϻ���");
		wlbdistrict= properties.getProperty("wlbdistrict", "������");
		wlbaddress = properties.getProperty("wlbaddress", "�������칫·589��E1��U2-U3��");
		wlbzipcode = properties.getProperty("wlbzipcode", "201702");
		wlblinkman = properties.getProperty("wlblinkman", "����");
		wlbphone = properties.getProperty("wlbphone", "021-61256226");
		wlbmobile = properties.getProperty("wlbmobile", "13601693743");
		storecode = properties.getProperty("storecode", "KJ-0011");
		wlbinterfacesystem = properties.getProperty("interfacesystem", "WLB");
		mainstorecode = properties.getProperty("mainstorecode", "");
		wlbdays = (new Integer(properties.getProperty("wlbdays", "10"))).intValue();
		iswlb = Boolean.valueOf(properties.getProperty("iswlb", "false")).booleanValue();
		isdistribution = Boolean.valueOf(properties.getProperty("isdistribution", "false")).booleanValue();
		isc = Boolean.valueOf(properties.getProperty("isc", "true")).booleanValue();
		isrds = Boolean.valueOf(properties.getProperty("isrds", "false")).booleanValue();
	}
}

